package Assign_2;


import Media.*;                  // for Turtle and TurtleDisplayer
import java.awt.*;               // for Color objects and methods
import static java.lang.Math.*;  // for math constants and functions
import static java.awt.Color.*;  // for Color constants
import static Media.Turtle.*; 	 //for Turtle class members



/** This class ...
  *
  * @author Saifa Bhanji
  * @version 1.0 (Oct 2015)                                                        */

public class Cover {
    
    
    // instance variables
    
  private TurtleDisplayer display; 	//display to draw on
  private Turtle yertle; 			//turtle to do drawing
  
    
    /** This constructor ...                                                     */
    
    public Cover ( ) {

        // local variables
        
        // statements including call to method
      display = new TurtleDisplayer();
      yertle = new Turtle(Turtle.FAST);
      display.placeTurtle(yertle);
      
      drawCover();
      display.close();
      
        
    }; // constructor
    
    
    // methods
    
    private void drawCover() {
      yertle.left(PI/2); 	//Move Turtle
      yertle.forward(120); 	//to starting
      yertle.right(PI/2); 	//position
      
      for (int k=1; k<=5; k++) {
      	drawRow();
      	yertle.right(PI/2); 	//Move Turtle
      	yertle.forward(60); 	//to next 
      	yertle.left(PI/2); 		//row
      }; //end of foor loop k
      
      yertle.left(PI/2);
      yertle.forward(180);
      yertle.right(PI/2);
      
    }; //drawCover
    
    private void drawRow() {
      
      yertle.backward(120); 	//move turtle to end of row
      
      for (int j=1; j<=5; j++) {
      	drawPatch();
      	yertle.forward(60);
      }; //end of for loop j
    
      yertle.backward(180); 	//move turtle back to starting position
             
    }; //drawRow
    
    
    private void drawPatch() {
      
      for (int i=1; i<=4 ; i++) {
      	drawTriangle();
      	yertle.right(2*PI/4);
      }; //end of for loop i 
      
    };//drawPatch
    
    
    private void drawTriangle () {
      yertle.penDown();
      
      yertle.forward(30);
      yertle.left(3*PI/4);
      yertle.forward(sqrt (1800));
      yertle.left(3*PI/4);
      yertle.forward(30);
      yertle.left(PI/2);
      
      yertle.penUp();
      
    }; //drawTriangle

    
    
    public static void main ( String[] args ) { Cover c = new Cover(); };
    
    
} // Cover
