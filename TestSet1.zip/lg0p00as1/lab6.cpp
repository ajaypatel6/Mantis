#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <string.h>

using namespace std;

class Record {

private:
	long rid; //Record ID
	char *content;
	
	static long nextRIDCount() {
		return ridCount++;
	}

public:

	long getRID() {
	return rid;
}
	char *getContent() {
	return content;
}

void setRID(long rid) {
	this->rid=rid;
}
void setContent(char cstring) {
//How would we do this? Do we allocate? Beware memory leaks!
}
friend std::ostream& operator<<(std::ostream &out, Record &rec) {
	std::cout<<'['<<rec.rid<<':'<<rec.content<<']';
}
static long ridCount; //Tied to the class; not the object

Record(char content[]) {
	int clength=0;
	this->rid=nextRIDCount();
	while (content[clength]!='\0') clength++;
	this->content=new char[clength];
	for (int i=0;i<clength;i++) this->content[i]=content[i];
}

Record(const Record &original):rid(original.rid) {
	int clength=0;
	while (original.content[clength]!='\0') clength++;
	clength++;
	this->content=new char[clength];
	for (int i=0;i<clength;i++) this->content[i]=original.content[i];
}

Record& operator=(const Record &other) {}

};
long Record::ridCount=0;


/*void mutate(Record r) {
	r.rid=77;
	r.content[0]='Z';
}*/

int main(){

	Record r("abba"),s("betta");
	r=s;
}
