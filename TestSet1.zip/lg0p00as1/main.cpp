#include "Record.h"

int main(){
	char data1[] = "data1";
	char data2[] = "data2";
	char data3[] = "data3";

	Record r0(data1);
	Record r1(data2);
	Record r2(data3);

	
	cout<<"RID: "<<r0.getRID()<<"\tData: "<<r0.getContent()<<endl;
	cout<<"RID: "<<r1.getRID()<<"\tData: "<<r1.getContent()<<endl;
	cout<<"RID: "<<r2.getRID()<<"\tData: "<<r2.getContent()<<endl;

/*	cout<<"Delete some stuff"<<endl;	
	r0.~Record();
	cout<<"RID:"<<r0.getRID()<<"\tData:"<<r0.getContent()<<endl;
*/
}
