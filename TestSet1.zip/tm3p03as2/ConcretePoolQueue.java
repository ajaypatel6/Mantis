package everybodyintothepool;

/*Tamara McDiarmid
* 6148837
*May 2017
*/

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;


public class ConcretePoolQueue<E> implements PoolQueue<E>{
    
    private List<LinkedList<E>> allG =new LinkedList<LinkedList<E>>();;
    int counter=0;
    
    public ConcretePoolQueue(){
        Queue theQ = new LinkedList<>();
    }
    
    /*adds a group of 1 */
    public void addSingle(E item) {
        List<E> single = new LinkedList<>();
        single.add((E) item);
        allG.add((LinkedList<E>) (E) single);
        counter = counter +1;
        //System.out.println(allG);
    }//addSingle
    
    /*adds a group of 2  */
    public void addPair(E first, E second) {
        List<E> pair = new LinkedList<>();
        pair.add((E) first);
        pair.add((E) second);
        allG.add((LinkedList<E>)(E)pair);
        counter = counter +2;
    }//addPair
    
    /*adds a group of 3  */
    public void addTriple(E first, E second, E third) {
        List<E> triple = new LinkedList<>();
        triple.add((E)first);
        triple.add((E)second);
        triple.add((E)third);
        allG.add((LinkedList<E>)(E)triple);
        counter = counter +3;
    }//addTriple
    
    /*adds a group of 4 */
    public void addQuartet(E first,E second, E third,E fourth) {
       List<E> quad = new LinkedList<>();
       quad.add((E)first);
       quad.add((E)second);
       quad.add((E)third);
       quad.add((E)fourth);
       allG.add((LinkedList<E>)(E)quad);
       counter=counter+4;
    }//addQuartet
    
    /*removes a group of 1
     * returns E
     */
    public E removeSingle() {
       
        LinkedList toSend = new LinkedList<>();
        boolean check = remove(1,0,toSend);
        if(!check)throw new InsufficientElementsException();
        counter=counter-1;
        String str=toSend.toString();
        return  (E) str;
    }//removeSingle
    
    /*removes a group of 2
     * returns List<E>
     */
    public List<E> removePair() {
        LinkedList<E> toSend = new LinkedList<>();
        boolean check = remove(2,0,toSend);
        if(!check)throw new InsufficientElementsException();
        counter=counter-2;
        //System.out.println(toSend);
        return  toSend;
    }//removePair
   
    
    /*removes a group of 3
     * returns List<E>
     */
    public List<E> removeTriple() {
        LinkedList<E> toSend = new LinkedList<>();
        boolean check = remove(3,0,toSend);
        if(!check)throw new InsufficientElementsException();
        counter=counter-3;
        System.out.println(toSend);
        return  toSend;
    }//removeTriple
    
    /*removes a group of 4
     * returns List<E>
     */
    public List<E> removeQuartet() {
        List<E> toSend = new LinkedList<>();
        List<E> pool=new LinkedList<>();
        boolean check = remove(4,0,toSend);
        if(!check)throw new InsufficientElementsException();
        counter=counter-4;
        System.out.println(toSend);
        for(int i=0;i<toSend.size();i++){
            
            String str=(String) toSend.get(i);
            pool.add((E) str);
        }
        return pool;
    }//removeQuartet
    
    
    /*Removes a grouping of players from list */
    private boolean remove(int num, int index, List pool){
        
        if (index >= allG.get(index).size())return false;
        if (allG.get(index).size()==num){
            pool.add(allG.get(index).toString());
            allG.remove(index);
            return true;
        }
        if(allG.get(index).size()>num){
            boolean check=hasSome (index+1,num);
            if(check){
                for (int i=index+1;i<allG.size();i++){
                    if (allG.get(i).size()==num){
                        pool.add(allG.get(i));
                        allG.remove(i);
                        return true;
                    }
                }
            }
            
        }
        if(allG.get(index).size() <num){
            boolean check= hasSome(index+1,num-allG.get(index).size());            
            if (check){
                for (int j=index;j<allG.size();j++){
                    if(allG.get(j).size()<num & hasSome(j+1,num-allG.get(j).size())){  
                        //if(allG.get(j).size())
                        check=remove(num-allG.get(j).size(),index+1,pool);
                        if(check){
                        String str=allG.get(j).toString();
                        pool.add(str);
                        return true;
                        }
                    }
                    else{
                        j++;
                    }
                }
                return true;
                //if(pool.size()==num)return true;
                
            }
           
                //return remove(num,index+1,pool);
            
        }
        return remove(num,index+1,pool);
    }
        
    //remove
    
    /*checks for an eligible single grouping to play 
     *returns a boolean
     */   
    public boolean hasSingle() {
        if (allG == null)return false;
        return hasSome(0,1);
    }//hasSingle
    
    /*checks for an eligible pair grouping to play 
     *returns a boolean
     */   
    public boolean hasPair() {
        if (allG == null)return false;
        return hasSome(0,2);
    }//hasPair
    
    /*checks for an eligible triple grouping to play 
     *returns a boolean
     */   
    public boolean hasTriple() {
        if (allG == null)return false;
        return hasSome (0,3);
    }//hasTriple
         
    /*checks for an eligible quartet grouping to play 
     *returns a boolean
     */   
    public boolean hasQuartet() {
       
       if (allG == null)return false;
       return hasSome (0,4);
    }//hasQuartet
       
    /*a helper method for other boolean methods
     *@ see hasSingle  @see hasPair  @see hasTriple   @see hasQuartet
     *returns a boolean
     */   
    private boolean hasSome(int index,int num){
       if (index>=allG.size() )return false;
       if (allG.get(index).size() ==num)return true;
       if(allG.get(index).size() > num){     
           return hasSome (index+1,num);
       }
       boolean check=hasSome(index+1, num-allG.get(index).size());
       if(check)return true;
       else{
           return hasSome(index+1, num);
       }
    }
    /*returns count of the poolQueue    */
    public int count() {
         return counter;
    }
}



