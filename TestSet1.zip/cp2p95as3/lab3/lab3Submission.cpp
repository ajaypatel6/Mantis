#include <iostream>
#include <cstdlib>
using namespace std;

int fib(int in){
	if (in == 1) {
		return 1;
	} else if (in == 0) {
		return 0;
 	} else {
		return (fib(in-1) + fib (in-2));
	}//End if
}//End fib

int main  (int argc, char* argv[]) {
	int input = atoi(argv[1]);
	if (input < 1 || input >90) {
		cout<<"Invalid usage! Please provide a single argument n, where n is in (0..90]"<<endl;
	} else {
		cout<<fib(input)<<endl;
	}//End if
}//End main
