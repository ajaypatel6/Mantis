#include <iostream>


int largest(int arr[], int size) {
	int outVal = arr[0];
	for (int a = 1; a < size; a++) {
		if (outVal < arr[a]) outVal = arr[a];
	}//End for
	return outVal;
}//End largest


int main() {
	int arrayIn[5];
	arrayIn = {1,2,5,4,8};
	std::cout<<largest(arrayIn,5)<<std::endl;
}//End main
