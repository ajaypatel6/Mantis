#include <iostream>
using namespace std;

void tail(int *arr, int size) {
	if (size<=0) return;
	cout<<arr[0];
	tail(arr+1,size-1);
}//End tail


int main() {
	int arrayIn[5];
	arrayIn = {1,2,5,4,8};
	tail(arrayIn,5);
}//End main
