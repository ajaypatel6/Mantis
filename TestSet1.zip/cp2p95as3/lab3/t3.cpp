#include <iostream>
using namespace std;

int main () {
	int a=37;
	int *b=&a;
	*b=40;
	cout<<a<<endl;	
}//End main
