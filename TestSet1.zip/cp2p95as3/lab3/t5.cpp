#include <iostream>
using namespace std;

int sqrt() {
	
}//End sqrt

int main () {
	int oh =14, geez=10;
	int &kwyjibo=huh(oh,geez);
	cout<<kwyjibo<<endl;
	kwyjibo=0;
	cout<<oh<<endl;
}//End main
