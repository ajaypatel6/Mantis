
package avltree;

import BasicIO.*;
import Media.*;
import java.util.StringTokenizer;
import java.util.concurrent.LinkedTransferQueue;
/**
 *
 * @Andrew Folkerson StNum#5764105
 * 11/05/2017
 * This class reads in data from a file and creates an AVL compliant BST from
 * the data. It then performs an SOT on the data and confirms that the tree
 * is in fact AVL compliant. After which, all nodes in the tree who contain a
 * String beginning with a letter between n and d (lower or upper case) are
 * deleted. Another SOT is undergone and the tree is once again confirmed to be
 * AVL compliant.
 */
public class AVLTree {
    public ASCIIDisplayer display;//the display to write the results
    public ASCIIDataFile file;//the file to read in the data
    public Node root;//the first node in the AVL tree
    public LinkedTransferQueue queue;//a queue used for parsing
   
/*This constructor reads in the data from file and parses the data accordinly
    it also calls the methods required to fulfill the purpose of this class.*/    
    public AVLTree(){
        display = new ASCIIDisplayer();
        queue = new LinkedTransferQueue();
        file = new ASCIIDataFile();
        root = null;
        while(!file.isEOF()){
            String s = file.readString();
            StringTokenizer st = new StringTokenizer(s,";:.,-() ");
            while(st.hasMoreTokens()){
                queue.put(st.nextToken());
            }
        }
        root = new Node (null, null, (String)queue.poll(), 1);
        while(!queue.isEmpty()){
            String s = (String)queue.poll();
            Insert(s, root);
        }
        sot(root);
        display.newLine();
        display.writeBoolean(isAVL(root));
        display.newLine();
        display.newLine();
        display.writeString("After Deletion:");
        display.newLine();
        display.newLine();
        deletionProtocol(root);
        sot(root);
        display.newLine();
        display.writeBoolean(isAVL(root));
        display.close();
        file.close();
        
        


    }//constructor
    
/*This method returns the height of a node*/    
    private int height(Node a){
        if(a==null)return-1;
        else{
            return a.height;
        }
    }//height
    
//This method performs an SOT traversal of the tree and prints the result    
    private void sot(Node a){
        if(a.left != null){
            sot(a.left);
            
        }
        display.writeLine(a.name +" = " + a.count);
        if(a.right != null){
            sot(a.right);
        }
        
    }//sot
    
    //This method inserts a node into the tree
    private Node Insert(String s, Node n){
        if (n== null){
            return new Node(null, null, s, 1);
        }
        int compare = s.compareTo(n.name);
        
        if(compare < 0){
            n.left = Insert(s, n.left);   
        }
        else if(compare > 0){
            n.right = Insert(s, n.right);  
        }
        else{
            n.count ++;
        }
        return balance(n);

    }
    
    //this method balances the tree to ensure AVL compliance
    private Node balance(Node n){
        if(n == null || isAVL(n)){
            return n;
        }
        if(height(n.left) - height(n.right)>=2){
            if(height(n.left.left)>height(n.left.right)){
                n = singleRight(n);
            }
            else{
                n = doubleRight(n);
            }
        }
        if(height(n.right) - height(n.left)>=2){
            if(height(n.right.right)>height(n.right.left)){
                n = singleLeft(n);
            }
            else{
                n = doubleLeft(n);
            }
        }
        n.height = 1 + Math.max(height(n.left), height(n.right));
        return n;
    }//balance
    
    /*This method recursively enumerates over the tree and calls the delete
    fucntion whenever a node contains a String beginning with a letter 
    between n and d (upper or lower case).*/
    private void deletionProtocol(Node a){
        if(a.left != null){
            deletionProtocol(a.left);
        }
        if(a.right != null){
            deletionProtocol(a.right);
        }
        char[] letters=a.name.toUpperCase().toCharArray();
        if(letters[0]>='D' && letters[0]<='N'){
            Delete(a.name, root);
        }
    }//deletionProtocol
    
    /*This method recursively deletes a node from the tree and calls the 
    method to rebalance the tree as needed.*/
    private Node Delete(String s, Node n){
        if(n == null){
            return n;
        }
        
        int compare = s.compareTo(n.name);
        
        if(compare<0){
            n.left = Delete(s, n.left);
        }
        else if(compare>0){
            n.right = Delete(s, n.right);
        }
        else if(n.left != null && n.right != null){
            n.name = getSuccessor(n).name;
            n.right = Delete(n.name,n.right);
        }
        else{
            if(n.left!=null)
                n = n.left;
            else
                n = n.right;
        }
        return balance(n);
    }//Delete
    
    //This method returns the successor to a given node.
    private Node getSuccessor(Node n){
        if(n ==null || n.right ==null)
            return null;
        Node b = n.right;
        while(b.left!=null){
            b = b.left;
        }
        return b;
    }//getSuccessor

   //This method checks to see whether a tree is AVL compliant or not. 
    private boolean isAVL(Node a){
        LinkedTransferQueue q = new LinkedTransferQueue();
        q.put(a);
        while(!q.isEmpty()){
            Node b = (Node)q.poll();
            if(Math.abs(height(b.right)-height(b.left))>=2){
                return false;
        }
            if(b.left!=null){
                q.put(b.left);
            }
            if(b.right!=null){
                q.put(b.right);
            }
        }
        return true;
        }//isAVL  
    
    //This method performs a single left rotation on the tree
    private Node singleLeft(Node a){
        Node b = a.right;
        a.right = b.left;
        b.left = a;
        a.height = 1 + Math.max(height(a.left), height(a.right));
        b.height = 1 + Math.max(height(b.left),height(b.right));
        a=b;
        return a;
    }//singleLeft
    
    //This method performs a single right rotation on the tree
    private Node singleRight(Node a){
        Node b = a.left;
        a.left = b.right;
        b.right = a;
        a.height = 1 + Math.max(height(a.left),height(a.right));
        b.height = 1 + Math.max(height(b.left),height(b.right));
        a=b;
        return a;
        
        
    }//singleRight
    
    //This method performs a double right rotation on the tree
    private Node doubleRight(Node a){
        a.left = singleLeft(a.left);
        a = singleRight(a);
        return a;
        
    }//double right
    
    //This method performs a double left rotation on the tree
    private Node doubleLeft(Node a){
        a.right = singleRight(a.right);
        a = singleLeft(a);
        return a;
    }//doubleLeft
    

   
    public static void main(String[] args) {AVLTree s = new AVLTree();    }
    
}//AVLTree
