
package avltree;

/**
 *
 * @author Andrew Folkerson StNum#5764105
 * 11/05/2017
 * This class outlines the structure of an individual node in the tree. It 
 * includes a height counter to ensure AVL compliance as well as a word and a 
 * counter for the number of occurrences of the word.
 */
public class Node {
    public Node right;//the right child of the node
    public Node left;//the left child of the node
    public String name;//the word contained in the node
    public int count;// the number of occurrences of the word
    public int height;//the height of the node
    
    public Node(Node r, Node l, String s, int c){
        right = r;
        left = l;
        name = s;
        count = c;
        height = 0;
    }//constructor
    
}//Node
