#include <iostream>
int main() {
int j,k;
std::cout<<"Enter j: ";std::cin>>j;
std::cout<<"Enter k: ";std::cin>>k;
std::cout<<"Personally, I'm a fan of "<<(j<k?"kayaking":j>k?"jaywalking":"sitting quietly")<<".\n";
}
