#include <iostream>
	int main() {
	int i,j,g;
	double c,d,e,f;
	d=3.7;
	f= 4.0;
	g=10;
	i=e=j=d;
	c=(int)d;
	std::cout<<"Step 1 The Basics"<<std::endl;
	std::cout<<"i: "<<i<<"\tj: "<<j;
	std::cout<<"\tc: "<<c<<"\td: "<<d<<"\te: "<<e<<std::endl;
	std::cout<<"i*d: "<<i*d<<std::endl;
	std::cout<<"i/d: "<<i/d<<std::endl;
	std::cout<<"i+d: "<<i+d<<std::endl;
	std::cout<<"i-d: "<<i-d<<std::endl;
	std::cout<<"i%d: "<<g%i<<std::endl;
}
