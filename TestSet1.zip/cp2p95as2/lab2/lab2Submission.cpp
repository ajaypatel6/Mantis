#include <iostream>
int main() {
	unsigned char a=0x9B;

	do {
		if (a%2 == 0){
			std::cout<<"zero"<<std::endl;
		} else {
			std::cout<<"one"<<std::endl;
		}
		a=a>>1;
	} while (a > 0);
}
