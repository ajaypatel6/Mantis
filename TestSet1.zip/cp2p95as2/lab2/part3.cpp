#include <iostream>
	int main() {
	int i=3>>1;
	int j=i<<1;
	int k=-1;
	int l=~k;
	std::cout<<"i: "<<i<<"\tj: "<<j<<"\tk: "<<k<<"\tl: "<<l<<std::endl;
	i=0xF; //corresponds to 00(lots of 0s)01111
	j=0b00001001; //It's actually more than 8 bits; it just adds zeroes
	k=i&j;
	l=i^j; //The last nybble is 0110, or 6
	std::cout<<"i: "<<i<<"\tj: "<<j<<"\tk: "<<k<<"\tl: "<<l<<std::endl;
	i=0;
	j=!i;
	k=~i;
	l=j==k;
	std::cout<<"i: "<<i<<"\tj: "<<j<<"\tk: "<<k<<"\tl: "<<l<<std::endl;
}
