#include <iostream>
int main() {
        int val;
	std::cout<<"Enter a value between 1 and 10: ";
	std::cin>>val;
	
	switch (val) {

	case 1:
		std::cout<<"One! Aha ha!"<<std::endl;
		break;
	case 2:
		std::cout<<"Two! Two! Aha ha!"<<std::endl;
		break;
	case 3:
	case 4:
		std::cout<<"Some! Some, aha ha!"<<std::endl;
	case 5:
		std::cout<<"Many! Aha ha!"<<std::endl;
		break;
	default:
		std::cout<<"I don't think you understood the instructions."<<std::endl;
		break;
}

		
	
}
