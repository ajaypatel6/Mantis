#include <iostream>
int main() {
int i=23; //0b00010111
std::cout<<"i: "<<i<<"\ti[0]: "<<(i>>0&1)
<<"\ti[1]: "<<(i>>0&1)<<"\ti[4]: "<<(i>>4&1)<<std::endl;
}
