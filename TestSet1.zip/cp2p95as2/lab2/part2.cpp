#include <iostream>
	int main() {
	int i=0b00011000;
	int j=030;
	int k=0x18;
	int l=24;
	std::cout<<"i: "<<i<<"\tj: "<<j<<"\tk: "<<k<<"\tl: "<<l<<std::endl;
}
