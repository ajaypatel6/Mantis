package Lab_2_2;


import Media.*;                  // for Turtle and TurtleDisplayer
import static java.lang.Math.*;  // for Math constants and functions
import static java.awt.Color.*;  // for Color constants


/** This class ...
  *
  * @author Andrew Folkerson
  * 
  * @version 1.0 (<28/09/2016>)                                                        */

public class Staircase {
    
    
    // instance variables
    private TurtleDisplayer display;
    private Turtle yertle;
    
    /** This constructor ...                                                     */
    
    public Staircase ( ) {
        
        // statements
        display = new TurtleDisplayer();
        yertle = new Turtle(); 
        
        display.placeTurtle(yertle);
        yertle.penDown();
        
        for ( int j=1; j<=4 ; j++) {
        for ( int i=1; i<=5 ; i++) {
          yertle.forward(10);
          yertle.right(PI/2);
          yertle.forward(10);
          yertle.left(PI/2);}
        yertle.right(PI/2);}
        yertle.right(PI/2);
        yertle.penUp();
        yertle.forward(50);
        for ( int k=1; k<=4 ; k++) {
          yertle.forward(50);
          yertle.penDown();
          yertle.forward(10);
          yertle.penUp();
          yertle.backward(60);
            yertle.left(PI/2);}  
          
        display.close();
    }; // constructor
    
    
    public static void main ( String[] args ) { Staircase s = new Staircase(); };
    
    
} // <className>
