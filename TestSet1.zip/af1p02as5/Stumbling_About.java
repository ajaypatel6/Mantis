package Lab_3_2;


import Media.*;                  // for Turtle and TurtleDisplayer
import java.awt.*;               // for Color objects and methods
import static java.lang.Math.*;  // for math constants and functions
import static java.awt.Color.*;  // for Color constants


/** This class ...
  *
  * @author Andrew
  *
  * @version 1.0 (05/10/2016)                                                        */

public class Stumbling_About {
    TurtleDisplayer display;
    Turtle          yertle;
    
    
    // instance variables
    
    
    /** This constructor ...                                                     */
    
    public Stumbling_About ( ) {
        yertle= new Turtle();
        display=new TurtleDisplayer();
        display.placeTurtle(yertle);
        
        
        for (int i=1 ; i<=5 ; i++){
          yertle.setPenColor(new Color((int)(16777216*random()-0)));
          drawStarburst();
        };
        display.close();
    }; // constructor

    
    
    /** This method ...                                                          */
    
    private void drawStarburst ( ) {
      yertle.moveTo((int)301*random()-150, (int)(301*random()-150));
      for ( int i=1 ; i<=10 ; i++ ) {
        yertle.forward(20);
        yertle.penDown();
        yertle.forward(10);
        yertle.penUp();
        yertle.backward(30);
        yertle.left(PI/5); }
    
        // statements
    
    }; // <methodName>

    
    
    public static void main ( String[] args ) { Stumbling_About s = new Stumbling_About(); };

    
    
}  // <className>
