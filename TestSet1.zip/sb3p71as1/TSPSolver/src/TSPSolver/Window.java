package TSPSolver;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *      COSC 2P05 - Assign 3
 *       @author Saifa Bhanji
 *       Student Number: 5172879
 *       Class Description: Class that shuffles the path stored in an integer array
 */

public class Window extends JFrame {

    private FormPanel formPanel;

    /**
     * creates a new JFrame with the given title
     * @param title
     */

    public Window(String title) {
        super(title);

        // set layout manager
        setLayout(new BorderLayout());

        // create Swing components


        formPanel = new FormPanel();

        //Add Swing Components to Content Pane
        Container c = getContentPane();

        c.add(formPanel, BorderLayout.NORTH);

    } // Window

} //class