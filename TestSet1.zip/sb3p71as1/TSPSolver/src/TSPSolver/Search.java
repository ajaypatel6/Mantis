package TSPSolver;

import java.util.Arrays;

/**
 *      COSC 2P05 - Assign 3
 *       @author Saifa Bhanji
 *       Student Number: 5172879
 *       Class Description: Class that runs the search given a set of Locations.
 */

public class Search implements Runnable {

    private Shuffle search; // used to shuffle the path 
    private Mutate mutate; // used to mutate the path
    private Locations map; // used to get the distance between points
    private int randomPath[]; // stores a random path
    private int currentPath[]; // stores the current path
    private int mutatedPath[]; // stores the mutated path
    private volatile int[] globalBestPath; // stores the best found path between all threads
    private int[] bestPath; // stores the best path found in the thread
    private int numIterations; // number of iterations to run for
    private int numSearches; // number of searches to complete
    private volatile double globalBestLength; // length of the globalBestPath
    private double bestLength; // length of the bestPath
    private volatile FormPanel panel;

    /**
     * starts a search given a set of locations, the number of times to run the search
     * the number of iterations to run each search for, and the panel to display the 
     * results to. 
     * @param map
     * @param numS
     * @param numI
     * @param panel
     */
    public Search(Locations map, int numS, int numI, FormPanel panel) {
        this.map = map;
        this.numSearches = numS;
        this.numIterations = numI;
        this.panel = panel;


        randomPath = new int[map.numVertices];
        fillPath();

        globalBestPath = new int[map.numVertices];

        globalBestLength = Double.MAX_VALUE;


    } //Search


    public void run() {

        synchronized(this) {
            bestLength = Double.MAX_VALUE;
            bestPath = new int[map.numVertices];
            for (int s = 0; s < numSearches; s++) {
                shufflePath();
                currentPath = randomPath;
                for (int i = 0; i < numIterations; i++) {
                    mutatedPath = currentPath.clone();
                    mutatePath();
                    if (calcLength(mutatedPath) < calcLength(currentPath)) {
                        currentPath = mutatedPath.clone();
                    }
                    if (calcLength(mutatedPath) < bestLength) {
                        bestPath = mutatedPath.clone();
                        bestLength = calcLength(bestPath);
                    }
                }
            }

            if (bestLength < globalBestLength) {
                updateGUI();
                globalBestPath = bestPath.clone();
                globalBestLength = calcLength(bestPath);
            }
        }

    }

    /**
     * method to return the best path
     * @return
     */
    public synchronized int[] getBestPath() {
        return globalBestPath;
    }

    /**
     * method to return the length of the best path
     * @return
     */
    public synchronized double getBestLength() {
        return globalBestLength;
    }

    private synchronized void updateGUI() {
        panel.setCurrentBest(Double.toString(bestLength));
        panel.setCurrentPath(Arrays.toString(bestPath));
    }

    private float calcLength(int p[]) {
        float pLength = 0;
        int i = 0;

        while (i + 1 < p.length) {
            pLength = pLength + map.getDistance(p[i], p[i + 1]);
            i++;
        }
        pLength = pLength + map.getDistance(p[p.length - 1], p[0]);

        return pLength;

    }

    private void fillPath() {
        for (int i = 0; i < map.numVertices; i++) {
            randomPath[i] = i;
        }

    }

    private void shufflePath() {
        search = new Shuffle(randomPath);
        randomPath = search.getPath();

    }

    private void mutatePath() {
        mutate = new Mutate(mutatedPath);
        mutatedPath = mutate.getPath();
    }

} //class