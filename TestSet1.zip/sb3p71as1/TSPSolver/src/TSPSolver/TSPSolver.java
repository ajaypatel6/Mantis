package TSPSolver;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *      COSC 2P05 - Assign 3
 *       @author Saifa Bhanji
 *       Student Number: 5172879
 *       Class Description: Class that creates a new instance of a TSPSolver which reads in
 *                          a file and creates a map of locations and starts the search
 *                          process. 
 */

public class TSPSolver {

    private int numThreads;
    private Locations map;
    private Thread object;
    private Search search;


    public TSPSolver(String fileName, int numThreads, int numSearches, int numIterations, FormPanel panel) {
        this.numThreads = numThreads;

        File file = new File(fileName);
        try {
            Scanner input = new Scanner(file);
            map = new Locations(input);
        } catch (FileNotFoundException e) {
            System.err.println("Caught IOException: " + e.getMessage());
        }

        search = new Search(map, numSearches, numIterations, panel);
        try {
            startThreads();
            object.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(TSPSolver.class.getName()).log(Level.SEVERE, null, ex);
        }


    } //TSPSolver

    private void startThreads() throws InterruptedException {
        for (int i = 0; i < numThreads; i++) {
            object = new Thread(search, " " + i);
            object.start();
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new Window("TSP Solver");
                frame.setSize(1000, 700);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });
    } // main

} // class