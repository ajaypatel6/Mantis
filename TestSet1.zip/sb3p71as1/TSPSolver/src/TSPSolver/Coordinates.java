package TSPSolver;

/**
 *      COSC 2P05 - Assign 3
 *       @author Saifa Bhanji
 *       Student Number: 5172879
 *       Class Description: Class that creates a coordinate for the point and 
 *                           stores its location. 
 */

public class Coordinates {

    private final float xPosition; // stores the x position of the coordinate
    private final float yPosition; // stores the y position of the coordinate

    /**
     *
     * @param x
     * @param y
     */
    public Coordinates(float x, float y) {

        this.xPosition = x;
        this.yPosition = y;
    }

    /**
     * method to get the x Position of the coordinate
     * @return
     */

    public float getXPosition() {
        return xPosition;
    }

    /**
     * method to get the Y position of the coordinate
     * @return
     */

    public float getYPosition() {
        return yPosition;
    }


}