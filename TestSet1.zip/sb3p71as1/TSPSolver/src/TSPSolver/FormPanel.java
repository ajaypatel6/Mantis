package TSPSolver;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


/**
 *      COSC 2P05 - Assign 3
 *       @author Saifa Bhanji
 *       Student Number: 5172879
 *       Class Description: Class that creates a form on the GUI. 
 */

public class FormPanel extends JPanel {

    static FormPanel panel;
    private JTextField currentBestField;
    private JTextArea textArea;

    public FormPanel() {
        Dimension size = getPreferredSize();
        size.height = 700;
        setPreferredSize(size);
        this.panel = this;


        setBorder(BorderFactory.createTitledBorder("Search Parameters"));

        JLabel fileLabel = new JLabel("File Path:");
        JLabel currentBestLabel = new JLabel("Current Best: ");
        JLabel numThreadsLabel = new JLabel("Number of Threads: ");
        JLabel numSearchesLabel = new JLabel("Number of Searches: ");
        JLabel numIterationsLabel = new JLabel("Number of Iterations: ");

        JTextField fileField = new JTextField(10);
        JTextField numThreadsField = new JTextField(10);
        JTextField numSearchesField = new JTextField(10);
        JTextField numIterationsField = new JTextField(10);
        currentBestField = new JTextField(10);

        currentBestField.setEditable(false);

        JButton searchBtn = new JButton("Run Search");

        textArea = new JTextArea();

        searchBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String fileName = fileField.getText();
                int numThreads = Integer.parseInt(numThreadsField.getText());
                int numSearches = Integer.parseInt(numSearchesField.getText());
                int numIterations = Integer.parseInt(numIterationsField.getText());


                //create new TSPSolver object passing all of these parameters
                TSPSolver tspSolver = new TSPSolver(fileName, numThreads, numSearches, numIterations, panel);
            }

        });

        setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();

        //// First Row


        gc.weightx = 0.5;
        gc.weighty = 0.5;

        gc.gridx = 0;
        gc.gridy = 0;
        add(fileLabel, gc);

        gc.gridx = 1;
        gc.gridy = 0;
        add(fileField, gc);

        gc.gridx = 2;
        gc.gridy = 0;
        add(searchBtn, gc);

        gc.gridx = 3;
        gc.gridy = 0;
        add(currentBestLabel, gc);

        gc.gridx = 4;
        gc.gridy = 0;
        add(currentBestField, gc);

        // Second row

        gc.gridx = 0;
        gc.gridy = 1;
        add(numThreadsLabel, gc);

        gc.gridx = 1;
        gc.gridy = 1;
        add(numThreadsField, gc);

        gc.gridx = 2;
        gc.gridy = 1;
        add(numSearchesLabel, gc);

        gc.gridx = 3;
        gc.gridy = 1;
        add(numSearchesField, gc);

        gc.gridx = 4;
        gc.gridy = 1;
        add(numIterationsLabel, gc);

        gc.gridx = 5;
        gc.gridy = 1;
        add(numIterationsField, gc);

        /// Final row

        gc.weighty = 10;

        gc.anchor = GridBagConstraints.FIRST_LINE_START;
        gc.gridx = 2;
        gc.gridy = 2;

        add(textArea, gc);
        textArea.setColumns(26);
        textArea.setLineWrap(true);
        textArea.append("Input File Path");

    }

    /**
     * method that returns the current best length
     * @return
     */
    public JTextField getCurrentBest() {
        return currentBestField;
    }

    /**
     * method that returns the current best path
     * @return
     */
    public JTextArea getCurrentPath() {
        return textArea;
    }

    /**
     * method to display the length of the current path on the GUI 
     * @param contents
     */
    public void setCurrentBest(String contents) {
        currentBestField.setText(contents);
    }

    /**
     * method to display the current path on to the GUI
     * @param path
     */
    public void setCurrentPath(String path) {
        textArea.setText(" ");
        textArea.append("Best Path is: " + path);
    }


}