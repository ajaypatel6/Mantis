package TSPSolver;

import java.util.concurrent.ThreadLocalRandom;


/**
 *      COSC 2P05 - Assign 3
 *       @author Saifa Bhanji
 *       Student Number: 5172879
 *       Class Description: Class that shuffles the path stored in an integer array
 */

public class Shuffle {

    private int path[]; // array to store the path

    public Shuffle(int p[]) {

        this.path = p;

        for (int i = 0; i < path.length; i++) {
            int randomNum = ThreadLocalRandom.current().nextInt(0, path.length - 1);
            int temp = path[randomNum];
            path[randomNum] = path[i];
            path[i] = temp;
        }

    } //shuffle

    /**
     * method to get the shuffled array
     * @return
     */
    public int[] getPath() {
        return this.path;
    }

} //class