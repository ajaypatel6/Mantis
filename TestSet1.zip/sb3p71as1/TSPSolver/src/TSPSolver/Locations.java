package TSPSolver;

import java.util.Scanner;

/**
 *      COSC 2P05 - Assign 3
 *       @author Saifa Bhanji
 *       Student Number: 5172879
 *       Class Description: Class that creates an array of vertex points and the
                            adjacency matrix that stores the distance between the
                            vertex points.
 */

public final class Locations {

    int numVertices; // number of points to visit
    private Coordinates vertex[]; // array to store the vertex points and their locations
    private float matrix[][]; // adjacency matrix of distances between points

    /**
     *
     * @param input
     */
    public Locations(Scanner input) {
        this.numVertices = input.nextInt();

        vertex = new Coordinates[numVertices];

        while (input.hasNext()) {
            for (int i = 0; i < numVertices && input.hasNext(); i++) {
                input.nextInt();
                vertex[i] = new Coordinates(input.nextFloat(), input.nextFloat());
            }
        }

        matrix = new float[numVertices][numVertices];

        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                if (i == j) {
                    matrix[i][j] = 0;
                    matrix[j][i] = 0;
                } else {
                    float x1 = vertex[i].getXPosition();
                    float y1 = vertex[i].getYPosition();
                    float x2 = vertex[j].getXPosition();
                    float y2 = vertex[j].getYPosition();

                    matrix[i][j] = calculate(x1, y1, x2, y2);
                }
            }
        }
    } //Locations

    /**
     * method that calculates the distance between 2 points given their X and Y positions
     * 
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @return
     */
    public float calculate(float x1, float y1, float x2, float y2) {
        double termX = (x1 - x2) * (x1 - x2);
        double termY = (y1 - y2) * (y1 - y2);

        double dist = Math.sqrt(termX + termY);

        return (float) dist;
    }

    /**
     * method that returns the distance between 2 points 
     * 
     * @param i
     * @param j
     * @return
     */
    public float getDistance(int i, int j) {

        return matrix[i][j];
    }




} //class