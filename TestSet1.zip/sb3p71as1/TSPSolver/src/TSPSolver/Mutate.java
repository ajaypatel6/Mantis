package TSPSolver;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

/**
 *      COSC 2P05 - Assign 3
 *       @author Saifa Bhanji
 *       Student Number: 5172879
 *       Class Description: Class that mutates the path stored in an integer array
 */



public class Mutate {

    private int path[]; // array to store the path

    public Mutate(int p[]) {
        this.path = p;
        int[] randomNumbers;
        int[] shuffledNumbers;

        randomNumbers = ThreadLocalRandom.current().ints(1, 52).distinct().limit(3).toArray();

        shuffledNumbers = randomNumbers.clone();
        Shuffle shuffle = new Shuffle(shuffledNumbers);
        shuffledNumbers = shuffle.getPath();

        if (Arrays.equals(randomNumbers, shuffledNumbers)) {
            Shuffle shuffle2 = new Shuffle(shuffledNumbers);
            shuffledNumbers = shuffle2.getPath();
        }

        int pcopy[] = p.clone();

        for (int i = 0; i < randomNumbers.length; i++) {
            int old = randomNumbers[i];
            int move = shuffledNumbers[i];
            int temp = pcopy[old];
            p[move] = temp;
        }


    } //mutate

    /**
     * method to return the mutated path 
     * 
     * @return
     */
    public int[] getPath() {
        return this.path;
    }

} //class