package Lab_3_1;


import Media.*;                  // for Turtle and TurtleDisplayer
import java.awt.*;               // for Color objects and methods
import static java.lang.Math.*;  // for math constants and functions
import static java.awt.Color.*;  // for Color constants


/** This class ...
  *
  * @author Andrew Folkerson
  *
  * @version 1.0 (05/10/2016)                                                        */

public class Polyspiral {
    
    
    TurtleDisplayer display;
    Turtle          yertle;
    
    
    
    /** This constructor ...                                                     */
    
    public Polyspiral ( ) {
      
        double length;
        yertle= new Turtle();
        display= new TurtleDisplayer();
        display.placeTurtle(yertle);
        length=2;
        yertle.penDown();
        
        for (int i=1 ; i<=30 ; i++){
          drawPolyspiral(length);
          length=length+2; } 
        display.close();
        
    }; // constructor

    
    
    /** This method ...                                                          */
    
    private void drawPolyspiral (double length ) {
      
      yertle.forward(length);
      yertle.right(PI/6);  
      
    
        // local variables
    
        // statements
    
    }; // <methodName>

    
    
    public static void main ( String[] args ) { Polyspiral s = new Polyspiral(); };

    
    
}  // <className>
