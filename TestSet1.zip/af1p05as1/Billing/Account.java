package Billing;


import BasicIO.*;


public class Account {
  private static final double RATE=1.525;
  private String accountNumber;
  private String name;
  private double prevReading;
  private double currReading;
    
    
    /* Instance Variables */
    
    
    public Account ( ASCIIDataFile from ) {
      accountNumber=from.readString();
      if(!from.isEOF()){
        name=from.readString();
        prevReading=from.readDouble();
        currReading=from.readDouble();
      };
        
    };  // constructor
    
    
    public String getAcctNum ( ) {
      return accountNumber;

        
    };  // getAcctNum
    
    
    public String getName ( ) {
      return name;
        
        
    };  // getName
    
    
    public double getPrevReading ( ) {
        return prevReading;
        
   };  // getPrevReading
    
    
    public double getCurrReading ( ) {
        return currReading;
        
    };  // getCurrReading
    
    
    public void takeReading ( double reading ) {
      currReading= reading;
        
        
    };  // takeReading
    
    
    public double billForUsage ( ) {
      double result;
      result=(currReading-prevReading)*RATE;
      prevReading=currReading;
      return result;
        
        
    };  // billForUsage
    
    
    public void write ( ASCIIOutputFile to ) {
      to.writeString(accountNumber);
      to.writeString(name);
      to.writeDouble(prevReading);
      to.writeDouble(currReading);
      to.newLine();
        
        
    };  // write
    
    
}  // Account