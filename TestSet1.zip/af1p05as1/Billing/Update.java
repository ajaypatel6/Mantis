package Billing;


import BasicIO.*;
import static BasicIO.Formats.*;


public class Update {
    
    /* Instance Variables */
    private BasicForm        usageForm;  // meter reading form
    private ASCIIDataFile   input;
    private ASCIIOutputFile  output;
    private Account[]        data;
    private static final int MAX_ACCT=100;
    private int counter=0;
    private Account         account;
    
    
    public Update ( ) {
      int button;
      
      usageForm= new BasicForm();
      setUpForm();
      
      output= new ASCIIOutputFile();
      input = new ASCIIDataFile();  
      
      loadAccts();
      input.close();
      for (;;){
        usageForm.clearAll();
        button= usageForm.accept("Find", "Quit");
        if (button==1) break;
        account = findAcct(usageForm.readString("acctNum"));
        if (account != null) {
          fillForm(account);
          usageForm.accept("Update");
          account.takeReading(usageForm.readDouble("reading"));
        }
      };
      usageForm.close();
      writeAccts();
      output.close();
        
    };  // construtor
    
    
    private void loadAccts ( ) {
      data=new Account[MAX_ACCT];
      while (true){
        Account account= new Account(input);
        
        if(input.isEOF())break;
        
        data[counter]=account;
        counter++;
        
       

        
      };
        
        
    };  // loadAccts
    
    
    private void writeAccts ( ) {
      
      for (int i=0; i<counter; i++){
        data[i].write(output);

        
        
      };
    };  // writeAccts
    
    
    private Account findAcct ( String acctNum ) {
      Account result =null;
      int low=0;
      int high=counter -1;
      
      while(low<=high){
        int pos= (low+high)/2;
        if(acctNum.equals(data[pos].getAcctNum())){
         result=data[pos]; 
          break;
        }
        if(acctNum.compareTo(data[pos].getAcctNum())>0){
         low=pos+1; 
        }
        else {
          high=pos-1;
        };
        
        
      }
      
      return result;
      
      
      

          
        
        
     
    };  // findAcct

    
    private void setUpForm ( ) {
        
        usageForm.setTitle("Over The Horizon Utilities");
        usageForm.addTextField("acctNum","Account #",getIntegerInstance(),
                               6,10,10);
        usageForm.addTextField("name","Name",20,10,40);
        usageForm.addTextField("prev","Previous Reading",getDecimalInstance(1),
                               6,10,70);
        usageForm.addTextField("reading","Current Reading",getDecimalInstance(1),
                               6,10,100);
        
    };  // setUpForm
    
    
    private void fillForm ( Account anAcct ) {
        
        usageForm.writeString("acctNum",anAcct.getAcctNum());
        usageForm.writeString("name",anAcct.getName());
        usageForm.writeDouble("prev",anAcct.getPrevReading());
        usageForm.clear("reading");
        
    };  // fillForm
    
    
    public static void main ( String[] args ) { Update u = new Update(); };
    
    
}  // Update