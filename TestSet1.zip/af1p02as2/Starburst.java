package Lab_2_1;


import Media.*;                  // for Turtle and TurtleDisplayer
import static java.lang.Math.*;  // for Math constants and functions
import static java.awt.Color.*;  // for Color constants


/** This class ...
  *
  * @author <Andrew Folkerson>
  * 
  * @version 1.0 (<28/09/2016>)                                                        */

public class Starburst {
        
    private TurtleDisplayer display;
    private Turtle yertle;
  
    
    // instance variables
    
    
    /** This constructor ...                                                     */
    
    public Starburst ( ) {
      display= new TurtleDisplayer();
      yertle= new Turtle();
     
        display.placeTurtle(yertle);
        yertle.setPenColor(orange);
        
        
        for ( int i=1 ; i<=10 ; i++ ) {
        yertle.forward(60);
        yertle.penDown();
        yertle.forward(30);
        yertle.penUp();
        yertle.backward(90);
        yertle.left(PI/5); }
       
        display.close();
        // statements
        
    }; // constructor
    
    
    public static void main ( String[] args ) { Starburst s = new Starburst(); };
    
    
} // <className>
