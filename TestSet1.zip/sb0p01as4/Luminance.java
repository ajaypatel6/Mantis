package Assign_4; 
 
 
import Media.*;                  // for Media classes 
import java.awt.*;               // for Color objects and methods 
import static java.lang.Math.*;  // for math constants and functions 
import static java.awt.Color.*;  // for Color constants 
 
 
/** This class ... 
  * 
  * @author Saifa Bhanji 
  * @version 1.0 (Oct 2015)                                                        */ 
 
public class Luminance { 
     
     
    // instance variables 
  
  private PictureDisplayer display;
  private PictureDisplayer display2; 
     
     
    /** This constructor ...                                                     */ 
     
    public Luminance ( ) { 
 
        // local variables 
      
      Picture pic1;
      Picture pic2; 
      double luminance; 
         
        // statements 
    
      pic1 = new Picture(); 
      display = new PictureDisplayer(pic1);
      
      
      pic2 = new Picture(); 
      display2 = new PictureDisplayer(pic2); 
      
      display.waitForUser(); 
      //display2.close(); 
      
      while (pic1.hasNext() && pic2.hasNext()) {
        //System.out.println("Test");
        Pixel currPix1 = pic1.next();
        Pixel currPix2 = pic2.next(); 
        luminance = getLuminance(currPix1);  
        blend(currPix2, luminance); 
      }
      display.close();
      pic1.save(); 
         
    } // constructor 
     
     
    // methods 
    
    private double getLuminance (Pixel p) {
      int r; // red value of pixel
      int g; // green value of pixel
      int b; // blue value of pixel
      double luminance; // luminance of the pixel
      
      luminance = 0; 
      
      r = p.getRed(); 
      g = p.getGreen();
      b = p.getBlue(); 
        
      luminance = (r + g + b)/3;  
        
      
      return luminance; 
      
    } //getLuminance
    
    private int clip (double val) {
      int clipped;
      
      clipped = (int) val; 
      
      if (clipped <= 255) {
        return clipped;
      } 
      else {
        return 255; 
      }     
      
    } //clip
    
    private void blend (Pixel p, double luminance) {      
      
      double plum = getLuminance(p);
      double FACTOR = 0;
      if (luminance != 0.0) {
      FACTOR = luminance / plum;
      } else {
     // FACTOR = Math.max(0, FACTOR);
      }
      //System.out.format("%f %f %f%n", plum, luminance, FACTOR); 
      

      
      p.setRed(clip(p.getRed()*FACTOR)); 
      p.setGreen(clip(p.getGreen()*FACTOR));
      p.setBlue(clip(p.getBlue()*FACTOR)); 
      
    } 
    
 
     
    public static void main ( String[] args ) { Luminance s = new Luminance(); } 
     
     
} // Luminance 
