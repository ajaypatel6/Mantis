#include <iostream>
#include "recHeader.h"

void displayRecord(PRecord pr) { //provided in lab outline
	cout<<"\tPriority: "<<pr.priority<<"\tEntry data: \""<<pr.entry<<'"'<<endl;
}

const int arrSize = 5; //size of PQueue

PRecord array[arrSize];//A PRecord queue that can hold arrSize items
int count= 0; //used to keep track of the number of valid items in queue
int age= 0; //this is used to track the oldest items. It would be more flexible if based on system time	

void enqueue(PRecord value) {
	
	value.ageValue=age;
	
	if (count==(sizeof(array)/24)){//queue is full
		cout<<"***queue is full***"<<endl;
		cout<<"Tried to add: ";
		displayRecord(value);
	}
	if (count<(sizeof(array)/24)){ //there is room to add
		
		for (int i=0; i<(sizeof(array)/24);i++){
			if (array[i].priority==0){
				array[i]=value;	
				break;
			}
		}	

		cout<<"Added to Queue: ";
		displayRecord(value);
		count++;
	}
	age++;
}
void dequeue() {

	PRecord value; 		
	int lowest=100000;
	int lowestAge=100000;	
	int pos;
	
	if (count<1){
		cout<<"***empty queue***"<<endl;
	}else{
			
		for (int i=0; i<(sizeof(array)/24);i++){ //Removing from Queeu
		
			if (array[i].priority<=lowest&&array[i].priority>0){
					
				if (lowestAge>array[i].ageValue){ //couldn't get this to work
					pos = i;
					lowest = array[i].priority;
					lowestAge = array[i].ageValue;
				}	
			}
		}		
		cout<<"Removed from Queue: ";
		displayRecord(array[pos]);
		
		array[pos].priority = 0;//flagged cell to be written over	
		count--;
	}
}

int main() {
	for (int i=0; i<(sizeof(array)/24);i++){ //init priority values
		array[i].priority=0;
	}
	
	long priority;
	string data;	
	int pick;
		
	while (true){
		cout<<"0. enqueue:"<<endl;
		cout<<"1. dequeue:"<<endl;		
		cin>>pick;
		

		if (pick==0){

			cout<<"Please enter Priority:"<<endl;
			cin>>priority;

			cout<<"Please String:"<<endl;
			cin>>data;

			PRecord r = {priority, data};		
			enqueue(r);
		}
		if (pick == 1){
			dequeue();		
		}
	}	

}
}