package assign4;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * Tamara McDiarmid 6148837 COSC 2P05 ASSIGNMENT#4 APRIL 2018
 */

//shared buffer (see ShipGui and OrderGui)
public class Buffer {

    private final int capacity = 5;
    String[] theArray;
    private int front = 0;
    private int tail = 0;
    private final List<String> log;
    private boolean isEmpty = true;
    private String frontOfBuffer;
    private int size = 0;

    public Buffer() {
        log = new LinkedList<>();
        theArray = new String[capacity];
    }//constructor

    public synchronized boolean isEmpty() {
        return isEmpty;
    }//isEmpty

    public synchronized List getLog() {
        return log;
    }//getLog

    public synchronized void add(String toAdd) {
        try {
            while (front == tail & !isEmpty) {
                wait();
            }
            isEmpty = false;
            String forLog = "ordered " + toAdd;
            theArray[tail] = toAdd;
            storeInfo(forLog);

            tail++;
            frontOfBuffer = toAdd;
            size++;
            tail %= capacity;
            notifyAll();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

    }//add

    private synchronized void storeInfo(String toStore) {
        log.add(toStore);
    }//storeInfo

    public synchronized void leave() {
        try {
            if (isEmpty) {
                wait();
            }
            int temp = front++;
            frontOfBuffer = theArray[temp];
            theArray[temp] = null;
            storeInfo("shipped " + frontOfBuffer);
            front %= capacity;
            size--;
            isEmpty = front == tail;
            notifyAll();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }//leave

    public synchronized int getBufferSize() {
        return size;
    }

    public synchronized String getTop() {
        return theArray[front];
    }//getTop

    public synchronized String[] getToBeShippedList() {
        return theArray;
    }//getToBeShipped
}//Buffer
