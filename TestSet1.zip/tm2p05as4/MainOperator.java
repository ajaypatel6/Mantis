package assign4;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * Tamara McDiarmid Assignment #4 COSC 2P05 April 2018
 */

//main class that creates 2 gui (1 for ordering, 1 for shipping), also creates a shared array based buffer (FIFO)
public class MainOperator {

    private static Buffer buff;
    private static OrderGui o;
    private static ShipGui s;

    public MainOperator() {

        userEntry();
    }//constructor

    private void userEntry() {
        try {
            buff = new Buffer();
            o = new OrderGui(buff);
            Thread t = new Thread(o);
            t.start();
            s = new ShipGui(buff);
            Thread t2 = new Thread(s);
            t2.start();
            t.join();
            t2.join();
        } 
        catch (InterruptedException ex) {
            Logger.getLogger(MainOperator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//userEntry

    public static void main(String[] args) {
        MainOperator m = new MainOperator();
    }
}//MainOperator
