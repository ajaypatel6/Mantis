package assign4;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * Tamara McDiarmid 6148837 assignment #4 April 2018
 */
//This class used to save details of the ship/order to assign4 folder to a 
//file named "LogFile.txt"
public class FileWriter {

    private PrintWriter writer;
    private Buffer buff;
    private List log;

    public FileWriter(Buffer buff, List log) throws FileNotFoundException {
        this.buff = buff;
        this.log = log;
        try {
            writer = new PrintWriter("LogFile.txt", "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FileWriter.class.getName()).log(Level.SEVERE, null, ex);
        }
        writeDetails(writer, log);
        writer.close();
        System.exit(0);
    }

    //writes the details of the ship/order log along with orders still left to ship
    private void writeDetails(PrintWriter writer, List log) {
        for (int i = 0; i < log.size(); i++) {
            writer.println(log.get(i).toString());

        }
        writer.println("");
        writer.println("Orders left to be shipped: ");
        String[] toBeShipped = buff.getToBeShippedList();
        for (int i = 0; i < toBeShipped.length; i++) {
            if (toBeShipped[i] != null) {
                writer.println(toBeShipped[i]);
            }

        }

    }//writeDetails

}//FileWriter
