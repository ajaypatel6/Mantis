package assign4;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * Tamara McDiarmid 6148837 Assignment#4 cOSC 2P05 april 2018
 */

//this class provides a gui to user that has access to a shared buffer
//when there is room in the buffer the user can "order" them using the order button
//upon pressing quit button, logged data is written to a file LogFile.txt
public class OrderGui extends JFrame implements ActionListener, Runnable {

    private JTextField textFld;
    private JLabel label;
    private JButton oButton;
    private JButton qButton;
    private JPanel panel;
    private String order;
    private final Buffer buff;
    private boolean complete;
    private volatile boolean data;

    public OrderGui(Buffer b) {
        this.buff = b;
        fillForm();
    }

    private void hideFrame() {
        this.dispose();

    }//hideFrame

    private void fillForm() {
        this.setSize(250, 250);
        this.setTitle("ORDER");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        panel = new JPanel();
        this.add(panel);
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        label = new JLabel("Item: ");
        gc.gridx = 0;
        gc.gridy = 0;
        panel.add(label, gc);
        textFld = new JTextField(20);
        panel.add(textFld);
        gc.gridx = 1;
        gc.gridy = 0;
        oButton = new JButton("Order");
        qButton = new JButton("quit");
        panel.add(oButton, gc);
        gc.gridx = 2;
        gc.gridy = 0;
        panel.add(qButton, gc);
        oButton.addActionListener(this);
        qButton.addActionListener(this);
        this.setVisible(true);
    }//fillForm

    //hides the order button when the buffer is full
    public void hideButton() {
        oButton.setEnabled(false);
    }//hideButton

    //shows the order button when there is space in the buffer
    public void showButton() {
        oButton.setEnabled(true);
    }//showButton

    public String getItem() {
        return textFld.getText();
    }//getItem

    @Override
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
        if (source == qButton) {
            complete = true;
            hideFrame();
            List log = buff.getLog();
            try {
                FileWriter writer=new FileWriter(buff,log);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(OrderGui.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        }
        if (source == oButton) {
            order = textFld.getText();
            textFld.setText("");
            data = true;
        }
    }//actionPerformed

  

    @Override
    public void run() {
        while (!complete) {
            if (buff.getBufferSize() == 5) {
                hideButton();
            }
            if (buff.getBufferSize() < 5) {
                showButton();
            }
            if (data) {
                buff.add(order);
                data = false;
            }
        }
    }//run

}//OrderGui
