package assign4;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * Tamara McDiarmid 6148837 Assignment#4 cOSC 2P05 april 2018
 */

//this class provides a gui to user that has access to a shared buffer
//when items are avaiulable in the buffer the user can "ship" them using the ship button
//upon pressing quit button, logged data is written to a file LogFile.txt
public class ShipGui extends JFrame implements ActionListener, Runnable {

    private JTextField textFld;
    private JLabel label;
    private JButton sButton;
    private JButton qButton;
    private JPanel panel;
    private final Buffer buff;
    private boolean complete;
    private volatile boolean data;

    public ShipGui(Buffer b) {
        this.buff = b;
        fillForm();
    }

    private void fillForm() {
        this.setSize(250, 250);
        this.setTitle("SHIP");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocation(100, 100);
        panel = new JPanel();
        this.add(panel);
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        label = new JLabel("Item: ");
        gc.gridx = 0;
        gc.gridy = 0;
        panel.add(label, gc);
        textFld = new JTextField(20);
        panel.add(textFld);
        gc.gridx = 1;
        gc.gridy = 0;
        sButton = new JButton("ship");
        qButton = new JButton("quit");
        panel.add(sButton, gc);
        gc.gridx = 2;
        gc.gridy = 0;
        panel.add(qButton, gc);
        sButton.addActionListener(this);
        qButton.addActionListener(this);
        this.setVisible(true);
    }//fillForm

    private void hideFrame() {
        this.dispose();
    }//hideFrame

    @Override
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
        if (source == qButton) {
            complete = true;
            hideFrame();
            List log = buff.getLog();
            try {
                FileWriter writer = new FileWriter(buff, log);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(OrderGui.class.getName()).log(Level.SEVERE, null, ex);
            }
            complete = true;
        }
        if (source == sButton) {
            data = true;
        }
    }//actionPerformed

    //shows the ship button when there are items available in the buffer
    public void showButton() {
        sButton.setEnabled(true);
    }//showButton

    //hides the ship button when the buffer is empty
    public void hideButton() {
        sButton.setEnabled(false);
    }//hideButton

    @Override
    public void run() {
        while (!complete) {
            if (buff.getBufferSize() <= 0) {
                hideButton();
            }
            if (buff.getBufferSize() > 0) {
                textFld.setText(buff.getTop());
                showButton();
            }
            if (data) {
                buff.leave();
                data = false;
            }
        }
    }//run
}//ShipGui
