COSC 4P03 Assignment1
Curtis Penney / 5660569 / cp14lt@brocku.ca

Notes to the marker...

IDE Used: NetBeans
If you are unable to open the project in NetBeans for any reason, the class files are stored in the following filepath:
	.../4P03Assignment1\build\classes\pkg4p03assignment1


When running the program it will prompt asking which question to process, 1 2 3 will run the corresponding program. Any other input will exit the program.


When the programs are run they will open a dialog window to allow you to select a file to process. This window may appear in the background if you don't see it immediately.


The test files provided to as are stored in the same folder that this README.txt is located, they are: 
a1q1in.txt
a1q2in.txt
a1q3in.txt


When the program has processed the file you selected it will store the output in one of three text files (one for each question):
q1Output.txt
q2Output.txt
q3Output.txt
