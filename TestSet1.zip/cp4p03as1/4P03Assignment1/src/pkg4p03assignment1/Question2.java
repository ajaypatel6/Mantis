//Curtis Penney
//5660659
//cp14lt@brocku.ca
//
//COSC 4P03 - Assignment 1
//Question 2. d)

package pkg4p03assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JFileChooser;

public class Question2 {
    
    //Global Variables
    static PrintWriter writer;
    
    //Constructor
    public Question2() throws FileNotFoundException{
        AS1_Q2_PART_D();
    }//End constructor
    
    //********************************************//
    //**************QUESTION 2********************//
    //********************************************//
    
    //Function for Assignment 1, Question 2, Part D
    private static void AS1_Q2_PART_D() throws FileNotFoundException {
        
        int i, j, l, o; //For loop variables...
        int m, n, k;
        int e[];
        int x[];
        int a[][];
        int t[][][];
        
        
        //Reading the file time!
        JFileChooser fileSel;       //FileChooser object
        File inFile;                //File for reading
        Scanner fileScanner;        //Scanner to read file
        writer = new PrintWriter("q2Output.txt");
        
        //Selecting the file using JFileChooser
        System.out.println("Please select a file (note: The file chooser might have opened in the background...)");
        fileSel = new JFileChooser();
        
        //Handling in case the user selects no file
        if (fileSel.showOpenDialog(fileSel) == JFileChooser.APPROVE_OPTION) {
            inFile = fileSel.getSelectedFile();
            fileScanner = new Scanner(inFile);
            
            //Reading the number of executions
            m = fileScanner.nextInt();
            
            //Doing it m times
            for (i = 0; i < m; i++){
                
                //Reading the info from the file
                n = fileScanner.nextInt();
                k = fileScanner.nextInt();
                e = new int[k];
                x = new int[k];
                t = new int[n-1][k][k];
                a = new int [n][k];
                for (j = 0; j < k; j++){
                    e[j] = fileScanner.nextInt();
                }//End for
                for (j = 0; j < k; j++){
                    x[j] = fileScanner.nextInt();
                }//End for
                for (j = 0; j < n-1; j++){
                    for (l = 0; l < k; l++){
                        for (o = 0; o < k; o++){
                            t[j][l][o] = fileScanner.nextInt();
                        }//End for
                    }//End for
                }//End for
                for (j = 0; j < n; j++){
                    for (l = 0; l < k; l++){
                        a[j][l] = fileScanner.nextInt();
                    }//End for
                }//End for
            
                writer.println("Scenario: " + i);
                StartToEnd(n, k, e, x, t, a);//Calling the Dynamic Algorithm
                
            }//End for
            writer.close();
            
        }//End if
        
    }//End AS2_Q2_PART_D
    
     //Function which will do the computation
    private static void StartToEnd(int n, int k, int e[], int x[], int t[][][], int a[][]) throws FileNotFoundException{

        int i, j, jmin, minVal, minIndex, temp;
        int StartTo[][] = new int[n][k];        //Array to store the cost to each cell
        int route[][] = new int[n][k];          //Array to store the route taken to each cell
        
        //For every cell
        for (i = 0; i < n; i++) {
            for (j = 0; j < k; j++) {
                
                //Only for the first nodes
                if (i == 0) {
                    StartTo[i][j] = e[j] + a[i][j];
                    route[i][j] = -1;
                } else {
                
                    minVal = Integer.MAX_VALUE;
                    minIndex = -1;
                    
                    //Determining the minimal of the prior step.
                    for (jmin = 0; jmin < k; jmin++) {
                        temp = StartTo[i-1][jmin] + t[i-1][jmin][j] + a[i][j];  
                        if (temp < minVal) {
                            minVal = temp;
                            minIndex = jmin;
                        }//End if
                    }//End for
                    
                    //Setting the value
                    StartTo[i][j] = minVal;
                    route[i][j] = minIndex;
                
                }//End if
                
            }//End for
        }//End For
        
        //Tables have been filled, time for the final step...
        minVal = Integer.MAX_VALUE;
        minIndex = -1;
        
        //Determining the best of the last steps to take
        for (i = 0; i < k; i++) {
            temp = StartTo[n-1][i] + x[i];
            if (temp < minVal) {
                minVal = temp;
                minIndex = i;
            }//End if
        }//End for
        
        //Writing to the file
        writer.println("Minimum Time: " + minVal);
        
        //Ensuring the route is printed in non-reversed order
        String routeReverse = ""+minIndex;
        j = minIndex;
        for (i = n-1; i >= 1; i--) {
            j = route[i][j];
            routeReverse = routeReverse + ", " + j;
        }//End for
        
        writer.print("Route Taken: ");
        for (i = routeReverse.length()-1; i >= 0; i--) {
            writer.print(routeReverse.charAt(i));
        }//End for
        writer.println();

    }//End StartToEnd

}//End Question2
