//Curtis Penney
//5660659
//cp14lt@brocku.ca
//
//COSC 4P03 - Assignment 1
//Question 3. c)

package pkg4p03assignment1;

//Class used to combine a task with the step it occurs at
public class Question3Task implements Comparable {
    
    private final int taskCost;
    private final int taskStep;
    private final int taskOption;
    
    //Constructor
    public Question3Task(int cost, int step, int option){
        taskCost = cost;
        taskStep = step;
        taskOption = option;
    }//End Constructor
    
    @Override
    public int compareTo(Object inputTask) {
        Question3Task otherTask = (Question3Task)inputTask;
        int otherCost = otherTask.getCost();
        return this.getCost() - otherCost;
    }//End compare
    
    public int getCost(){
        return taskCost;
    }//End getCost
    
    public int getStep() {
        return taskStep;
    }//End getStep
    
    public int getOption() {
        return taskOption;
    }//End getStep
    
}//End Question3Task