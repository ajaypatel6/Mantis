//Curtis Penney
//5660659
//cp14lt@brocku.ca
//
//COSC 4P03 - Assignment 1
//Question 1. d)

package pkg4p03assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JFileChooser;

public class Question1 {
    
    //Constructor
    public Question1() throws FileNotFoundException {
        AS1_Q1_PART_D();
    }//End constructor
    
    
    //********************************************//
    //**************QUESTION 1********************//
    //********************************************//
    
    //Function for Assignment 1, Question 1, Part D
    private static void AS1_Q1_PART_D() throws FileNotFoundException {
        
        //Variable Declaration
        JFileChooser fileSel;       //FileChooser object
        File inFile;                //File for reading
        Scanner fileScanner;        //Scanner to read file
        int numEvents;              //The number of events to score for
        int corAnswer[];            //Array to hold the correct answer
        int stuAnswer[];            //Array to hold the student's answer
        int i, stuCount;            //Counters
        
        //Selecting the file using JFileChooser
        System.out.println("Please select a file (note: The file chooser might have opened in the background...)");
        fileSel = new JFileChooser();
        
        //Handling in case the user selects no file
        if (fileSel.showOpenDialog(fileSel) == JFileChooser.APPROVE_OPTION) {
            inFile = fileSel.getSelectedFile();
            fileScanner = new Scanner(inFile);
            
            //Reading the file
            numEvents = fileScanner.nextInt();
            corAnswer = new int[numEvents];
            stuAnswer = new int[numEvents];

            //Filling the correct answers array
            for (i = 0; i < numEvents; i++){
                corAnswer[i] = fileScanner.nextInt();
            }//End for
            
            //Opening the textfile to write to.
            PrintWriter writer = new PrintWriter("q1Output.txt");

            //Reading and processing each student
            i = 0;
            stuCount = 0;
            while (fileScanner.hasNext()){
                stuAnswer[i] = fileScanner.nextInt();
                i++;
                
                //Once we've read a whole students info, process and reset the array
                if (i >= numEvents){
                    stuCount++;
                    writer.print("Student " + stuCount + " receives a score of: " + lcsMark(corAnswer, stuAnswer));
                    writer.println();
                    i = 0;                  
                }//End if 
            }//End while
            writer.close();
        } //End if
        
    }//End AS1_Q1_PART_D
    //Method which is used to get the length of the LCS of the two inputted arrays
    private static int lcsMark(int correctArr[], int studentArr[]){
        
        int arrLength = correctArr.length;                          //Storing the length of the arrays (The two arrays will always have the same number)
        int scoreMatrix[][] = new int[arrLength+1][arrLength+1];    //Defining the matrix used to store the values
        int i, j;                                                   //Iterators for loops
        
        //Initializing the edges of the matrix
        for (i = 0; i < arrLength+1; i++) {
            scoreMatrix[i][0] = 0;
            scoreMatrix[0][i] = 0;
        }//End for
        
        //Starting the actual work...
        for (i = 1; i < arrLength+1; i++) {
            for (j = 1; j < arrLength+1; j++) {
                
                //Handling our two cases
                if (correctArr[i-1] == studentArr[j-1]) {
                    scoreMatrix[i][j] = scoreMatrix[i-1][j-1] + 1;
                } else {
                    scoreMatrix[i][j] = Math.max(scoreMatrix[i-1][j], scoreMatrix[i][j-1]);
                }//End if
                
            }//End for
        }//End for
        
        return scoreMatrix[arrLength][arrLength];
    }//End lcsMark

}//End Question1
