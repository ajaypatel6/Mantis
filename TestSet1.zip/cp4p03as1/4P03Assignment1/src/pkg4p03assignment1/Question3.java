//Curtis Penney
//5660659
//cp14lt@brocku.ca
//
//COSC 4P03 - Assignment 1
//Question 3. c)

package pkg4p03assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import javax.swing.JFileChooser;

public class Question3 {
    
    //Global Variables
    static PrintWriter writer;
    
    //Constructor
    public Question3() throws FileNotFoundException {
        AS1_Q3_PART_D();
    }//End Constructor
    
    //********************************************//
    //**************QUESTION 3********************//
    //********************************************//
    
    //Function for Assignment 1, Question 3, Part D
    private static void AS1_Q3_PART_D() throws FileNotFoundException {
         
        int i, j, l; //For loop variables...
        int m, n, k, e, x;
        int t[];
        int a[][];
        
        
        //Reading the file time!
        JFileChooser fileSel;       //FileChooser object
        File inFile;                //File for reading
        Scanner fileScanner;        //Scanner to read file
        writer = new PrintWriter("q3Output.txt");
        
        //Selecting the file using JFileChooser
        System.out.println("Please select a file (note: The file chooser might have opened in the background...)");
        fileSel = new JFileChooser();
        
        //Handling in case the user selects no file
        if (fileSel.showOpenDialog(fileSel) == JFileChooser.APPROVE_OPTION) {
            inFile = fileSel.getSelectedFile();
            fileScanner = new Scanner(inFile);
            
            //Reading the number of executions
            m = fileScanner.nextInt();
            
            //Doing it m times
            for (i = 0; i < m; i++){
                
                //Reading the info from the file
                n = fileScanner.nextInt();
                k = fileScanner.nextInt();
                e = fileScanner.nextInt();
                x = fileScanner.nextInt();
                t = new int [n-1];
                a = new int [n][k];
                for (j = 0; j < n-1; j++){
                    t[j] = fileScanner.nextInt();
                }//End for
                for (j = 0; j < n; j++){
                    for (l = 0; l < k; l++){
                        a[j][l] = fileScanner.nextInt();
                    }//End for
                }//End for
            
                writer.println("Scenario: " + i);
                matroid(n, k, e, x, t, a);//Calling the Matroid algorithm
                
            }//End for
            writer.close();
            
        }//End if
        
    }//End AS2_Q3_PART_D
    
    //Function which will process the instance of the problem
    private static void matroid(int n, int k, int e, int x, int t[], int a[][]) {
        
        int i, j;
        
        //Array to store the task we take at each step (A in the Matroid)
        int stepTaken[] = new int[n];  
        for (i = 0; i < n; i++) {
            stepTaken[i] = -1;      //Initializing the array to -1
        }//End for
        
        //Initializing the arrayList of all tasks (S for the Matroid)
        ArrayList<Question3Task> matroidTasks = new ArrayList<>();
        for (i = 0; i < n; i++){
            for (j = 0; j < k; j++){
                matroidTasks.add(new Question3Task(a[i][j], i, j));
            }//End for
        }//End for
        
        //Sorting the tasks on their the time it takes to complete them
        Collections.sort(matroidTasks);

        //For each task
        for (Question3Task task: matroidTasks){
            //If we havent already chosen a task for this step
            if (stepTaken[task.getStep()] == -1){
                stepTaken[task.getStep()] = task.getOption();   //Take this task  
            }//End if
        }//End for

        //Summing the overall cost
        int outVal = 0;                                                 //Setting out output value
        for(i = 0; i < n; i++) outVal += a[i][stepTaken[i]];            //Adding the task times
        outVal += e + x;                                                //Adding the entry and exit times
        for(i = 0; i < n-1; i++) outVal += t[i];                        //Adding the travel time
        
        //Output Time
        writer.println("Minimum time: " + outVal);
        for(i = 0; i < n; i++){
            writer.println("Step " + (i+1) + ": " + (stepTaken[i] + 1));
        }//End for
        writer.println();
        
    }//End matroid
    
}//End Question3


