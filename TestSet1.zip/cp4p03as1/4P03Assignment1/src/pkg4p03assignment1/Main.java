//Curtis Penney
//5660659
//cp14lt@brocku.ca
//
//COSC 4P03 - Assignment 1
//Question 1. d)

package pkg4p03assignment1;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) throws FileNotFoundException {
        
        System.out.println("COSC 4P03 Assignment 1");
        
        boolean whileBool = true;
        while (whileBool) {
            System.out.print("Which question do you want to run? (1, 2, 3): ");
            String questionChoice = new Scanner( System.in ).nextLine();
            switch (questionChoice) {
                case "1":
                    System.out.println("COSC 4P03 Assignment 1 - Question 1. d)");
                    new Question1();
                    System.out.println("Output has been saved to q1Output.txt");
                    break;
                case "2":
                    System.out.println("COSC 4P03 Assignment 1 - Question 2. d)");
                     new Question2();
                     System.out.println("Output has been saved to q2Output.txt");
                    break;
                case "3":
                    System.out.println("COSC 4P03 Assignment 1 - Question 3. d)");
                    new Question3();
                    System.out.println("Output has been saved to q3Output.txt");
                    break;
                default:
                    System.out.println("Exiting.");
                    whileBool = false;
                    break;
            }//End switch
            System.out.println("Complete.");
            System.out.println();
        }//End while

    }//End constructor

}//End main
