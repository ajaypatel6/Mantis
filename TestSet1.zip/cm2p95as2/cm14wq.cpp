#include <iostream>
#include <string>
#include <list>

//Cesar Moreno 5727722
//Lab Exercise 2

int main(){
	
	//Task #1:
	int stNum = 2135754;

	int modifiedStNum = 0;
	int finalID = 0;

	int digit;
	int tempDigit;

	while (stNum > 0){

		digit = stNum%10;

		if (digit%2 == 0){
			//std::cout<<"Even digit"<<std::endl;

			digit = digit/2;

			//std::cout<<"Digit Transformation: "<<digit<<std::endl;

			modifiedStNum = digit + (modifiedStNum * 10);
			//std::cout<<"New Student ID so far: "<<modifiedStNum<<std::endl;

		}

		else{
			//std::cout<<"Odd digit"<<std::endl;
			digit = (digit * 2);
			//std::cout<<"Digit Transformation: "<<digit<<std::endl;
			if (digit >= 10){

				digit = digit%10;

				//std::cout<<"Number bigger than 10 was reduced to: "<<digit<<std::endl;

				modifiedStNum = digit + (modifiedStNum * 10);
				//std::cout<<"New Student ID so far: "<<modifiedStNum<<std::endl;
			}
			else{

				modifiedStNum = digit + (modifiedStNum * 10);
				//std::cout<<"New Student ID so far: "<<modifiedStNum<<std::endl;
			}
		}

		stNum /= 10;
	}

	//After modifying the digits of the Student ID, the final number is in reverse.
	//With this in mind, we apply the above process to obtain the Student ID in the correct form:

	int tempFinal = modifiedStNum;
	//std::cout<<"TEMP FINAL: "<<tempFinal<<std::endl;

	while (tempFinal > 0){

		tempDigit = tempFinal%10;
		finalID = tempDigit + (finalID * 10);

		//std::cout<<"TEMP: "<<finalID<<std::endl;
		
		tempFinal /= 10;
	}

	std::cout<<finalID<<std::endl;

////////////////////////////////////////////////////////////////////////////////////////////////////////

	//Task #2:
	int monkeys;
	std::cout<<"How many monkeys do I have? " ;
	std::cin>>monkeys;
	
	monkeys>1000000?(std::cout<<"I have " << (((double)monkeys)/1000000) << " million monkeys"<<std::endl ):std::cout<<"I have " << monkeys <<(monkeys > 1? " monkeys":" monkey")<<std::endl;

////////////////////////////////////////////////////////////////////////////////////////////////////////	

	//Task #3:
	int choice1,choice2;
	std::cout<<"Do you have room for tiramisu? (1:yes, 0:no)"; std::cin>>choice1;
	std::cout<<"Do you actually like tiramisu? (1:yes, 0:no)"; std::cin>>choice2;
	if (choice1){
		if (choice2){
			std::cout<<"Ready, willing, and able to enjoy tiramisu!\n";
		}
	}
	else{
			std::cout<<"It doesn't matter if I like it or not, I don't have room for dessert!\n";
		}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
