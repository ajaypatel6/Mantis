
package search;

/**
 *
 * @author Andrew Folkerson StNum #5764105
 * Date 10/12/2017
 * This class creates an individual node to enable the implementation of 
 * a binary
 * tree structure. It points to two other nodes as well as to a subtree 
 * beneath it.
 * Each node contains a pointer to two other nodes beside it, a pointer to the
 * subnode beneath it, as well as a left and right tag to indicate whether the 
 * nature of the pointers to the nodes beside it are normal connections or 
 * threads,
 * and lastly the name of a student in the COSC 2P03 course.
 */
public class Node {
    public Node right;// the right pointer
    public Node left;// the left pointer
    public Node2 down;// the pointer to the subtree
    public String name;// the name stored in the node
    public boolean ltag, rtag;// the left and right tags
    
//This constructor initializes the nodes and their variables.    
    public Node (String n, Node r, Node l, Node2 d, boolean rt, boolean lt){
        right =r;
        left = l;
        down = d;
        name = n;
        ltag = lt;
        rtag = rt;
        
                
    }//constructor
    
}//Node
