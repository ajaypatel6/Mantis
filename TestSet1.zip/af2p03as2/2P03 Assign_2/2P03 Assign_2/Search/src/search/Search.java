
package search;

import BasicIO.*;
import Media.*;
import java.util.Stack;

/**
 *
 * @author Andrew Folkerson StNum#5764105
 * Date: 10/12/2017
 * This class imports the class list from a file and creates a tree structure
 * out of it. It enables the user to traverse the 
 * structure in a variety of ways
 * and prints the results of each traversal to a basicform GUI.
 */
public class Search {
    private Node p;// a node pointer
    private Node root;// the root node
    private ASCIIDataFile file;// the file for the data to be imported from
    private BasicForm  form;//the form for the outputs to be written to
    private Stack      s;// a stack for sot iterative traversal
        
/** This constructor sets up the basicform and enables the user to call as 
 many traversals as he/she would like.*/    
    public Search(){
        s = new Stack();
        boolean subtrees = false;
        form = new BasicForm("PreOrder T","PostOrder T", "InOrder T","SOT",
                "Build Subtrees", "InOrder with Subtrees","SOT with Subtrees", 
                "BONUS","Exit");
        file = new ASCIIDataFile();
        root = new Node(file.readString(), null, null, null, true, true);
        setUpForm();
        load();
        form.writeString("Output","Tree Loaded Successfully");
        for(;;){
            int button = form.accept();
            form.clearAll();
            if(button == 0){
                prePrint(root);
            }
            if(button == 1){
                postPrint(root);
            }
            if(button == 2){
                inOrderPrint(root);
            }
            if(button == 3){
                sot(root);
            }
            if(button==4){
                if(!subtrees){
                    addSubTrees(root);
                    form.writeString("Subtrees added successfully!");
                    subtrees = true;
                }
                else{
                    form.writeString("Subtrees already built");
                }
            }
            if(button==5){
                if(subtrees)
                    printFullTrees(root);
                else
                    form.writeString("Please add subtrees before attempting "
                            + "to print them");
            }
            if(button==6){
                if(subtrees)
                    sotFullTrees(root);
                else
                   form.writeString("Please add subtrees before attempting "
                           + "to print them"); 
            }
            if(button==7){
                if(subtrees)
                    lnkInversionFullTrees(root);
                else
                    form.writeString("Please add subtrees before attempting "
                            + "to print them");
            }
            if(button==8){
                
                break;
            }
        }  
        file.close();
        form.close();
}//constructor
    
//This method sets up the basicform    
    private void setUpForm(){
        form.addTextArea("Output","Output");  
    }//setUpForm
    
//This method loads the data into the larger exterior tree    
    private void load(){
        for(;;){
            p = root;
            Node q;
            String name = file.readString();
            if(file.isEOF())break;
            for(;;){
                if(name.compareTo(p.name)<0 && p.ltag ==false){
                    p=p.left;
                    continue;
                }
                if(name.compareTo(p.name)>0 && p.rtag==false){
                    p=p.right;
                    continue;
                }
                if(name.compareTo(p.name)<0&& p.ltag == true){
                    q=p.left;
                    p.ltag = false;
                    p.left = new Node(name,p, q, null, true, true);
                    break;
   
            }
                if(name.compareTo(p.name)>0&& p.rtag==true){
                    q = p.right;
                    p.right = new Node(name,q, p, null, true, true );
                    p.rtag = false;
                    break;
                }
                
            }
            
        }
        
    }//load
    
//This method executes a preorder traversal and prints the results.    
    private void prePrint(Node p){
        form.writeString(p.name);
        form.newLine();
        if(p.left != null && !p.ltag){
            prePrint(p.left);
        }
        if(p.right !=null && !p.rtag){
            prePrint(p.right);
        }
        
    }//prePrint
    
//This method executes a postorder traversal and prints the results    
    private void postPrint(Node p){
        if(p.left != null && !p.ltag){
            postPrint(p.left);
        }
        if(p.right !=null && !p.rtag){
            postPrint(p.right);
        }
        form.writeString(p.name);
        form.newLine();
        
    }//postPrint
    
//This method executes an inorder traversal and prints the results    
    private void inOrderPrint(Node p){
        if(p.left != null && !p.ltag){
            inOrderPrint(p.left);
        }
        form.writeString("Output",p.name);
        form.newLine();
        if(p.right !=null && !p.rtag){
            inOrderPrint(p.right);
        }
        
        
    }//inOrderPrint
    
/*This method iteratively traverse the tree using threads and prints 
    an sot output*/    
    private void sot(Node p){
        while(p.left!=null){
            p = p.left;
        }
        form.writeString(p.name);
        form.newLine();
        while(p!=null){
            if(p.rtag){
                p=p.right;
                if(p==null)return;
                form.writeString(p.name);
                form.newLine();
        }
            else{
                p=getSuccessor(p);
                if(p==null)return;
                form.writeString(p.name);
                form.newLine();
        }
        }
        
    }//sot
    
//This method returns the successor to an inputted node    
    private Node getSuccessor(Node p){
        if(p.right!=null){
            p=p.right;
            while(p.left!=null & !p.ltag){
                p=p.left;
        }
            return p;
        }
        else{
            return null;
        }
        
    }//getSuccessor
    
//This method adds subtrees to the larger tree structure    
    private void addSubTrees(Node p){
        Node2 q;
        char[] letters = p.name.toCharArray();
        p.down = new Node2 (letters[0], 1, null, null, false);
        q = p.down;
        for(int i=1; i<letters.length; i++){
            q=p.down;

            if(letters[i]>='A' & letters[i] <='Z' | (letters[i]>='a' & 
                    letters[i] <='z')){
                for(;;){
                    letters[i]= Character.toUpperCase(letters[i]);
                    if(letters[i]<q.letter & q.left!=null){
                        q = q.left;
                    }
                    if(letters[i] > q.letter & q.right !=null){
                        q = q.right;
                    }
                    if(letters[i] < q.letter & q.left == null){
                        q.left = new Node2(letters[i], 1, null, null, false);
                        break;
                    }
                    if(letters[i] > q.letter & q.right == null){
                        q.right = new Node2 (letters[i], 1, null, null, false);
                        break;
                    }
                    if(letters[i] == q.letter){
                        q.occurences ++;
                        break;
                    }
                }
                    
                    
            }
        }
        if(p.left != null && !p.ltag){
            addSubTrees(p.left);
        }
        if(p.right !=null && !p.rtag){
            addSubTrees(p.right);
        }
        
        
    }//addSubTrees
    
/*This method performs an inorder traversal on the tree nodes and 
    calls the method to traverse their respective
    subtrees and prints the result using recursion.*/    
    private void printFullTrees(Node p){
        if(p.left != null && !p.ltag){
            printFullTrees(p.left);
        }
        form.writeString("Output", p.name);
        form.newLine();
        printSubTrees(p.down);
        if(p.right!=null && !p.rtag){
            printFullTrees(p.right);
        }
        
        
    }//printFullTrees
    
/*This method recursively traverses a subtree inorder and prints the result*/    
    private void printSubTrees(Node2 p){
        if(p.left != null){
            printSubTrees(p.left);
        }
        form.writeLine("  -"+p.letter + "=" + p.occurences);
        if(p.right != null){
            printSubTrees(p.right);
        }
    }//printSubTrees
    
/*This method iteratively traverse the outer structure in sot and callse the 
    method to do the same on the respective subtrees of each node*/    
    private void sotFullTrees(Node p){
        while(p.left!=null){
            p = p.left;
        }
        form.writeString(p.name);
        form.newLine();
        sotSubTrees(p.down);
        while(p!=null){
            if(p.rtag){
                p=p.right;
                if(p==null)return;
                form.writeString(p.name);
                form.newLine();
                sotSubTrees(p.down);
        }
            else{
                p=getSuccessor(p);
                if(p==null)return;
                form.writeString(p.name);
                form.newLine();
                sotSubTrees(p.down);
        }
        }
        
    }//sotFulTrees
    
//This method uses a stack to iteratively sot traverse the subtrees    
    private void sotSubTrees(Node2 p){
        Node2 q = p;
        s.push(q);
        Node2 a = null;
        for(;;){
            while(q!=null&&q.left!=null){
                q=q.left;
                s.push(q);        
        }
            if(!s.isEmpty()){
                a = (Node2) s.pop();
                form.writeLine("  -"+a.letter + "=" + a.occurences);
            }
            if(a.right!=null){
                q = a.right;
                s.push(q);
            }
            if(s.isEmpty()){
                return;
            }
            
            
            
        
    }
    }//sotSubTrees
    
    
/*This method iteratively traverses the outer structure in sot and calls the 
    method to iteratively traverse the subtrees using link inversion*/    
    private void lnkInversionFullTrees(Node p){
        while(p.left!=null){
            p = p.left;
        }
        form.writeString(p.name);
        form.newLine();
        lnkInversionSubTrees(p.down);
        while(p!=null){
            if(p.rtag){
                p=p.right;
                if(p==null)return;
                form.writeString(p.name);
                form.newLine();
                lnkInversionSubTrees(p.down);
        }
            else{
                p=getSuccessor(p);
                if(p==null)return;
                form.writeString(p.name);
                form.newLine();
                lnkInversionSubTrees(p.down);
        }
        }
    }//lnkInversionFullTrees
    
//This method uses link inversion to iteratively traverse the subtrees.    
    private void lnkInversionSubTrees(Node2 p){

       Node2 prev = null;
       Node2 pres = p;
       Node2 next;
       
       loop1:for(;;){
           next = pres.left;
           if(next!=null){
            pres.left = prev;
	    prev = pres;
	    pres = next;
            continue;
	   
        }
           loop2:for(;;){
               form.writeLine("  -"+pres.letter + "=" + pres.occurences);
               next = pres.right;
               if(next!=null){
                    pres.flag = true;
                    pres.right = prev;
                    prev = pres;
                    pres = next;
                    continue loop1;
           }
               loop3:for(;;){
                if(prev == null)return;
                if(!prev.flag){
                    next = prev.left;
                    prev.left = pres;
                    pres = prev;
                    prev = next;
                    continue loop2;
            }  
               if(prev.flag){
                    prev.flag = false;
                    next = prev.right;
                    prev.right = pres;
                    pres = prev;
                    prev = next;
                   }
               } 
           }
       }
    }//lnkInversionSubTrees    

    public static void main(String[] args) {Search s = new Search();    }
    
}//Search
