
package search;

/**
 *
 * @author Andrew Folkerson StNum #5764105
 * 10/12/2017
 * This class creates the nodes for the subtrees which exist under the nodes
 * of the main tree. It stores the letter for each letter of the name of the 
 * student, the number of times each letter occurs, and a boolean for 
 * assisting
 * in traversing the tree structure using link inversion.
 */

public class Node2 {
    public Node2 right;//the right pointer
    public Node2 left;//the left pointer
    public int occurences;// the number of times the letter occurs
    public char letter;//the letter
    public boolean flag;// a flag to indicate the direction of the descent
    
//This constructor initializes the subnodes and their variables.
    public Node2 (char n, int o, Node2 r, Node2 l, boolean f){
        right = r;
        left = l;
        occurences = o;
        letter = n;
        flag = f;
       
        
                
    }//constructor
    
}//Node2
