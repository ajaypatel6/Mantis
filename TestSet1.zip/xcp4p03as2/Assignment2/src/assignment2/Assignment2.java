//COSC 4P03 Assignment 2
//Curtis Penney

package assignment2;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Scanner;

public class Assignment2 {
    
    static long startTime, endTime;
    static int depth = 0;
    static int count = 0;
    static final int MAX_N = 10;
    static ArrayList<int[][]> DistinctSquares = new ArrayList<>();
    
    static PrintWriter textFile;
    static Scanner innput = new Scanner(System.in);  // Reading from System.in
    
    
    public static void main(String[] args) throws IOException {
        
        System.out.println("COSC 4P03 Asignment 2");
        
        int temp;
        int theInput = -1;

        /*
        //For loop method
        for (int i = 3; i < 16; i ++){
            
            //Initializing the txt file to write to
            textFile =  new PrintWriter(new FileWriter("output" + i + ".txt")); 

            //Recording the starting time
            startTime = System.nanoTime();

            //Calling the algorithm
            temp = SolveLatinSquare(i);

            //Recording the completion time
            endTime = System.nanoTime();

            //Printing
            System.out.println("Printing to output" + i + ".txt");
            printWrite("For n = " + i + ": There are " + temp + " unique solutions.");
            printWrite("Total Time Elapsed (milliseconds): " + ((endTime - startTime)/1000000));
            printWrite("First four equivalent squares printed to the txt file.");

            //Printing the first four squares (if there are 4)
            for (int j = 0; j < DistinctSquares.size(); j++){
                if (j > 3) break;   //Stopping after 4
                outSqur(DistinctSquares.get(j), i);
            }//End for

            //Closing the txt file
            textFile.close();
            
        }//End for*/
        
        
        //*
        //USER theInput METHOD
        //Looping until the user specifies
        while (theInput != 0){
            System.out.println("Please enter the n you wish to compute for (0 to stop)");
            
            //Catching theInput errors
            try{                
                //Getting the user's input
                theInput = innput.nextInt();
                
                //If the theInput is a meaningful n
                if (theInput != 0){
                    
                    //Initializing the txt file to write to
                    textFile =  new PrintWriter(new FileWriter("output" + theInput + ".txt")); 
                    
                    //Recording the starting time
                    startTime = System.nanoTime();
                    
                    //Calling the algorithm
                    temp = SolveLatinSquare(input);
                    
                    //Recording the completion time
                    endTime = System.nanoTime();
                    
                    //Printing
                    System.out.println("Printing to output" + theInput + ".txt");
                    printWrite("For n = " + theInput + ": There are " + temp + " unique solutions.");
                    printWrite("Total Time Elapsed (milliseconds): " + ((endTime - startTime)/1000000));
                    printWrite("First four equivalent squares printed to the txt file.");
                    
                    //Printing the first four squares (if there are 4)
                    for (int i = 0; i < DistinctSquares.size(); i++){
                        if (i > 3) break;   //Stopping after 4
                        outSqur(DistinctSquares.get(i), input);
                    }//End for
                    
                    //Closing the txt file
                    textFile.close();
                    
                }//End if
                
            } catch (Exception e){
                System.out.println("Inserted value not an integer.");
                innput.next(); //Clears the inputted value from System.in
            }//End Try Catch
            
        }//End while
        //*/
    
    }//End main
    
    //Prints to the Console AND outputs to the text file
    private static void printWrite(String msgToWrite){
        System.out.println(msgToWrite);
        textFile.println(msgToWrite);
    }//End printWrite
    
    //Generates the base square to solve on
    //Base square is generated in Normal Form to reduce the number of squares we have to generate
    private static int SolveLatinSquare(int dim){
        int outVal;
        
        //Initializing the empty square of dimensions Dim        
        int [][] baseSquare = new int[dim][dim];
        for (int i =0; i < dim; i++){
            for(int j = 0; j < dim; j++) {
                baseSquare[i][j] = 0;
            }//End for
        }//End for
        
        //Putting into normal form
        for(int j = 0; j < dim; j++) {
            baseSquare[0][j] = j+1;
            baseSquare[j][0] = j+1;
        }//End for
        
        //Starting the call sequence
        DistinctSquares.clear();
        genTheThing(dim, baseSquare, true, 1, 1);
        outVal = DistinctSquares.size();

        return outVal;
    }//End SolveLatinSquare
    
    //Function used to print the square for the output
    private static void outSqur(int [][] inSquare, int dim){
        for (int x = 0; x < dim; x++){
            for (int y = 0; y < dim; y++){
                textFile.print(inSquare[x][y] + ", ");
            }//End for
            textFile.println();
        }//End for
        textFile.println();
    }//End printSquare
    
    //Beginning calculation for the given dimension
    private static void genTheThing(int dim, int[][] currSquare, boolean first, int prevRow, int prevCol){
        
        boolean [] candy;
        int [][] nextSqur;
        int currRow = 0, currCol = 0;
        boolean found;
        
        //printSquare(currSquare, dim, -1, -1);
        
        //Ensuring Deep copy of the array
        nextSqur = ultraGo(currSquare);
        
        //The square is already done
        if (isSquareComplete(dim, currSquare)) {
            
            //Compare with already found solutions...
            //printSquare(currSquare, dim, -1, -1);
            KilroyWasHere(dim, currSquare);
            
        } else {
            //Recurse deeper!

            //Finding the next empty cell
            found = false;
            for (int i = 1; i < dim; i++){
                for (int j = 1; j < dim; j++){
                    if (nextSqur[i][j] == 0){
                        currRow = i;
                        currCol = j;
                        found = true;
                        break;
                    }//End if
                }//End for
                if (found) break;
            }//End for
            
            //Getting the candy
            candy = getcandy(dim, nextSqur, currRow, currCol);
            
            //For each candidate
            for (int i = 0; i < dim; i++){
                
                //If the candidate is true
                if (candy[i]){

                    //Set the cell to teh candidate
                    nextSqur[currRow][currCol] = i+1;
                    
                    //Recurse
                    genTheThing(dim, nextSqur, false, currRow, currCol);
                    
                }//End if
            }//End for
            
        }//End if        
    }//End genTheThing
    
    //Function which performs the equivalency testing
    private static void KilroyWasHere(int dim, int [][] inSquare){
        
        //Converting the square to normal form
        int [][] tempSquare = ultraGo(inSquare);
        //convertNormalForm(inSquare, dim);
        
        //If this normal form is already in our list, continue
        //If not add it then continue
        if (DistinctSquares.isEmpty()) {
            
            //List is empty...
            DistinctSquares.add(ultraGo(tempSquare));
            
        } else {
            
            //Check if its already in there..
            boolean same = false;
            for (int i = 0; i < DistinctSquares.size(); i++){
                if (noThisIsNotaMethod(DistinctSquares.get(i), tempSquare, dim)){
                    same = true;
                    break;
                }//End if
            }//End for

            //It isnt already in there
            if (!same){
                
                //Check if its a permutation of one of the existing ones
                boolean perm = false;
                for (int i = 0; i < DistinctSquares.size(); i++){
                    if (thereBeNoWayOut(DistinctSquares.get(i), tempSquare, dim)){
                        perm = true;
                        break;
                    }//End if
                }//End for

                //It isnt already in there
                if (!perm){
                    DistinctSquares.add(ultraGo(tempSquare));
                }//End if
                
            }//End if
        }//End if
    }//End KilroyWasHere
    
    //Returns true if the squares are equal
    private static boolean noThisIsNotaMethod(int [][] squareA, int [][] squareB, int dim){
        
        //Checking if they are equivalent
        for (int i = 0; i < dim; i++){
            for (int j = 0; j < dim; j++){
                
                //If not, return false
                if (squareA[i][j] != squareB[i][j]){
                    return false;
                }//End if
                
            }//End for
        }//End for
        
        //They are equal, return true
        return true;
        
    }//End noThisIsNotaMethod
    
    //Checks if squareA is a permutation of squareB by brute force
    private static boolean thereBeNoWayOut(int [][] squareA, int [][] squareB, int dim){
        int [][] testSquare;
         
        //IDEA
        //Giving each row a chance to be the primary row for the Normal form
        //Original idea was to also give each column a chance, however each column corresponds to a row
        //Because when you organize it onto a specific row, there is only one column arrangement that works
        
        //Allowing each Row to be the Normal Row
        for (int i = 0; i < dim; i++){
            testSquare = rowsuponrows(squareB, dim, i);
            //If any of the permuted squares are equivalent, then return true
            if (noThisIsNotaMethod(testSquare, squareA, dim)){
                return true;
            }//End if
        }//End for

        return false;
        
    }//End thereBeNoWayOut
    
    //Permutes the square with the given rows and cols
    private static int[][] perm(int [][] square, int col1, int col2, int row1, int row2, int dim){
        int[][] outSquare = ultraGo(square);
        outSquare = permRow(outSquare, row1, row2, dim);
        outSquare = allColsBeHEre(outSquare, col1, col2, dim);
        return outSquare;
    }//End perm
    
    //Permutes the selected rows
    private static int[][] permRow(int [][] square, int row1, int row2, int dim){
        int [][] outSquare = ultraGo(square);
        
        //No perm
        if (row1 == row2){
            return outSquare;
        }//End if
        
        for (int i = 0; i < dim; i++){
            outSquare[row1][i] = square[row2][i];
            outSquare[row2][i] = square[row1][i];
        }//End for
        
        return outSquare;
    }//End allColsBeHEre
    
    //Permutes the selected columns
    private static int[][] allColsBeHEre(int [][] square, int col1, int col2, int dim){
        int [][] outSquare = ultraGo(square);
        
        //No perm
        if (col1 == col2){
            return outSquare;
        }//End if
        
        for (int i = 0; i < dim; i++){
            outSquare[i][col1] = square[i][col2];
            outSquare[i][col2] = square[i][col1];
        }//End for
        return outSquare;
    }//End allColsBeHEre
    
    //Returns true if the square is fully filled
    private static boolean isSquareComplete(int dim, int[][] inSquare){
        for (int i = 0; i < dim; i++){
            for (int j = 0; j < dim; j++){
                if (inSquare[i][j] == 0){
                    return false;
                }//End if
            }//End for
        }//End for
        return true;
    }//End isSquareComplete
    
    //Gets the possible value that can go in the given coordinates
    private static boolean [] getcandy(int dim, int[][] inSquare, int xCoord, int yCoord){
        boolean [] outVals = new boolean[dim];
        
        //Initializing to true
        for (int i = 0; i < dim; i++) outVals[i] = true;
        
        //Marking those which are false
        for (int i = 0; i < dim; i++) {
            if (inSquare[xCoord][i] != 0 ){
                outVals[inSquare[xCoord][i]-1] = false;
            }//End if
            if (inSquare[i][yCoord] != 0) {
                outVals[inSquare[i][yCoord]-1] = false;
            }//End if
        }//End for
        
        return outVals;
    }//End getcandy
    
    //Converts the given Latin Square to be normal on the given column
    private static int[][] defineUltraInstinctShaggy(int [][] square, int dim, int col){
        
        //No permutation needed
        if (col == 0){
            return square;
        }//End if
        
        int [][] tempSquare = ultraGo(square);
        
        //Organizing the column into normal form
        for (int i = 0; i < dim; i++){
            if (tempSquare[i][col] != i+1){
                for (int j = i; j < dim; j++){
                    if (tempSquare[j][col] == i+1){
                        tempSquare = permRow(tempSquare, i, j, dim);
                        break;
                    }//End if
                }//End for
            }//End if
        }//End for
        
        //Making it the first column
        if (col != 0){
            tempSquare = allColsBeHEre(tempSquare, 0, col, dim);
        }//End if

        //Organizing the row into normal form
        for (int i = 0; i < dim; i++){
            if (tempSquare[0][i] != i+1){
                for (int j = i; j < dim; j++){
                    if (tempSquare[0][j] == i+1){
                        tempSquare = allColsBeHEre(tempSquare, i, j, dim);
                        break;
                    }//End if
                }//End for
            }//End if
        }//End for
        
        return tempSquare;
    }//End defineUltraInstinctShaggy
    
    //Converts the given Latin Square to be normal on the given row
    private static int[][] rowsuponrows(int [][] square, int dim, int row){
        
        //No permutation needed
        if (row == 0){
            return square;
        }//End if
        
        int [][] tempSquare = ultraGo(square);
        
        //Organizing the row into normal form
        for (int i = 0; i < dim; i++){
            if (tempSquare[row][i] != i+1){
                for (int j = i; j < dim; j++){
                    if (tempSquare[row][j] == i+1){
                        tempSquare = allColsBeHEre(tempSquare, i, j, dim);
                        break;
                    }//End if
                }//End for
            }//End if
        }//End for
        
        //Making it the first row
        tempSquare = permRow(tempSquare, 0, row, dim);

        //Organizing the col into normal form
        for (int i = 0; i < dim; i++){
            if (tempSquare[i][0] != i+1){
                for (int j = i; j < dim; j++){
                    if (tempSquare[j][0] == i+1){
                        tempSquare = permRow(tempSquare, i, j, dim);
                        break;
                    }//End if
                }//End for
            }//End if
        }//End for
        
        return tempSquare;
    }//End rowsuponrows
    
    //Ensuring Deep copy of the array
    private static int[][] ultraGo(int [][] inSquare){
        int squareDim = inSquare.length;
        int [][] outSquare = new int [squareDim][squareDim];
        
        for (int i = 0; i < squareDim; i++){
            for (int j = 0; j < squareDim ; j++){
                outSquare[i][j] = inSquare[i][j];
            }//End for
        }//End for
        
        return outSquare;
    }//End ultraGo
    
}//End Assignment2