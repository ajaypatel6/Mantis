package Rental;


import BasicIO.*;


public class Car {
    
    
    public  static final String[] CATEGORIES = {"Economy","Full Size","Van","SUV"};
    private static final double[] RATES = {0.25,0.50,1.00,1.25};
    private String license;
    private int    mileage;
    private int    category;
    
    /* Instance Variables */
    
    
    public Car ( ASCIIDataFile in ) {
      license= in.readString();
      if(!in.isEOF()){
        mileage=in.readInt();
        category=in.readInt();
      };
        
        
    };  // constructor
    
    
    public String getLicence ( ) {
      return license;
        

    };  // getLicence
    
    
    public int getMileage ( ) {
      return mileage;
        

    };  // getMileage
    
    
    public int getCategory ( ) {
      return category;
        
        

    };  // getCategory
    
    
    public double getRate ( ) {
      return RATES[category];
        
        

    };  // getRate
    
    
    public double returned ( int m ) {
      double charge;
      charge=(m-this.mileage)*getRate();
      mileage=m;
      return charge;
        
        
        

    };  // returned
    
    
}  // Car