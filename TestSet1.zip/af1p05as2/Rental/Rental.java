package Rental;


import BasicIO.*;
import static BasicIO.Formats.*;


public class Rental {
    
    
    /** Instance Variables */
  private ASCIIDisplayer  output;
  private Node             avail;
  private Node             rented;
  private BasicForm        form;
    
    public Rental ( ) {
      form = new BasicForm("Rent","Return","List","Quit");
      setupForm();
      output = new ASCIIDisplayer();
      avail = null;
      rented = null;
      loadCars();
      
      while(true){
       int button=form.accept();
       if(button==3)break;
       switch(button){
         case 0://rent
           int cat = form.readInt("cat");
           Car c=removeAvail(cat);
           if(c==null)form.writeString("msg", "none of that category was found");
           else{
             doRent(c);}
           form.accept("OK");
           form.clearAll();
           /*if(c==null)form.writeString("msg","No Cars Available");
           else{
           addRented(c);  
           doList(c); 
           form.writeString("msg","Rented: "+c.getLicence());
           output.writeString("Car Rented");
           output.newLine();
}*/
           break;
         case 1://return
           String licence=form.readString("licence");
           Car a=removeRented(licence);
           if(a==null)form.writeString("msg","Licence not found");
           else{
             doReturn(a);}
           form.accept("OK");
           form.clearAll();
           /*if(a==null) form.writeString("msg","All Cars Returned");
           addAvail(a);
           doList(a);
           form.writeString("msg","Returned: "+a.getLicence());
           output.writeString("Car Returned");
           output.newLine();
                  form.accept("OK");
       form.writeDouble("amt",(form.readInt("nMileage")-form.readInt("oMileage"))*form.readDouble("rate"));
       form.accept("OK");
       form.clearAll();*/
           break;
         case 2://list
           output.writeString("Available Cars");
           output.newLine();
           listAvail();
           output.newLine();
           output.writeString("Rented Cars");
           output.newLine();
           listRented();
           break;
      }
 
      };
      output.close();
      form.close();
      
        
        
    }; // constructor
    
    
    /* Methods */
    private void addRented(Car car ){
      rented= new Node(car, rented);
      
    }
    
    private Car removeAvail(int category ){
      Node q = null;
      Node p = avail;
      Car result;
      while ( p!=null && p.item.getCategory()!=category){
       q=p;
       p=p.next;
      };
      if (p==null){
        result = null;
      }
      else {
        result = p.item;
        if (q==null) avail=p.next;
        else{
          q.next=p.next;
        };
      }
       return result; 
      
      
      /*Car result=null;
      if (avail==null)result=null;
      else{
        result=avail.item;
        avail=avail.next;
      };
      return result;*/
      
    }
    
    private Car removeRented(String licence ){
      Node q = null;
      Node p = rented;
      Car result;
      while ( p!=null && p.item.getLicence().compareTo(licence)!=0){
        q=p;
        p=p.next;
      };
      if (p == null){
        result = null;
      }
      else {
        result = p.item;
        if (q==null) rented=p.next;
        else{
         q.next=p.next; 
        }
      }
    return result;}
    
    private void listRented( ){
     Node p=rented;
     while(p!=null){
       String license=p.item.getLicence();
       output.writeString(license);
       output.writeInt(p.item.getMileage());
       output.writeInt(p.item.getCategory());
       output.newLine();
       p=p.next;
     }
     
      
    }
    
    private void loadCars( ){
      ASCIIDataFile input = new ASCIIDataFile();
      while(true){
        Car c = new Car(input);
        if(input.isEOF()) break;
        addAvail(c);
        
        
      }
      
      
    }
    
    private void addAvail( Car car){
     Node q = null;
     Node p= avail;
     while(p!=null){
        q=p;
        p=p.next;
       };
       if(q==null){
          avail = new Node (car,null);
        }
        else {
          q.next = new Node(car,null);
        }
      
      
    }
    
    private void listAvail( ){
     Node p=avail;
     while(p!=null){
       String license=p.item.getLicence();
       output.writeString(license);
       output.writeInt(p.item.getMileage());
       output.writeInt(p.item.getCategory());
       output.newLine();
       p=p.next;
     }
      
    }
    
        private void setupForm ( ) {
        
        form.setTitle("Acme Rentals");
        form.addTextField("licence","Licence",8,10,10);
        form.addRadioButtons("cat","Category",true,10,40,Car.CATEGORIES);
        form.addTextField("rate","Rate",getCurrencyInstance(),8,294,40);
        form.setEditable("rate",false);
        form.addTextField("oMileage","Rental Mileage",getIntegerInstance(),
                          8,10,160);
        form.setEditable("oMileage",false);
        form.addTextField("nMileage","Returned Mileage",getIntegerInstance(),
                          8,222,160);
        form.addTextField("amt","Amount",getCurrencyInstance(),10,10,190);
        form.setEditable("amt",false);
        form.addTextField("msg","Message",45,10,220);
        form.setEditable("msg",false);
        
    };  // setupForm
        
        private void doList (Car c ){
           form.writeString("licence", c.getLicence());
           form.writeInt("oMileage", c.getMileage());
           form.writeDouble("rate", c.getRate());
           form.writeInt("cat",c.getCategory());
           //form.writeString("msg","Rented: "+c.getLicence());
        }
        
        private void doRent (Car c){
          
           if(c==null)form.writeString("msg","No Cars Available");
           else{
           addRented(c);  
           doList(c); 
           form.writeString("msg","Rented: "+c.getLicence());
           output.writeString("Car Rented");
           output.newLine();
          
          
          
        }
        }
        
        private void doReturn (Car a){
          if(a==null) form.writeString("msg","All Cars Returned");
           addAvail(a);
           doList(a);
           form.writeString("msg","Returned: "+a.getLicence());
           output.writeString("Car Returned");
           output.newLine();
           form.accept("OK");
           form.writeDouble("amt",(form.readInt("nMileage")-form.readInt("oMileage"))*form.readDouble("rate"));
           form.accept("OK");
           form.clearAll();
           /*Node q = null;
           Node p= avail;
           while(p!=null){
            q=p;
            p=p.next;
           };
           if(q==null){
             avail = new Node (a,null);
           }
           else {
             q.next = new Node(a,null);
           }*/
          
          
        }
        

    
    public static void main ( String[] args ) { Rental r = new Rental(); };
    
    
}  // Rental