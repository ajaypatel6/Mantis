int menu();
void interrupted(int sig);
double eggHolderFormula (double x, double y);
double randomizeValue (int min, int max);
void* hillClimb(void* work);
