#include <iostream>
#include <unistd.h>
#include <cstdlib>
#include <signal.h>
#include <pthread.h>
#include <cmath>
#include "hillClimb.h"

//Author: Cesar Moreno, Student #: 5727722
//COSC 2P95 - Lab Exercise #9

int climberNum; 

double bestX = 0; 
double bestY = 0; 

volatile double bestAnswer = randomizeValue(-512,512);
volatile bool defaultBest = true;

volatile bool continuing;
volatile int occupied;

pthread_mutex_t olock; // Our mutual exclusion lock for entering the critical region "hillClimb"
pthread_mutex_t cout_lock; //Our mutual exclusion lock for updating global best and printing values

int menu(){
	int choice;
	std::cout<<"Enter the number of climbers/threads you want (1-8) or type 0 to quit: ";
	std::cin>>choice;
	return choice;
}

void interrupted(int sig) {
	std::cout<<"\n Computations are done\n Stopping..."<<std::endl;
    std::cout<<"Global Best Height: "<<bestAnswer<<std::endl;
    std::cout<<"X: "<<bestX<<", Y: "<<bestY<<std::endl;
	continuing = false;
}

double eggHolderFormula (double x, double y) { 
	return (-(y + 47) * std::sin(std::sqrt(std::abs((x/2) + y + 47))) - x * (std::sin(std::sqrt(std::abs(x - y - 47)))));
}

double randomizeValue (int min, int max) {
    double f = (double)rand() / RAND_MAX;
    return (min + (f * (max - min)));
}

void* hillClimb(void* work){

    double startingLocation = randomizeValue(-512,512); 

	double currentX = startingLocation;
	double currentY = startingLocation;
    
	double currentHeight;

	double modifiedX;
	double modifiedY;
	double modifiedHeight;

	double tempX = currentX;
	double tempY = currentY;

	bool moved; 
	
	while (continuing) {

		moved = false;

		//Each climber will generate, at each step, 4 possible moves
		for (int i  = 0; i < 4; i++) {
			currentHeight = eggHolderFormula(currentX,currentY); //calculate current climber's height
			modifiedX = currentX + randomizeValue(-5,5); //Random modifier in the range of [-5,5] is added to the current value of X
			modifiedY = currentY + randomizeValue(-5,5); //Random modifier in the range of [-5,5] is added to the current value of Y
			
            //Check that we have not exceeded the bounds (-512, 512)
			if (!(modifiedX < -512 || modifiedX > 512 || modifiedY < -512 || modifiedY > 512)){
				modifiedHeight = eggHolderFormula(modifiedX, modifiedY);
				if (modifiedHeight < currentHeight){
					moved = true;
					tempX = modifiedX;
					tempY = modifiedY;
				}
			}
		}
		
		//If the climber moves, as a result of finding a better local height, then update the coordinates of X and Y
		if (moved == true) {
			currentX = tempX;
			currentY = tempY;
			currentHeight = eggHolderFormula(currentX,currentY);
		}
		
		//Update the global best answer for the hill climber height and print the values
		if (defaultBest == true || currentHeight < bestAnswer){
			pthread_mutex_lock(&cout_lock);
			defaultBest = false;
			bestAnswer = currentHeight;
			bestX = currentX;
			bestY = currentY;
			std::cout<<"\nNew Global Best found! "<<std::endl;
			std::cout<<"New Best: "<<currentHeight<<", X: "<<currentX<<", Y: "<<currentY<<std::endl;
			pthread_mutex_unlock(&cout_lock);
		}
		
		//If the climber current calculated height was not improved, then randomize the position of X and Y
		if (moved == false) {
			currentX = randomizeValue(-512,512);
			currentY = randomizeValue(-512,512);
		}
	}

    //Mutual exclusion lock for entering the critical region
    pthread_mutex_lock(&olock);
	occupied--;
	pthread_mutex_unlock(&olock);

}

int main(){
	
    srand(time(NULL));
	pthread_t ct[8]; //thread pool
	
	if (signal(SIGINT,interrupted)==SIG_ERR) {
		std::cout<<"Unable to change signal handler"<<std::endl;
		return 1;
	}

	while (true){
        climberNum = menu();
	if (climberNum <= 0 || climberNum > 8) break;	
		continuing = true;

		for (int i = 0; i < climberNum; i++) {
			pthread_mutex_lock(&olock); //obtain the lock
		    pthread_create(&ct[i], NULL, &hillClimb, NULL);
			occupied++;
			pthread_mutex_unlock(&olock); //release lock
		}
		
		//Ensuring the program continues to run as long as any thread is running
		while (occupied > 0) {
			sleep(1);
		}	
	}
    std::cout<<"Execution complete"<<std::endl;
}

