package Assign_6;


import Media.*;                  // for Media classes
import java.awt.*;               // for Color objects and methods
import static java.lang.Math.*;  // for math constants and functions
import static java.awt.Color.*;  // for Color constants


/** This class ...
  *
  * @author Saifa Bhanji
  * @version 1.0 (Nov 2015)                                                        */

public class Blurry {
    
    
    // instance variables
  
  private PictureDisplayer display; //
    
    
    /** This constructor ...                                                     */
    
    public Blurry ( ) {

        // local variables
      
      Picture pic; 
        
        // statements

      pic = new Picture(); 
      display = new PictureDisplayer(); 
      dsplay.placePicture(pic); 
      display.waitForUser();
      
      display.close();
      pic.save(); 
      
    }; // constructor
    
    
    // methods
    
    private Color aveColor (Picture pic, int c, int r, int blockSize) {
      
      
    } //aveColor
    
    
    private void paint (Picture pic, int c, int r, int blockSize, Color color) {
      
      
      
    } //paint
    
    private void pixelate (Picture pic, int blockSize) {
      
      
    } //pixelate

    
    
    public static void main ( String[] args ) { Blurry b = new Blurry(); };
    
    
} // Blurry
