/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class Building{
    String constructionmat; //construction material of building (options are brick, wood, siding, other)
    int size;               //in square feet
    
    public Building(String constructionmat, int size){
        this.constructionmat=constructionmat;
        this.size=size;
    }//constructor
    
    public String getMaterial(){
        return constructionmat;
    }//getMaterial
    public int getSize(){
        return size;
    }//getSize
}//Building
