/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class FarmNode {

    FarmNode next;
    FarmProperty farmProp;    //stores farm property
    
    public FarmNode(FarmProperty r, FarmNode n){
        this.next=n;
        this.farmProp=r;
    }//constructor
    
}//FarmNode
