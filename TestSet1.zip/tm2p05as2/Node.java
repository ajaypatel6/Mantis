/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class Node {

    Node next;
    CommRetailProperty retail;
    
    public Node(CommRetailProperty retail, Node n){
        this.next=n;
        this.retail=retail;
    }//constructor
}//Node
