/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class IndustrialNode {

    IndustrialNode next;
    CommIndustProperty industrial;

    public IndustrialNode(CommIndustProperty i, IndustrialNode n) {

        this.next = n;
        this.industrial = i;
    }//constructor

}//IndustrialNode
