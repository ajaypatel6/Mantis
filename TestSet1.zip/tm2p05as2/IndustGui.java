package assign2;

/**
 *
 * Tamara McDiarmi 6148837 COSC2P05_ assign2
 */
import BasicIO.*;

public class IndustGui {

    private BasicForm form; //basic form for commercial propertoies available that meet search criteria entered
    private Converter convert;  //converts booleans and city strings for output
    public IndustGui() {

        form = new BasicForm("Next", "Quit");
        setupForm();
    }//constructor

    private void setupForm() {
        form.setTitle("AVAILABLE PROPERTIES");
        form.addTextField("taxes", "Taxes");
        form.addTextField("price", "Price");
        form.addTextField("lSize", "Lot size");
        form.addTextField("city", "City");
        form.addTextField("material", "Material");
        form.addTextField("bSize", "Building Size");
        form.addTextField("attr", "Attribute");
        form.addTextField("iType", "Industry Type");
        form.addTextField("crane", "Any cranes incl?");
        form.addTextField("equip", "Any other equip incl?");
        form.addTextField("rail", "Is there railway access?");
    }//setupForm

    public void writeIndustry(IndustrialNode i) {
        convert=new Converter();
        form.writeInt("taxes", i.industrial.getPropTaxes());
        form.writeInt("price", i.industrial.getLotPrice());
        form.writeInt("lSize", i.industrial.getLotSize());
        form.writeString("city", convert.convertCity(i.industrial.getLoc()));
        form.writeString("material", i.industrial.aFactory.getMaterial());
        form.writeInt("bSize", i.industrial.aFactory.getSize());
        form.writeString("attr", i.industrial.getIndustrialAttr());
        form.writeString("iType", i.industrial.getTheBuildingType());
        form.writeString("crane",convert.convertBoolean( i.industrial.aFactory.crane));
        form.writeString("equip", convert.convertBoolean(i.industrial.aFactory.equip));
        form.writeString("rail", convert.convertBoolean(i.industrial.aFactory.rail));
    }//writeIndustry

    public int display() {
        return form.accept();
    }//display

    public void close() {
        form.close();
        System.exit(0);
    }//close

    public void noMore() {
        form.clearAll();
        form.writeString("taxes", "NO MORE PROPERTIES TO DISPLAY");
    }//noMore

}//IndustGui
