package assign2;

/**
 *
 * Tamara McDiarmi 6148837 COSC2P05_ assign2
 */
import BasicIO.*;

public class CrGui  {

    private BasicForm form; //basic form for commercial propertoies available that meet search criteria entered
    private Converter convert;  //used to convert Booleans and city strings for output
    public CrGui () {

        form = new BasicForm("Next", "Quit");
        setupForm();
    }//constructor

    private void setupForm() {
        form.setTitle("AVAILABLE PROPERTIES");
        form.addTextField("taxes", "Taxes");
        form.addTextField("price", "Price");
        form.addTextField("lSize", "Lot size");
        form.addTextField("city", "City");
        form.addTextField("material", "Material");
        form.addTextField("bSize", "Building Size");
        form.addTextField("attr", "Attribute");
        form.addTextField("shelves", "Are shelves incl?");
        form.addTextField("chkout", "Are cash registers incl?");
        form.addTextField("safe", "Is a safe incl?");
    }//setupForm

    public int display() {
        return form.accept();
    }//display

    public void close() {
        form.close();
        System.exit(0);
    }//close

    public void noMore() {
        form.clearAll();
        form.writeString("taxes", "NO MORE PROPERTIES TO DISPLAY");
    }//noMore

    public void write(Node cr) {
        convert=new Converter();
        form.writeInt("taxes", cr.retail.getPropTaxes());
        form.writeInt("price", cr.retail.getLotPrice());
        form.writeInt("lSize", cr.retail.getLotSize());
        form.writeString("city", convert.convertCity(cr.retail.getLoc()));
        form.writeString("material", cr.retail.aStore.getMaterial());
        form.writeInt("bSize",cr.retail.aStore.getSize());
        form.writeString("attr", cr.retail.getRetailAttr());
        form.writeString("shelves", convert.convertBoolean(cr.retail.aStore.shelves));
        form.writeString("chkout", convert.convertBoolean(cr.retail.aStore.checkout));
        form.writeString("safe", convert.convertBoolean(cr.retail.aStore.safe));
     
    }//write
    
}//CrGui
