/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class Factory extends Building{
    boolean crane;  //is an overhead crane included in sale?
    boolean equip;  //is other equipment included in sale?
    boolean rail;   //is there railway access?
    
    public Factory(String constructionmat, int size, String c, String e, String r){
        super(constructionmat, size);
        if(c.equals("y")){
           this.crane=true; 
        }else{this.crane=false;}
        if(e.equals("y")){
            this.equip=true;
        }else{this.equip=false;}
        if(r.equals("y")){
            this.rail=true;
        }else{this.rail=false;}
        
        this.equip=equip;
        this.rail=rail;
    }//constructor
}//Factory
