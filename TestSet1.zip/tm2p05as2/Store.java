/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class Store extends Building{
    boolean shelves;    //is shelving included in sale?
    boolean checkout;   //are cash registers included in sale?
    boolean safe;       //is safe included in sale?
    
    public Store(String constructionmat, int size, String s, String check, String sf){
        super(constructionmat, size);
        if(s.equals("y")){
            this.shelves=true;
        }else{this.shelves=false;}
        if(check.equals("y")){
            this.checkout=true;
        }else{this.checkout=false;}
        if(sf.equals("y")){
            this.safe=true;
        }else{this.safe=false;}
    }//constructor
    
    public boolean getShelves(){
        return shelves;
    }//getShelves
    public boolean getCheckout(){
        return checkout;
    }//getCheckout
    public boolean getSafe(){
        return safe;
    }//getSafe
}//Store
