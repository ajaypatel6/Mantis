/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;


public class FarmProperty extends ResidentialProperty {
    String crops; //crop type on property (options are cash, vineyard, fruit or poultry)
    
    public FarmProperty(String sewer, String water, String garage, String pool,int pt, int lp, int ls, String loc, String type, String crops, House aHouse){
        //super(sewer, water, garage, pool, pt, lp, ls, loc, type);
        super(sewer, water, garage, pool, pt, lp, ls, loc, type, aHouse);
        this.crops=crops;
    }//constructor
    
}//FarmProperty
