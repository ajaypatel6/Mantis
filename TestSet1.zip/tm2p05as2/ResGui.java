package assign2;

/**
 *
 * Tamara McDiarmi 6148837 COSC2P05_ assign2
 */
import BasicIO.*;

public class ResGui {

    private BasicForm form; //basic form for residential propertoies available that meet search criteria entered
    private Converter convert;//used to convert booleans and city for output
    public ResGui() {

        form = new BasicForm("Next", "Quit");
        setupForm();
    }//constructor

    private void setupForm() {
        form.setTitle("AVAILABLE PROPERTIES");
        form.addTextField("taxes", "Taxes");
        form.addTextField("price", "Price");
        form.addTextField("lSize", "Lot size");
        form.addTextField("city", "City");
        form.addTextField("material", "Material");
        form.addTextField("bSize", "Building Size");
        form.addTextField("sewer", "Sewer");
        form.addTextField("water", "water");
        form.addTextField("garage", "Garage");
        form.addTextField("pool", "Pool");
        form.addTextField("bedroom", "Bedrooms");
        form.addTextField("baths", "Bathrooms");
        form.addTextField("bmnt", "Basement");
        form.addTextField("type", "House Type");
    }//setupForm

    public int display() {
        return form.accept("Next", "Quit");
    }//display

    public void close() {
        form.close();
    }//close

    public void noMore() {
        form.clearAll();
        form.writeString("taxes", "NO MORE PROPERTIES TO DISPLAY");
    }//noMore

    public void write(ResidentialNode r) {
        convert=new Converter();
        form.writeInt("taxes", r.resProp.getPropTaxes());
        form.writeInt("price", r.resProp.getLotPrice());
        form.writeInt("lSize", r.resProp.getLotSize());
        form.writeString("city",convert.convertCity(r.resProp.getLoc()));
        form.writeString("material", r.resProp.aHouse.getMaterial());
        form.writeInt(r.resProp.aHouse.getSize());
        form.writeString("sewer",convert.convertBoolean(r.resProp.sewer));
        form.writeString("water",convert.convertBoolean(r.resProp.water));
        form.writeString("garage",convert.convertBoolean(r.resProp.garage));
        form.writeString("pool",convert.convertBoolean(r.resProp.pool));
        form.writeInt("bedroom", r.resProp.aHouse.numBedrooms);
        form.writeInt("baths", r.resProp.aHouse.numBaths);
        form.writeString("bmnt", convert.convertBoolean(r.resProp.aHouse.basement));
        form.writeString("type", r.resProp.aHouse.houseType);
    }//write

    public void writeFarm(FarmNode f) {
        convert=new Converter();
        form.addTextField("crop", "Crop Type");
        form.writeInt("taxes", f.farmProp.getPropTaxes());
        form.writeInt("price", f.farmProp.getLotPrice());
        form.writeInt("lSize", f.farmProp.getLotSize());
        form.writeString("city",convert.convertCity(f.farmProp.getLoc()));
        form.writeString("material", f.farmProp.aHouse.getMaterial());
        form.writeInt(f.farmProp.aHouse.getSize());
        form.writeString("sewer", convert.convertBoolean(f.farmProp.sewer));
        form.writeString("water", convert.convertBoolean(f.farmProp.water));
        form.writeString("garage", convert.convertBoolean(f.farmProp.garage));
        form.writeString("pool", convert.convertBoolean(f.farmProp.pool));
        form.writeInt("bedroom", f.farmProp.aHouse.numBedrooms);
        form.writeInt("baths", f.farmProp.aHouse.numBaths);
        form.writeString("bmnt", convert.convertBoolean(f.farmProp.aHouse.basement));
        form.writeString("type", f.farmProp.aHouse.houseType);
        form.writeString("crop", f.farmProp.crops);
    }//writeFarm

}//ResGui
