/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class House extends Building {
    int numBedrooms;    //# of bedrooms in house
    int numBaths;       //# of bathrooms in house
    boolean basement;   //is there a basement?
    String houseType;   //options are (condo, row, semi, bungalow, split, two story)
    
    public House(String constructionmat, int size, int numBedrooms, int numBaths, String b, String houseType){
        super(constructionmat, size);
        this.numBedrooms=numBedrooms;
        this.numBaths=numBaths;
        if (b.equals("y")){
           this.basement=true;  
        }else{this.basement=false;}
        this.houseType=houseType;
    }//constructor
    
}//House
