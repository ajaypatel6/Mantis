package assign2;

/**
 *
 * Tamara McDiarmi 6148837 COSC2P05_ assign2
 */
import BasicIO.*;

public class GUI {

    private BasicForm form; //user input form

    public GUI() {
        
        form=new BasicForm("Search", "Quit");
        setupForm();
        //form.show();
    }//constructor

    //sets up the form
    private void setupForm() {
        form.setTitle("SEARCH PARAMETERS");
        form.addTextField("city","City");
        form.addTextField("max","Max price");
        form.addTextField("pType","Property Type");
    }//setupForm
    
    public int display(){
        return form.accept("Search", "Quit");
    }//display
    
    public void close (){
        form.close();
        System.exit(0);
    }//close

    /*reads city field entered and returns a String */
    public String readCity(){
        return form.readString("city");
    }//readCity
    
    /*reads max price field entered and returns an int*/
    public int readMaxPrice(){
        return form.readInt("max");
    }//readMaxPrice
    
    /*reads the property type field and returns a String*/
    public String readPropType(){
        return form.readString("pType");
    }//readPropType
    
}//GUI
