/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class ResidentialNode {

    // Store st;//???not needed
    ResidentialNode next;
    ResidentialProperty resProp;    //stores residential property

    public ResidentialNode(ResidentialProperty r, ResidentialNode n) {
        this.next = n;
        this.resProp = r;
    }//constructor
    
    public int size(){
        return 20;
    }
}//ResidentialNode
