/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class ResidentialProperty extends Property {

    boolean sewer; //is the property on city sewers?
    boolean water;  //is the property on city water?
    boolean garage; //does property have a garage?
    boolean pool;   //is there a pool?
    House aHouse;   //house on property
    String typeOfHouse; //type of house on property

    public ResidentialProperty(String s, String w, String g, String p, int pt, int lp, int ls, String loc, String type, House aHouse) {
        super(pt, lp, ls, loc, type);
        if (s.equals("y")) {
            this.sewer = true;
        } else {
            this.sewer = false;
        }
        if (w.equals("y")) {
            this.water = true;
        } else {
            this.water = false;
        }
        if (g.equals("y")) {
            this.garage = true;
        } else {
            this.garage = false;
        }
        if (p.equals("y")) {
            this.pool = true;
        } else {
            this.pool = false;
        }
        this.aHouse = aHouse;
        this.typeOfHouse=type;
    }//constructor

}//ResidentialProperty
