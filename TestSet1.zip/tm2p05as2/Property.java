/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

//constructs a property object
public class Property {
    private int     pt;     //property taxes
    private int     lp;     //lot price
    private int     ls;     //in square feet
    private String  loc;    //the city
    private String  type;   //the building on the property

    public Property(int pt, int lp, int ls, String loc, String type) {
        this.pt=pt;
        this.lp=lp;
        this.ls=ls;
        this.loc=loc;
        this.type=type;
    }//constructor
    public int getPropTaxes(){
        return pt;
    }//getPropTaxes
    public int getLotPrice(){
        return lp;
    }//getLotPrice
    public int getLotSize(){
        return ls;
    }//getLotSize
    public String getLoc(){
        return loc;
    }//getLoc
    public String getTheBuildingType(){
        return type;
    }//getTheBuildingType
    
    
}//Property
