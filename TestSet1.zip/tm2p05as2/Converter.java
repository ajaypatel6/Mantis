/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class Converter {

    public Converter() {

    }

    public String convertBoolean(boolean toConvert) {
        if (toConvert == true) {
            return "yes";
        } else {
            return "no";
        }
    }//convertBoolean

    public String convertCity(String cityShort) {
        String theCity = null;
        if (cityShort.equalsIgnoreCase("wlld")) {
            theCity = "Welland";
        }
        if (cityShort.equalsIgnoreCase("ngfl")) {
            theCity = "Niagara Falls";
        }
        if (cityShort.equalsIgnoreCase("fter")) {
            theCity = "Fort Erie";
        }
        if (cityShort.equalsIgnoreCase("stct")) {
            theCity = "St. Catharines";
        }
        return theCity;
    }//convertCity
}
