/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class CommIndustProperty extends Property{
    private String commIndustAttr;  //light, medium or heavy (only options)
    Factory aFactory;       //factory on property
    
    public CommIndustProperty(String commIndustAttr, int pt, int lp, int ls, String loc, String type, Factory aFactory){
        super(pt, lp, ls, loc, type);
        this.commIndustAttr=commIndustAttr;
        this.aFactory=aFactory;
    }//constructor
    public String getIndustrialAttr(){
        return commIndustAttr;
    }//getIndustrialAttr
}//CommIndustProperty
