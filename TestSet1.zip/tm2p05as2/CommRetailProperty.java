/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class CommRetailProperty extends Property{
    private String commRetailAttr;  //stripmall, largemall, or street (only options)
    Store aStore;                   //store on the property
    
    public CommRetailProperty(String commRetailAttr, int pt, int lp, int ls, String loc, String type, Store aStore){
        super(pt, lp, ls, loc, type);
        this.commRetailAttr=commRetailAttr;
        this.aStore=aStore;
    }//constructor
    public String getRetailAttr(){
        return commRetailAttr;
    }//getRetailAttr
}//CommRetailProperty
