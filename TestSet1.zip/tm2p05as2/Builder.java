/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

public class Builder {

    public Builder() {

    }//constructor
    
    //returns a store
    public Store makeStore(String[] storeInfo) {
        Store aStore = new Store(storeInfo[2], Integer.parseInt(storeInfo[1]), storeInfo[3], storeInfo[4], storeInfo[5]);
        return aStore;
    }//makeStore
    
    //makes a factory and returns it
    public Factory makeFactory(String[] factoryInfo) {
        Factory aFactory = new Factory(factoryInfo[2], Integer.parseInt(factoryInfo[1]), factoryInfo[3], factoryInfo[4], factoryInfo[5]);
        return aFactory;
    }//makeFactory
    
    //returns a house
    public House makeHouse(String[] houseInfo) {
        House aHouse = new House(houseInfo[2], Integer.parseInt(houseInfo[1]), Integer.parseInt(houseInfo[4]), Integer.parseInt(houseInfo[5]), houseInfo[6], houseInfo[3]);
        return aHouse;
    }//makeHouse
    
}//Builder
