/*
 * Tamara McDiarmid
 * student# 6148837
 * COSC2P05 FEB 2018
 */
package assign2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Iterator;
import java.util.LinkedList;

public class Assign2 {

    private Node commRetail;    //list of commercial retail properties
    private IndustrialNode commIndustrial;    //list of commercial industrial properties
    private ResidentialNode residential;   //list of residential properties
    private FarmNode farm;      //list of farm properties
    private GUI mainSearchGUI;    //provides a search GUI for user input (to provide search parameters)
    private ResGui rg;  //gui for residential
    private CrGui cr;   //gui for commercial retail properties
    private IndustGui indGui;   //gui for ondustrial properties
    private ResGui farms;   //gui for farm properties
    private LinkedList<ResidentialNode> queue;//linked list for residential
    private LinkedList<Node> crList;    //linkedlist for commercial retail
    private LinkedList<IndustrialNode> industryList;    //linked list for industrial
    private LinkedList<FarmNode> farmList;  //linked list for farms
    private Builder theBuilder; //builds buildings

    private Assign2() {
        getInputFile();
    }//constructor

    //prompts user for input txt file
    private void getInputFile() {
        boolean value = false;
        try {
            File listings = new File("realEstateInput.txt"); //found in Assign2 folder
            Scanner reader = new Scanner(listings);
            value = true;
            if (value) {
                makeListings(reader);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("EXCEPTION CAUGHT--> " + ex);
            getInputFile();
        }

    }//getInputFile

    //once file is loaded, makes different property objects from file
    private void makeListings(Scanner reader) {
        String str;
        while (reader.hasNextLine()) {
            str = reader.nextLine();
            doStuff(str);   //reads properties one line at a time to make appropriate objects

        }
        mainSearchGUI = new GUI();
        for (;;) {
            int button = mainSearchGUI.display();
            switch (button) {
                case 1: {               //exit  
                    mainSearchGUI.close();
                    break;
                }
                case 0: {                     //get search parameters
                    String a = mainSearchGUI.readCity();
                    int b = mainSearchGUI.readMaxPrice();
                    String c = mainSearchGUI.readPropType();
                    if (c.equalsIgnoreCase("residential")) {    //residential
                        compileResidentials(a, b, c);

                    }
                    if (c.equalsIgnoreCase("commretail")) {//commercial retail
                        compileCr(a, b, c);
                    }
                    if (c.equalsIgnoreCase("farm")) {//farm
                        compileFarm(a, b, c);
                    }
                    if (c.equalsIgnoreCase("commindust")) {//farm
                        compileIndustrial(a, b, c);
                    }
                    mainSearchGUI.close();
                    break;
                }

            }
        }

    }//makeListings

    //**********FARMS*******************
    private void makeFarm(String[] farmPropInfo, House aHouse) {
        FarmProperty theFarm = new FarmProperty(farmPropInfo[12], farmPropInfo[13], farmPropInfo[14],
                farmPropInfo[15], Integer.parseInt(farmPropInfo[8]), Integer.parseInt(farmPropInfo[9]), Integer.parseInt(farmPropInfo[10]),
                farmPropInfo[11], farmPropInfo[3], farmPropInfo[16], aHouse);
        addToFarmListings(theFarm);
    }//makeFarm

    private void addToFarmListings(FarmProperty r) {
        FarmNode q = null;
        FarmNode p = farm;
        while (p != null) {
            q = p;
            p = p.next;
        }
        if (q == null) {
            farm = new FarmNode(r, p);
        } else {
            q.next = new FarmNode(r, p);
        }
    }//addToFarmListings

    private void compileFarm(String city, int max, String type) {
        FarmNode f = farm;
        farmList = new LinkedList<>();
        while (f != null) {
            if (f.farmProp.getLoc().equalsIgnoreCase(city) && f.farmProp.getLotPrice() <= max) {
                farmList.add(f);
            }
            f = f.next;
        }

        farms = new ResGui();
        if (farmList.size() > 0) {
            FarmNode first = farmList.removeFirst();
            farms.writeFarm(first);

        } else {
            farms.noMore();
        }
        Iterator<FarmNode> itt = farmList.iterator();
        for (;;) {
            int button = farms.display();
            switch (button) {
                case 1: {               //exit  
                    farms.close();
                    mainSearchGUI.close();
                    break;
                }
                case 0: {                     //NEXT property
                    displayFarm(farmList, itt);
                    break;
                }

            }
        }

    }//compileFarms

    private void displayFarm(LinkedList l, Iterator i) {
        if (!i.hasNext()) {
            farms.noMore();
        }
        if (i.hasNext()) {
            FarmNode r = (FarmNode) i.next();
            farms.writeFarm(r);
        }
    }//displayFarm
//************************END OF FARM METHODS*******************

    //*********************RESIDENTIAL************
    private void makeResidential(String[] resPropInfo, House aHouse) {
        ResidentialProperty res = new ResidentialProperty(resPropInfo[12], resPropInfo[13], resPropInfo[14],
                resPropInfo[15], Integer.parseInt(resPropInfo[8]), Integer.parseInt(resPropInfo[9]), Integer.parseInt(resPropInfo[10]),
                resPropInfo[11], resPropInfo[3], aHouse);
        addToResidentialListings(res);
    }//makeResidential

    private void addToResidentialListings(ResidentialProperty r) {
        ResidentialNode q = null;
        ResidentialNode p = residential;
        while (p != null) {
            q = p;
            p = p.next;
        }
        if (q == null) {
            residential = new ResidentialNode(r, p);
        } else {
            q.next = new ResidentialNode(r, p);
        }
    }//addToResidentialListings

    private void display(LinkedList q, Iterator it) {
        if (!it.hasNext()) {
            rg.noMore();
        }
        if (it.hasNext()) {
            ResidentialNode r = (ResidentialNode) it.next();
            rg.write(r);
        }

    }//display

    private void compileResidentials(String city, int max, String type) {
        ResidentialNode r = residential;
        queue = new LinkedList<>();
        while (r != null) {
            if (r.resProp.getLoc().equalsIgnoreCase(city) && r.resProp.getLotPrice() <= max) {
                queue.add(r);
            }
            r = r.next;
        }
        rg = new ResGui();
        ResidentialNode first = queue.removeFirst();
        rg.write(first);
        Iterator<ResidentialNode> itt = queue.iterator();
        for (;;) {
            int button = rg.display();
            switch (button) {
                case 1: {               //exit  
                    rg.close();
                    mainSearchGUI.close();
                    break;
                }
                case 0: {                     //get search parameters
                    display(queue, itt);
                    break;
                }

            }
        }

    }//compileResidentials
    //*********************END OF RESIDENTIAL METHODS************************

    //*********INDUSTRIAL**********************
    private void compileIndustrial(String city, int max, String type) {
        IndustrialNode ind = commIndustrial;
        industryList = new LinkedList<>();
        while (ind != null) {
            if (ind.industrial.getLoc().equalsIgnoreCase(city) && ind.industrial.getLotPrice() <= max) {
                industryList.add(ind);
            }
            ind = ind.next;
        }
        indGui = new IndustGui();
        if (industryList.size() > 0) {
            IndustrialNode first = industryList.removeFirst();
            indGui.writeIndustry(first);

        } else {
            indGui.noMore();
        }
        Iterator<IndustrialNode> itt = industryList.iterator();
        for (;;) {
            int button = indGui.display();
            switch (button) {
                case 1: {               //exit  
                    indGui.close();
                    mainSearchGUI.close();
                    break;
                }
                case 0: {                     //get search parameters
                    displayIndustry(industryList, itt);
                    break;
                }

            }
        }
    }//compileIndustrial

    private void displayIndustry(LinkedList i, Iterator it) {
        if (!it.hasNext()) {
            indGui.noMore();
        }
        if (it.hasNext()) {
            IndustrialNode r = (IndustrialNode) it.next();
            indGui.writeIndustry(r);
        }

    }//displayIndustry

//makes a commercial industrial property object
    private void makeCommIndustrial(String[] industrialPropInfo, Factory aFactory) {
        CommIndustProperty industrial = new CommIndustProperty(industrialPropInfo[11], Integer.parseInt(industrialPropInfo[7]), Integer.parseInt(industrialPropInfo[8]), Integer.parseInt(industrialPropInfo[9]), industrialPropInfo[10], industrialPropInfo[11], aFactory);
        addToCommercialIndustrial(industrial);
    }//makeCommIndustrial

    //adds listing to the commercial industrial listings
    private void addToCommercialIndustrial(CommIndustProperty i) {
        IndustrialNode q = null;
        IndustrialNode p = commIndustrial;
        while (p != null) {
            q = p;
            p = p.next;
        }
        if (q == null) {
            commIndustrial = new IndustrialNode(i, p);
        } else {
            q.next = new IndustrialNode(i, p);
        }
    }//addToCommercialIndustrial

//******************END OF INDUSTRIAL METHODS***********************
    //********************RETAIL********************
    private void makeCommRetail(String[] commRetailInfo, Store aStore) {
        CommRetailProperty retail = new CommRetailProperty(commRetailInfo[11], Integer.parseInt(commRetailInfo[7]), Integer.parseInt(commRetailInfo[8]), Integer.parseInt(commRetailInfo[9]), commRetailInfo[10], commRetailInfo[6], aStore);
        addToCommRetail(retail);
    }//makeCommRetail

    //adds listing to the commercial retail listings
    private void addToCommRetail(CommRetailProperty retail) {
        Node q = null;
        Node p = commRetail;
        while (p != null) {
            q = p;
            p = p.next;
        }
        if (q == null) {
            commRetail = new Node(retail, p);
        } else {
            q.next = new Node(retail, p);
        }

    }//addToCommRetail

    private void compileCr(String city, int max, String type) {
        Node comm = commRetail;
        crList = new LinkedList<>();
        while (comm != null) {
            if (comm.retail.getLoc().equalsIgnoreCase(city) && comm.retail.getLotPrice() <= max) {
                crList.add(comm);
            }
            comm = comm.next;
        }

        cr = new CrGui();
        if (crList.size() > 0) {
            Node first = crList.removeFirst();
            cr.write(first);

        } else {
            cr.noMore();
        }
        Iterator<Node> itt = crList.iterator();
        for (;;) {
            int button = cr.display();
            switch (button) {
                case 1: {               //exit  
                    cr.close();
                    mainSearchGUI.close();
                    break;
                }
                case 0: {                     //get search parameters
                    displayCommRet(crList, itt);
                    break;
                }

            }
        }

    }//compileCr

    private void displayCommRet(LinkedList l, Iterator i) {
        if (!i.hasNext()) {
            cr.noMore();
        }
        if (i.hasNext()) {
            Node r = (Node) i.next();
            cr.write(r);
        }
    }//displayCommRet
    //************END OF COMMERCIAL RETAIL METHODS***********

    private void allGone() {
        rg.noMore();
    }//allGone

    //checks buildings types to make objects
    private void doStuff(String str) {
        char c = str.charAt(0);
        String[] result = new String[11];
        String[] factResult = new String[11];
        String[] houseResults = new String[15];
        if (c == 's') {     //if building type ='s' (store)
            result = str.split("\\s");
            theBuilder = new Builder();
            Store place = theBuilder.makeStore(result);
            if (result[6].equals("s")) {    //commercial retail
                makeCommRetail(result, place);
            }

        }
        if (c == 'f') {     //if building type = 'f' (factory)
            factResult = str.split("\\s");
            Factory aFactory = theBuilder.makeFactory(factResult);
            if (factResult[6].equals("i")) {    //commercial industrial
                makeCommIndustrial(factResult, aFactory);
            }
        }
        if (c == 'h') {     //if building type ='h' (house)
            houseResults = str.split("\\s");
            House aHouse = theBuilder.makeHouse(houseResults);
            if (houseResults[7].equals("r")) {    //residential
                makeResidential(houseResults, aHouse);
            }
            if (houseResults[7].equals("f")) {    //farms
                makeFarm(houseResults, aHouse);

            }
        }
    }//doStuff

    public static void main(String[] args) {
        new Assign2();
    }

}//Assign2
