/*
Curtis Penney - 5660659
COSC 2P05 - Assignment 1
Solving Sudoku with Backtracking
*/

package sudokuassignment;

//Class for Sudoku-Exceptions
class SudokuException extends Exception {
    public SudokuException(String msg) {
        super(msg);
    }//End SudokuException
}//End SudokuException
