/*
Curtis Penney - 5660659
COSC 2P05 - Assignment 1
Solving Sudoku with Backtracking
*/

package sudokuassignment;

public final class sudokuBoard {
    
    //Declaring variables
    public static final int BOARD_DIM = 9;
    int[][] boardArr = new int[BOARD_DIM][BOARD_DIM];       //Array to store the values of the board
    
    
    //Constructor
    public sudokuBoard (int[][] inputArr) throws SudokuException {
        
        int i, j;
            
        //Validating the inputArr is of size 9x9
        if (inputArr.length != BOARD_DIM || inputArr[0].length != BOARD_DIM) {
            throw new SudokuException("Input array must be of dimensions 9x9."); 
        }//End if
        
        //Storing inputArr into boardArr
        for (i = 0; i < BOARD_DIM; i++){
            for (j = 0; j < BOARD_DIM; j++){
                boardArr[i][j] = inputArr[i][j];
            }//End for
        }//End for
 
    }//End constructor
    
    //Method to print the board
    public void printBoard(){
        int i, j;
        for (i = 0; i < BOARD_DIM; i++){
            for (j = 0; j < BOARD_DIM; j++){
                System.out.print(boardArr[i][j]);
            }//End for
            System.out.println();
        }//End for
    }//End printBoard
    
    //Method which will place a given value into the provided cell
    public void placeVal(int givenVal, int row, int col){
        boolean[] numCheck = cellCheck(row, col);
        
        //Checking if the value can be placed there
        if (givenVal != 0 && numCheck[givenVal-1] == false){
            System.out.println(givenVal + " cannot be placed at board location: [" + row + "][" + col + "].");
            return;
        }//End if
        
        //Inserting the value
        boardArr[row][col] = givenVal;
        
    }//End placeVal
    
    //Method which will check the cell provided and return an array of booleans
    //The index of the boolean determines what value it represents:
    //Index 0 -> Number 1
    //Index 1 -> Number 2 ...etc
    //A value of T => The number can be placed in this cell
    //A value of F => The number exists in either the Row/Column/Square and cannot be placed.
    //Returns null if there is no potential value, or if the cell has already been filled in
    public boolean[] cellCheck(int row, int col){
        
        //If the cell is NOT 0, there is already a value here.
        if (boardArr[row][col] != 0){
            return null;
        }//End if
        
        int i;
        int j;
        int tempVal;
        //Initializing an arry used to check each number in sudoku (1-9)
        boolean[] numCheck = new boolean[BOARD_DIM]; 
        for (i = 0; i < BOARD_DIM; i++)numCheck[i] = true;
        
        //Checking the row
        for (i = 0; i < BOARD_DIM; i++){
            tempVal = boardArr[row][i];

            //Flagging those that already appear in the row
            if (tempVal != 0){
                numCheck[tempVal-1] = false;
            }//End if
            
        }//End for
        
        //Checking the column
        for (i = 0; i < BOARD_DIM; i++){
            tempVal = boardArr[i][col];
            
            //Flagging those that already appear in the col
            if (tempVal != 0){
                numCheck[tempVal-1] = false;
            }//End if
            
        }//End for
        
        //Checking the square
        //To determine which 3x3 to check; I take the  row and col number, and convert them to the index of top left cell in the square using math!
        int idX = (row - (row%3) );
        int idY = (col - (col%3) );
        
        //Checking square based off the top left cell (right 2 and down 2)
        for (i = idX; i < idX + 3; i++){
            for (j = idY; j < idY + 3; j++){
                tempVal = boardArr[i][j];
                
                //Flagging those that already appear in the 3x3 square
                if (tempVal != 0){
                    numCheck[tempVal-1] = false;
                }//End if
                
            }//End for
        }//End for
        
        return numCheck;
        
    }//End cellCheck
    
    //Method which will return True or False if the board is a valid Sudoku board
    public boolean validateBoard(){
        boolean validCheck = true;
        int i, j;
        
        //To validate the board, check each row, column and 3x3-Square
        
        //If the row/column is invalid, it will be invalid for the entire row/column
        //Knowing this, I am only checking the diagonal instead of every cell. Reducing the overall time complexity
        for (i = 0; i < BOARD_DIM; i++){
            //Checking cell [i][j]
            validCheck = validateRowCol(0,i);
            if (!validCheck) return validCheck;
            validCheck = validateRowCol(1,i);
            if (!validCheck) return validCheck;
        }//End for
        
        //Checking the 3x3 Squares
        for (i = 0; i < 3; i++){
            for (j = 0; j < 3; j++){
                validCheck = validateSquare(i*3, j*3);
                if (!validCheck) return validCheck;
            }//End for
        }//End for
        
        
        return validCheck;
    }//End validateBoard
    
    //Method which will return True or False if the row/column is valid for sudoku
    //The first parameter determines if we are checking the row or column: 0->Row, 1->Column
    public boolean validateRowCol(int rowOrCol, int indexToCheck){
        boolean validCheck = true;
        int tempVal;
        int i;

        //Initializing an arry used to check each number in sudoku (1-9)
        boolean[] numCheck = new boolean[BOARD_DIM]; 
        for (i = 0; i < BOARD_DIM; i++)numCheck[i] = false;
        

        //Checking the row
        for (i = 0; i < BOARD_DIM; i++){
            
            //Setting value based on if we are checking the row or column
            if (rowOrCol == 0) {
                tempVal = boardArr[indexToCheck][i];
            } else {
                tempVal = boardArr[i][indexToCheck];
            }//End if

            //Do nothing
            if (tempVal == 0){
                //Dont need to do jack!
            
            //If the value is outside the range of Sudoku
            } else if (tempVal > BOARD_DIM || tempVal < 0){
                validCheck = false;
                break;
                
            //If the value has ocurred more than once
            }  else if (numCheck[tempVal-1]){
                validCheck = false;
                break;
                
            //Otherwise, update the flag to mark we've seen this value
            } else {
                numCheck[tempVal-1] = true;
            }//End if
            
        }//End for

        return validCheck;
    }//End validateRowCol
    
    //Method which will return True or False if the 3x3-Square the given cell is in, is valid for sudoku
    public boolean validateSquare(int row, int col){
        boolean validCheck = true;
        int tempVal;
        int i, j;
        int idX, idY;

        //Initializing an arry used to check each number in sudoku (1-9)
        boolean[] numCheck = new boolean[BOARD_DIM]; 
        for (i = 0; i < BOARD_DIM; i++)numCheck[i] = false;
        
        //Determining which 3x3 to check
        //I take the inputted row and column number, and convert them to the index of top left cell in the square
        idX = (row - (row%3) );
        idY = (col - (col%3) );
        
        //Checking square based off the top left cell (right 2 and down 2)
        for (i = idX; i < idX + 3; i++){
            for (j = idY; j < idY + 3; j++){
                
                //Storing the value
                tempVal = boardArr[i][j];

                //Do nothing
                if (tempVal == 0){
                    //Dont need to do jack!

                //If the value is outside the range of Sudoku
                } else if (tempVal > BOARD_DIM || tempVal < 0){
                    validCheck = false;
                    break;

                //If the value has ocurred more than once
                }  else if (numCheck[tempVal-1]){
                    validCheck = false;
                    break;

                //Otherwise, update the flag to mark we've seen this value
                } else {
                    numCheck[tempVal-1] = true;
                }//End if
            }//End for
        }//End for

        return validCheck;
    }//End validateBoard
    
    //Method which will return True if the board is completed, false if not
    public boolean isComplete(){
        boolean completeBool = true;
        
        int i,j;
        for (i = 0; i < BOARD_DIM; i++){
            for (j = 0; j < BOARD_DIM; j++){
                if (boardArr[i][j] == 0){
                    return false;
                }//End if
            }//End for
        }//End for
        
        return completeBool;
    }//End isComplete
    
}//End sudokuBoard
