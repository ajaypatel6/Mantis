/*
Curtis Penney - 5660659
COSC 2P05 - Assignment 1
Solving Sudoku with Backtracking
*/

package sudokuassignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SudokuAssignment {
    
    static sudokuBoard startBoard;
    static boolean continueBoolean = true;
    static int[][] importedNumbers;
    
    public static void main(String[] args) throws FileNotFoundException, SudokuException { 
        
        //We need to loop... FOREVER.. or atleast until continueBoolean is false...
        while (continueBoolean){

            importedNumbers = readFile();
            if (importedNumbers != null){
                
                //Creating the sudokuBoard
                startBoard = new sudokuBoard(importedNumbers);

                //Checking if the initial board is valid
                if (startBoard.validateBoard()) {
                    //The board is valid
                    if (solveBoard(0,0)){
                        System.out.println("The board has is solveable. One solution is as follows: ");
                        startBoard.printBoard();
                    } else {
                        System.out.println("There is no possible solution for this board.");
                    }//End if
                } else {
                    //The board is invalid
                    System.out.println("The board is invalid.");
                }//End if
            }//End if
            
            System.out.println("Do you wish to check another board? (Y/N)");
            String response = new Scanner( System.in ).nextLine();
            if (!response.equals("Y") && !response.equals("y")){
                //If you don't say Y or y, im just gonna exit... cause why not
                continueBoolean = false;
            }//End if

        }//End while

    }//End main

    
    //Function which will solve the given board, if possible
    private static boolean solveBoard(int cellRow, int cellCol){
        
        //Checking if the board is complete
        if (startBoard.isComplete()) {
            return true;
        }//End if
        
        int i;                              //Variable used for Iterating
        int newRow, newCol;                 //Variables used to calculate the Row and Col of the next cell to check
        boolean doneFlag = false;           //Boolean used to ensure we stop checking if the recursive calls returned true (a solution is found)
        boolean noOptionFlag = false;       //Boolean used to determine if the cell had no possible numbers
        boolean[] numCheck;                 //Boolean array which represents the possible values which can be placed in a cell
        
        //Getting which numbers can be placed in cell(row,col)
        numCheck = startBoard.cellCheck(cellRow, cellCol);      
        
        //Calculating the next cell ahead of time
        newCol = cellCol+1;
        newRow = cellRow;
        //Preventing OOB and ensuring we wrap
        if (newCol >= 9){
            newCol = 0;
            newRow++;
        }//End if
        
        //Ensuring the cell hasnt already been filled in (by the initial numbers...)
        if (numCheck != null){
            
            //Iterating through the possible values of the cell
            for (i = 0; i < 9; i++) {
                
                //If any of the numChecks are true, noOptionFlag will be set to true
                noOptionFlag = noOptionFlag || numCheck[i];
                
                //If the value at index i is True, we can place the value of i+1 in the cell. 
                if (numCheck[i]){
                    startBoard.placeVal(i+1, cellRow, cellCol); //Placing the value
                    doneFlag = solveBoard(newRow,newCol);       //Recursive step, sets boolean to if the board is solved
                    if (doneFlag) return doneFlag;              //If the board was solved, return true. dont need all solutions after all
                    startBoard.placeVal(0,cellRow, cellCol);    //Removing the value we placed
                }//End if
                
            }//End for 
            
            //If there are no values we can put in or there are no vlues we can put in which result in a valid board.
            if (!noOptionFlag || !doneFlag){
                return false;
            }//End if
            
        } else {
            //If the cell starts with a value, skip to the next one.
            return solveBoard(newRow, newCol);
        }//End if
        
        System.out.println("This *should* never print out. If you see me in the console, something happened I did not expect.");
        return false;
    }//End solveBoard
 
    
    //Method which is called to read a file into memory and will return the 2x2 array of integers
    public static int[][] readFile() throws FileNotFoundException {
        
        //Declaring variables
        Scanner scanner;                    //Scanner variable to read the file
        File file;                          //File variable to store the file
        int[][] readArr = new int[9][9];    //Initializing an array of size 9x9
        int i, j;                           //Iterator variables
        boolean fileReadingFlag = true;     //Boolean flag to ensure an error message only prints once
        
        scanner = new Scanner( System.in );
        System.out.print( "Please enter the filepath (ex. C:\\Users\\Curtis\\COSC_2P05\\As1\\board1.txt): " );
        String filePath = scanner.nextLine();
        
        //Debugging shortcut cause im a lazy boy... 
        //ID:PATHNAME_SHORTCUT
        if (filePath.equals("q")){
            filePath = "C:\\Users\\Curtis\\Desktop\\School\\COSC_2P05\\As1\\board1.txt";
        }else if (filePath.equals("qq")){
            filePath = "C:\\Users\\Curtis\\Desktop\\School\\COSC_2P05\\As1\\board2.txt";
        }else if (filePath.equals("qqq")){
            filePath = "C:\\Users\\Curtis\\Desktop\\School\\COSC_2P05\\As1\\board3.txt";
        }else if (filePath.equals("qqqq")){
            filePath = "D:\\As1\\board1.txt";
        }//End if
        
        //Attempting to open the filepath supplied...
        try {
            file = new File(filePath); 
            scanner = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("Invalid file path. Aborting.");
            return null;
        }//End tryCatch

        //Reading from the file and inserting into the array
        for (i = 0; i < 9; i++){
            for (j = 0; j < 9; j++){
                //Ensuring there exists an Int to read in.
                if (scanner.hasNextInt()){
                    //Adding the integer to the array
                    readArr[i][j] = scanner.nextInt();
                } else {
                    //If the file runs into an issue, it fills the rest with zeroes      
                    //Notifying the user of the issue (only once)
                    if (fileReadingFlag) {
                        System.out.println("There was an issue with the file starting at index [" + i + "][" + j +"'. The program has completed the board with 0's.");
                        fileReadingFlag = false;
                    }//End if
                    readArr[i][j] = 0;
                }//End if
            }//End for
        }//End for
        
        scanner.close();        //Closing the scanner
        return readArr;         //Return the Integers

    }//End readFile
    
}//End SudokuAssignment
