#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
int main() {
	int val;
	fstream fin("filein.txt",ios::in);
	while (fin) {
		fin>>val;
		if (fin.fail()) {
			fin.clear(ios::eofbit&fin.rdstate()|ios::goodbit);
			fin.ignore(1);
		} else cout<<val<<endl;
	}
}

