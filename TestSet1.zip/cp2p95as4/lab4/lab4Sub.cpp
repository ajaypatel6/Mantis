#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

//Unix to Dos
void utod () {
	char ch;
	ifstream fUnix ("sample.txt", ifstream::in);
	ofstream fDos ("sample2.txt", ofstream::out | ofstream::trunc);
	while (fUnix >> noskipws >> ch) {
		if (ch  == 0x0A) {
			fDos << char(0x0D);
		}//End if
		fDos << ch;
	}//End while	
}//End utod

//Dos to Unix
void dtou () {
	char ch;
	ofstream fUnix ("sample.txt", ofstream::out | ofstream::trunc);
	ifstream fDos ("sample2.txt", ifstream::in);
	while (fDos >> noskipws >> ch) {
		if (ch  != 0x0D) {
			fUnix << ch;
		}//End if
	}//End while	
}//End dtou

int main () {
	
	utod();
	dtou();
	
	
}//End main
