#include <iostream>
#include <iomanip>
using namespace std;

int inspectWidth(int values[16]){
	int max = 0;
	int temp = 0;
	int count;
	for (int i=0;i<1;i++) {
		temp = values[i];
		count = 1;
		while (temp > 0){
			temp = temp / 10;
			count++;
		}//End while
		if (count > max) max = count;
	}//End for	
	cout<<"hi"<<endl;
	return max + 1;
}//End inspectWidth

void cleanOutput(int values[16]) {
	int width = inspectWidth(values);
	for (int i=0;i<4;i++) {
		for (int j=0;j<4;j++) {
			cout<<setw(width)<<values[4*i + j];
		}//End for
		cout<<endl;
	}//End for
}//end cleanOutput

int main() {
	int values[16]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
	cleanOutput(values);
}
