#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

void printHello () {
	cerr<<"Hello you giant pile of garbage."<<endl;
}//End printHello

void printBye () {
	cerr<<"Good riddance!"<<endl;
}//End printBye

int main () {
	printHello();
	string line;
	ifstream file ("test.txt");
	
		while (getline(file,line)){
			cout<<line<<'\n';
		}//End while
		file.close();
	
	printBye();
}//End main
