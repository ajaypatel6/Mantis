//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

public class TSPDistMatrix {
    
    double [][] distMatrix;

    public TSPDistMatrix (int numVert, double coords[][]) {
        
        //Initializing the matrix
        distMatrix = new double [numVert][numVert];
        
        //Calculating the distances
        for (int i = 0; i < numVert; i++){
            for (int j = 0; j < numVert; j++){
                distMatrix[i][j] = Math.pow( Math.pow((coords[i][0]-coords[j][0]),2.0) + Math.pow((coords[i][1]-coords[j][1]),2.0) , 0.5);
            }//End for
        }//End for
        
    }//End TSPDistMatrix
    
    //Returns the Distance Matrix calculated
    public double[][] getDistMatrix(){
        return distMatrix;
    }//End getDistMatrix
    
}//End TSPDistMatrix
