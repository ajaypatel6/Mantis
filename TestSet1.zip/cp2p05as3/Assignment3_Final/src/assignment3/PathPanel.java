//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Polygon;
import javax.swing.JPanel;


public class PathPanel extends JPanel {

    private boolean clear;  // Clear the drawing area if true
    private Polygon poly = new Polygon();
    private int numPoints = 0;
    
    //Constructor
    public PathPanel(){
        this.setPreferredSize(new Dimension(600,400));
        this.setBackground(Color.WHITE);
        this.clear = true;
        repaint();
    }//End Constructor
    
    
    // Sets whether or not to clear the draw panel
    public void setClear(boolean cl){
        this.clear = cl;
    }//End setClear
    
    //Updates the path to the current best path
    public void updatePath(int dim, int [] inPath){
        clear = false;
        int xPoly[] = new int[dim];
        int yPoly[] = new int[dim];
        
        numPoints = dim;
        
        //Setting the Path's x y coords for the polygon
        for (int i = 0; i < dim; i++){
            xPoly[i] = (int)Assignment3.vertexCoord[inPath[i]][0]/3;
            yPoly[i] = (int)Assignment3.vertexCoord[inPath[i]][1]/3;
        }//End for
        
        //Sets the polygon to draw
        poly = new Polygon(xPoly, yPoly, numPoints);
        
        //Repaints the panel
        repaint(); 
        
    }//End setPath

    // This method will be run when repaint() is called.
    public void paintComponent(Graphics g) {

        if(this.clear){
            super.paintComponent(g);      // This will clear the draw area. Super is necessary here.
            return;
        } else{  
            super.paintComponent(g);   // You must clear before drawing or weird stuff will happen. (Ghost buttons get drawn)
            
            //Draw the polygon
            g.drawPolygon(poly);
            
        } // end else
    } // end paintComponent
    
}//End PathPanel
