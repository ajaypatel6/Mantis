//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

import java.util.concurrent.Semaphore;

public class SolveTSP implements Runnable {
    
    private int threadNum;                                  //Number of threads
    private int [] initialPath;                             //The starting path
    private int Num_Iterations;                             //Number of iterations
    private int Num_Mutations;                              //Number of mutations
    private int Num_Mutation_Degree;                        //How many spots to swap in a mutations (degree)
    private volatile boolean stop;                          //Stop boolean
    private static Semaphore lock = new Semaphore(1);       //Lock to ensure threads wait
    
    @Override
    public void run() {
        
        //Doing the stuff!
        for (int j = 0; j < Num_Iterations; j++) {
            
            //Breaking early if the Thread has been stopped
            if (stop){
                break;
            }//End if
            
            //Generating the initial path
            initialPath = new GeneratePath(Assignment3.vertexNum).getPath();
            
            //Mutating the path
            MutatePath mutant = new MutatePath(Num_Mutations, Num_Mutation_Degree, initialPath);
            
            //Attempting to update the best path
            try {
                lock.acquire();
                updateBest(mutant, j);
                lock.release();
            } catch (InterruptedException ex) {}//End Try-Catch
   
        }//End for
        
    }//End Overrided
    
    //Function call updates the best path stored and redraws
    private void updateBest(MutatePath inMutant, int iterNumber){
        
        //If its an improvement
        System.out.print("Thread " + threadNum + ": Iteration " + iterNumber + ". Best path found " + inMutant.getBestCost() +". ");        
        if (Assignment3.bestCost > inMutant.getBestCost()){
            
            //Take it
            Assignment3.bestCost = inMutant.getBestCost();
            Assignment3.bestPath = new DeepCopy(inMutant.getBestPath()).getCopiedArr();
            
            //Updating the UI
            Assignment3.solveUI.pathCanvas.updatePath(Assignment3.vertexNum, Assignment3.bestPath);
            Assignment3.solveUI.bestField.setText("" + Assignment3.bestCost);
            
            System.out.println("New Global Best found " + Assignment3.bestCost);
            
        }else {
            System.out.println("Worse than Global Best");
        }//End if
    }//End updateBest
    
    //Constructor
    public SolveTSP(int iter, int mut, int deg, int num){
        Num_Iterations = iter;
        Num_Mutations = mut;
        Num_Mutation_Degree = deg;
        threadNum = num;
        stop = false;
    }//End Constructor
    
    //Stops the thread
    public void stop () {
        stop = true;
    }//End stop

}//End SolveTSP
