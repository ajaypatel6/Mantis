//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

import java.io.FileNotFoundException;

public class Assignment3 {
    
    static SolverGUI solveUI;                           //Variable for the UI
    static int vertexNum;                               //Varibale for number of nodes
    static double [][] vertexCoord;                     //Array to store the Coordinates of each node
    static double [][] vertexDistMatrix;                //Distance Matix
 
    static int [] bestPath = null;                      //The current Best Path found
    static double bestCost = Integer.MAX_VALUE;         //The Best Path's value

    //Main Constructor
    public static void main(String[] args) throws FileNotFoundException {
        
        solveUI = new SolverGUI("This be the Title");   //Initializing the UI
        solveUI.setVisible(true);                       //Setting to visible
        
    }//End main
    
}//End Assignment2
