//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

import static assignment3.Assignment3.vertexNum;

public class MutatePath {
    
    int [] bestPath;        //Best Path found so-far this mutations
    int [] currPath;        //Current path
    int [] mutaPath;        //Mutated Path
    double bestCost;        //Best cost so far
    double currCost;        //Current cost
    double mutaCost;        //Mutated cost
    
    
    //Takes a path, and mutates it the given number of mutations by the given mutation degree
    public MutatePath(int numMutations, int mutationDegree, int [] inPath) {
        
        //Copies and evaluates the current path
        currPath = new DeepCopy(inPath).getCopiedArr();
        currCost = evalPath(currPath);
        
        //Copies and evaluates the current best path
        bestPath = new DeepCopy(currPath).getCopiedArr();
        bestCost = currCost;
        
        //Mutating it numMutation times
        for (int i = 0; i < numMutations; i++) {
            
            //Mutates and evaluates the new path
            mutaPath = mutate(currPath, mutationDegree);
            mutaCost = evalPath(mutaPath);
            
            //If the mutation is an improvement
            if (mutaCost < currCost){
                
                //Store it as our new current
                currCost = mutaCost;
                currPath = new DeepCopy(mutaPath).getCopiedArr(); //Deep Copy
                
                //If it is an improvement on our global
                if (currCost < bestCost){
                    bestCost = currCost;
                    bestPath = new DeepCopy(currPath).getCopiedArr(); //Deep Copy
                }//End if
            
            }//End if
            
        }//End for

    }//End MutatePath
    
    //Function to get the best cost value calculated
    public double getBestCost(){
        return bestCost;
    }//End getBestCost
    
    //Function to get the best path determined
    public int[] getBestPath(){
        return new DeepCopy(bestPath).getCopiedArr();
    }//End getBestPath
    
    //Function which will take the given path and mutate it to the specified degree
    private int[] mutate(int [] inPath, int degree) {
        
        if (degree > inPath.length){
            throw new IllegalArgumentException("Degree must be less than or equal to the number of items in the Path.");
        }//End if
        
        int [] newPath = new DeepCopy(inPath).getCopiedArr();
        int [] mutation;
        
        //GeneratePath creates a new random path.
        //This random path will represent the mutations to ocurr
        //The value at index 0 is the first node to mutate, index 1 is the second node to mutate.. etc...
        //It generates a mutation for up to the entire path, however we will only use as many as specified in the value degree
        mutation = new GeneratePath(vertexNum).getPath();

        //Mutating based off the degree of the mutation
        int temp = inPath[mutation[0]];
        for (int i = 0; i < degree; i++) {
            if (i == degree - 1) {
                newPath[mutation[i]] = temp;
            } else {
                newPath[mutation[i]] = newPath[mutation[i+1]];
            }//End if
        }//End for
        
        return newPath;
        
    }//End mutate
    
    //Function which will evaluate the total cost of a path
    private double evalPath(int [] thePath) {
        
        int pathVal = 0;
        
        //Traversing the path
        for (int i = 0; i < thePath.length; i++){
            
            if (i == thePath.length - 1) {
                pathVal += Assignment3.vertexDistMatrix[thePath[i]][thePath[0]];
            } else {
                pathVal += Assignment3.vertexDistMatrix[thePath[i]][thePath[i+1]];
            }//End if
            
        }//End for
        
        //System.out.println(pathVal);
        return pathVal;
        
    }//End evalPath
    
}//End MutatePath Class
