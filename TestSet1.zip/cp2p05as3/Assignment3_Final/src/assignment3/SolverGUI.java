//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import javax.swing.*;


public class SolverGUI extends JFrame implements ActionListener{
    
    int numThreads;
    int numSearches;
    int numIter;
    boolean check;
    
    JPanel parameters;
    PathPanel pathCanvas;
    JLabel pathLabel;
    JLabel bestLabel;
    JLabel thrdLabel;
    JLabel srchLabel;
    JLabel iterLabel;
    JTextField pathField;
    JTextField bestField;
    JTextField thrdField;
    JTextField srchField;
    JTextField iterField;
    JButton runButton;
    

    //Generating the UI
    public SolverGUI( String title ) {
        super( title );
        setSize( 700, 600 );
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        
        pathLabel = new JLabel("File Path");
        pathField = new JTextField(20);
        bestLabel = new JLabel("Current Best");
        bestField = new JTextField(20);
        thrdLabel = new JLabel("Number of Threads");
        thrdField = new JTextField(20);
        thrdField.setText("4");
        srchLabel = new JLabel("Number of Searches");
        srchField = new JTextField(20);
        srchField.setText("1000000");
        iterLabel = new JLabel("Number of Iterations");
        iterField = new JTextField(20);
        iterField.setText("30");
        runButton = new JButton("Run Search");
        
        parameters = new JPanel(new FlowLayout(FlowLayout.LEFT));
        parameters.add( pathLabel );
        parameters.add( pathField );
        parameters.add( bestLabel );
        parameters.add( bestField );
        parameters.add( thrdLabel );
        parameters.add( thrdField );
        parameters.add( srchLabel );
        parameters.add( srchField );
        parameters.add( iterLabel );
        parameters.add( iterField );
        runButton.addActionListener(this);
        parameters.add( runButton );
        pathCanvas = new PathPanel();
        parameters.add(pathCanvas);
        add(parameters);  
        
    }//End constructor

    @Override
    public void actionPerformed(ActionEvent e) {

        //Initializing a boolean
        check = false;
        try {
            
            //Resetting from previous runs
            Assignment3.bestPath = null;
            Assignment3.bestCost = Integer.MAX_VALUE;
            pathCanvas.setClear(true);
            pathCanvas.repaint();
            
            //Getting the File Name
            String fileName = pathField.getText();
            
            //Reading the file
            readFileData(fileName);
            
            //Reading the values from the ui
            numThreads = Integer.parseInt(thrdField.getText());
            numSearches = Integer.parseInt(srchField.getText());
            numIter = Integer.parseInt(iterField.getText()); 
            
            //Marking we read the data fine
            check = true;
            
        } catch (Exception ex){}

        //Only creating the threads if we read the info from the UI fine
        if (check){
            //Creating the threads
            SolveTSP solver [] = new SolveTSP [numThreads];
            Thread [] solverThread = new Thread[numThreads];
            for (int i = 0; i < numThreads; i++){
                solver[i] = new SolveTSP(numIter, numSearches, 3, i);
                solverThread[i] = new Thread(solver[i]);
                solverThread[i].start();
            }//End for
            
        }//End if

    }//End Action
    
    //Reads the file information and stores in variables
    private void readFileData(String fileName) throws FileNotFoundException{
        
        //Reading in the file and storing the information
        ReadFile inputData = new ReadFile(fileName);
        Assignment3.vertexNum = inputData.getLocationNumber();
        Assignment3.vertexCoord = inputData.getLocationCoordinates();
        
        //Calculating the Distance Matrix and storing
        TSPDistMatrix distMat = new TSPDistMatrix(Assignment3.vertexNum, Assignment3.vertexCoord);
        Assignment3.vertexDistMatrix = distMat.getDistMatrix();
        
    }//End readFileData
    
    
    
}//End SolverGUI
