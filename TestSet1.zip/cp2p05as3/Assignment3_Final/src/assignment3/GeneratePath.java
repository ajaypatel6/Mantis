//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

//Generates a random path
public class GeneratePath {
    
    int [] genPath;
    
    //Function which will take an integer and generate the initial path to take for th GA
    public GeneratePath(int numVert){
        
        //Initializing the array
        genPath = new int[numVert];
        
        //Filling with initial values
        for (int i = 0; i < numVert; i++){
            genPath[i] = i;
        }//End for
        
        //Shuffling the array using Fisher-Yates Shuffle
        Random rnd = ThreadLocalRandom.current();
        for (int i = numVert - 1; i > 0; i--){
          int index = rnd.nextInt(i + 1);
          int a = genPath[index];
          genPath[index] = genPath[i];
          genPath[i] = a;
        }//End for
        
    }//End genInitialPath
    
    //Function which returns the path generated
    public int[] getPath(){
        return new DeepCopy(genPath).getCopiedArr();
    }//End getInitialPath
    
}//End GenerateInitialPath Class
