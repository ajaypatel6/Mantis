//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFile {
    
    private int locationNum;
    private double [][] locationCoord;
    
    //Reading the file off of the given string
    public ReadFile(String filePath) throws FileNotFoundException {
        
        //Variable Declaration
        File dataFile;
        Scanner dataScanner;

        //Shortcuts
        if (filePath.equals("a")) filePath = "Z:/Y4/COSC2P05/Assignment3/berlin52.txt";
        if (filePath.equals("b")) filePath = "C:/Users/Curtis/Desktop/School/COSC2P05/Assignment3/berlin52.txt";
        
        try {
            
            //Openin the file and starting to read it
            dataFile = new File(filePath);  
            dataScanner = new Scanner(dataFile);
            
            //Reading the number of locations in the TSP
            locationNum = dataScanner.nextInt();        
            
            //Initializing the array
            locationCoord = new double [locationNum][2];    
            
            //For each location in the data
            for (int i = 0; i < locationNum; i++) {
                dataScanner.nextInt();                          //Skipping the first number
                locationCoord[i][0] = dataScanner.nextDouble();    //Reading the X Coord
                locationCoord[i][1] = dataScanner.nextDouble();    //Reading the Y Coord
            }//End for

        } catch (FileNotFoundException  e){
            throw e;
        }//End Try-Catch block

        
    }//End readFile
    
    //Gets the number of location read from the file
    public int getLocationNumber(){
        return locationNum;
    }//End  getLocationNumber
    
    //Gets the location coordinates read from th file
    public double[][] getLocationCoordinates(){
        return locationCoord;
    }//End getLocationCoordinates

}//End ReadFile class
