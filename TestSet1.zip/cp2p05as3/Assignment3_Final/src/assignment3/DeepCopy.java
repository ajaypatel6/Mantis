//COSC 2P05 Assignment 3
//Curtis Penney - 5660659

package assignment3;

//Class which is used enure the path arrays deep copy and not shallow copy
public class DeepCopy {
    
    int [] copiedArr;
    
    public DeepCopy (int [] arrToCopy) {
        
        int temp = arrToCopy.length;
        copiedArr = new int[temp];
        
        //Copies the values
        for (int i = 0; i < temp; i++) copiedArr[i] = arrToCopy[i];
        
    }//End constructor
    
    //Gets the copied array
    public int[] getCopiedArr(){
        return copiedArr;
    }//End getCopiedArr
    
}//End DeepCopy
