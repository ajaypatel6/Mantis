package InfToPost;

import CharStacks.*;
import BasicIO.*;


/** This class is a program to perform infix to postfix conversion. It
  * consecutively reads strings representing infix expressions and then produces
  * and displays the equivalent postfix expression. The process involves a stack
  * of characters.
  *
  * @see  CharStack
  * @see  ConCharStack
  *
  * @author  your name
  *
  * @version  1.0 (Feb. 2015)                                                    */

public class InfToPost {
  
  
  private BasicForm  display;  // form for UI
  
  
  /** The constructor repeatedly reads infix expressions, converts them to
    * postfix and displays them.                                               */
  
  public InfToPost ( ) {
    display= new BasicForm("Convert", "Clear", "Quit");
    buildForm();
    while(true){
      int button=display.accept();
      if(button==2)break;
      switch(button){
        case 0:
          String infix= display.readString("infix");
          String postfix = translate(infix.trim());
          display.writeString("postfix", postfix);
          
          break;
        case 1:
          display.clearAll();
          break;
          
          
          
      }
      
      
    }
    display.close();
    
    
  }; // constructor
  
  
  /** This method builds the form for expression string IO.                    */
  
  private void buildForm ( ) {
    
    display.setTitle("Infix to Postfix");
    display.addTextField("infix","Infix");
    display.addTextField("postfix","Postfix");
    
  };  // buildForm
  
  
  /** This method does the actual conversion from infix to postfix. It
    * concatenates a dummy operator to the end of the input string and then
    * processes the string from left to right, placing operands into the output
    * string and pushing or popping operators to a stack depending on their
    * relative priorities.
    *
    * @param  in  the infix expression to be converted.
    *
    * @return   String  the equivalent postfix expression.                     */
  
  private String translate ( String in ) {
    char[]infix=(in+'#').toCharArray();
    char[]postfix = new char [in.length()];
    int oPos = 0;
    CharStack opStack = new ConCharStack(10);
    opStack.push('$');
    
    for(char c:infix){
      switch(c){  
        case '+':
        case '-':
        case '/':
        case '^':
        case '#':
        case '*':
          while(prio(opStack.top()) >= prio(c) ){
          postfix[oPos] = opStack.pop();
          oPos++;
        }
          opStack.push(c);
          break;
          
          
        default:
          postfix[oPos]=c;
          oPos++;
          break;
      }
      
      
      
    }
    return new String(postfix);
    
    
    
  }; // translate
  
  
  /** This method returns the relative priority of an operator.
    *
    * @param  c  the operator
    *
    * @return  int  the relative priority of c.                                */
  
  private int prio ( char c ) {
    switch(c){
      case '$':
        return -1;
        
      case '#':
        return 0;
        
      case '+':
      case '-':
        return 1;
        
      case '/':
      case '*':
        return 2;

    }
    return 0;//never actually executed
    
    
    
    
  }; // prio
  
  
  public static void main ( String[] args ) { InfToPost i = new InfToPost(); };
  
  
} // InfToPost