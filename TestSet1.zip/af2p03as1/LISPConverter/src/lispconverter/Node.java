/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lispconverter;

/**
 *
 * @author Andrew Folkerson StNum #5764105
 * 09/23/2017
 * This class describes the nodes used for implementation of the linked structure
 * of the LISPConverter
 */
public class Node {
    
    public Node right; //the node to the right in the sequence
    public String  item; //the Item to be wrapped
    public Node down; //the node below in the sequence

    //This constructor
    public Node ( String i, Node r, Node d){
        right = r;
        item = i;
        down = d;
        
    }; //constrcutor
    

    
    
}//Node

