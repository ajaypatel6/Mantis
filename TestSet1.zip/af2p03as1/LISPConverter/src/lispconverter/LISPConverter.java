/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lispconverter;

import BasicIO.*;
import java.util.StringTokenizer;

/**
 *
 * @author Andrew Folkerson. StNum: #5764105
 * 09/23/2017
 * This class uses a linked list to translate LISP Commands into a Java
 * representation. The commands are inputted via a BasicForm and the outputs
 * are also sent to the BasicForm
 * 
 */
public class LISPConverter {
    
    private BasicForm form;
    private Node      list;
    private Node      p;
    private Parser    parse;
    private StringTokenizer token;
    private String   result;
    private boolean  one;
    private boolean  two;
    
/*this constructor initializes the variables and sets up the form*/
    public LISPConverter (){
        String first = null;
        String second = null;
        String third = null;

        list = new Node(null,null,null);
        p =list;
        form = new BasicForm("Convert", "Quit");
        setUpForm();
        for(;;){
            result = "";
            one = true;
            two = true;
            p = list;
            int button = form.accept();
            if(button==0){
                String input= form.readString("input");
                form.clearAll();
                if(input !=null){
                    parse = new Parser (input);
                    token = parse.getTokenizer(); 
                    if(token.hasMoreTokens()){
                        first = token.nextToken();
                    }
                    if(token.hasMoreTokens()){
                        second = token.nextToken();
                    }
                    if(token.hasMoreTokens()){
                        third = token.nextToken();
                    }
                    if(first.equals("setq")&& third.equals("'")) {
                        Node m = list;
                        while(m.right!=null){
                            m = m.right;
                            
                        }
                        m.right = new Node (second, null, null);
                        p = m.right;
                        System.out.println(p.item + " p's item");
                        setq(token);
                        form.clearAll();
                        form.writeString("output", "List added");
                        
                    
                }
                    else if(first.equals("print")){
                        form.writeString("output",print(second));
                    }
                    else if (first.equals("setq")& !third.equals("'")){
                        copy(second, third);
                    }
                
                }
                else{
                    form.writeString("output", "ERROR! Please enter a command");
                }
  
                
            }
            if(button==1){
                form.close();
                break;  
               
            }
        }             
    }//constructor
    
    //This method sets up the form
    private void setUpForm(){
        form.addTextArea("input","LISP Notation");
        form.addTextArea("output","Conversion");
        form.setEditable("output",false);
    }//setUpForm
    
    //This method uses recursion to add a list to the linked structure
    private void setq (StringTokenizer t){
        if(!t.hasMoreTokens()){
           return;

           
       }
        String a = t.nextToken();

       if(a.equals("(") & p.down==null){
            p.down = new Node(null, null, null);
            p=p.down;
            setq (t);
        
        
    }
       if(a.equals("(") & p.down!=null){
           p.right = new Node (null, null, null);
           p = p.right;
           setq (t);
       }
       if(!a.equals("(")|!a.equals(")")|!a.equals("'")){
           Node q = p;
           q.item = a;
           while(!a.equals("(")|!a.equals(")")|!a.equals("'")&& t.hasMoreTokens()){
               q.right = new Node(a, null, null);
               q = q.right;
               a = t.nextToken();
               
           }  


        setq (t);           
           
       }           
    }//setq
    
//This method deals with the special cases of printing and calls the makeOutput method
    private String print(String check){
        Node q = list.right;
        System.out.println(check);
        if(q==null){
            return "nil";
        }
        while(q!= null && !q.item.equals(check)){
            q=q.right;
        }
        if(q==null){
            return "nil";
        }
        else{
            q = q.down;
            if(q==null){
               return "Empty List"; 
            }
            else{
                result =result;
                String result = makeOutput(q);
                if(two){
                    return result+" ";
                }
                else{
                    return result+") ";
                }
            }
        }
    }//print
    
    //This method makes the output recursively when the print method is called
    private String makeOutput(Node q){
        if(q.item !=null){
            if(!one)two=false;
            int i =0;
            while(q.right!=null && q.right.item != null){
                result = result + q.item+" ";
                q = q.right;
                i++;
            }
            if(i ==0){
                result = result + q.item+ " ";
        }
            else{
               result = result + q.item+ " "+") "; 
            }
        
           one = false; 
            
        }
        if(q.down!=null){
            Node p=q.down;
            result = result + "( ";
            makeOutput(p);
        }
        if(q.right!=null){
            Node p=q.right;
            makeOutput(p);
            
        }
        return result;
    }//makeOutput
    
    //This method handles copying lists and deleting lists from the structure
    private void copy(String first, String second){
        String command = "";
        if( !second.equals("nil")){
            Node a = list;
            Node b = null;
            if(a.right !=null){
            do{
             b = a;   
             a = a.right;
             if(a.item.equals(second)){
                 command = command + print(a.item);
             }
             if(a.item.equals(first)){
                 b.right = b.right.right;
                 
             }   
        }while(a.right != null);
            Node j = list;
            while(j.right!=null){
                j=j.right;
            }
            j.right = new Node(first, null, null);
            p = j.right;
            Parser nInput = new Parser(command);
            StringTokenizer p = nInput.getTokenizer();
            setq(p);
            form.writeString("output","Item Copied");   
        }    
        }
        else if(second.equals("nil")){
            Node a =list;
            Node b = list;
            boolean delete = false;
            while(b.right!=null){
                b = a;
                a = a.right;
                if(a.item.equals(first)){
                    b.right=b.right.right;
                    a = a.right;
                    delete = true;
                }
                
            }
            if(delete)form.writeString("output", "Item deleted");
            else form.writeString("output", "Item not found");    
        }
        else form.writeString("output","please input a valid command");
    }//copy

    public static void main(String[] args) {LISPConverter s = new LISPConverter();    }  
}//LISPConverter
