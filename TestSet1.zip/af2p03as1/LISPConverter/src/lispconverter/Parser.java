/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lispconverter;

import java.util.StringTokenizer;

/**
 *
 * @author Andrew Folkerson StNum #5764105
 * 09/23/2017
 * This class translates the user input into a manageable format using a
 * StringTokenizer
 */
public class Parser {
    StringTokenizer t;//the tokenizer
    
    /*This constructor takes in a string and formats it to be compatible
     * with a StringTokenizer*/
    public Parser(String s){
        
        int i =0;
        char[] a = s.toCharArray();
        String mod = "";
        while (i<s.length()){
            if (a[i]=='('|a[i]==')'|a[i]=='\''){
                mod = mod + " "+a[i]+" ";
            }
            else{
                mod = mod + a[i];
            
                
            }
            i++;
        }
        t = new StringTokenizer (mod," ");
        
    }//constructor
    
    public StringTokenizer getTokenizer(){
        return t;
    }
    
    
}//Parser
