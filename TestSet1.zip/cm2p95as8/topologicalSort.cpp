#include <iostream>
#include <string>
#include <fstream>
using namespace std;

//Author: Cesar Moreno, Student #: 5727722
//COSC 2P95 - Lab Exercise #8

int numVertices = 0;
int numEdges = 0;

string labels[20];
bool edges[20][20];
bool visited[20];
int indegreeCount[20];


void showGraph(std::string labels[20], bool edges[20][20], int numVertices) {
	std::cout<<"Vertices:"<<std::endl;
	for (int i=0;i<numVertices;i++)
		std::cout<<(i?", ":"")<<'['<<i<<':'<<labels[i]<<']';
	std::cout<<std::endl<<std::endl;
	
	std::cout<<"Edges:"<<std::endl;
	for (int from=0;from<numVertices;from++) {
		std::cout<<labels[from]<<" -> ";
		bool mult=false;
		for (int to=0;to<numVertices;to++)
			if (edges[from][to]) {
				std::cout<<(mult?",":"")<<labels[to];
				mult=true;
			}
		std::cout<<std::endl;
	}
}


void getIndegrees() {
	int indegree = 0;
	for (int a = 0; a < numVertices; a++) {
		if (visited[a] == false) {
			indegree = 0;
			for (int b = 0; b < numVertices; b++) {
				if (visited[b] == false && edges[b][a] == true){
					indegree+=1;
				}
			}
			indegreeCount[a] = indegree;
        } 
        else {
			indegreeCount[a] = 0;
		}
	}
}


void topologicalSort(int numSorted) {
	int indegree = 0;
    getIndegrees();

    if (numSorted >= numVertices) {
		return; //This means that the whole graph has been traversed
	}
    for (int a = 0; a < numVertices; a++) {
		if(indegreeCount[a] == false && visited[a] == false){
			indegree += 1; 
			cout<<labels[a]<<" ";
			visited[a] = true;
		}
	}
	
	if (indegree == 0) {
        cout<<endl;
        cout<<".\n"".\n"".\n";
		cout<<"ALERT: Cyclic dependencies found during sorting; no topological sort possible."<<endl;
		return;
	}

    else {
		return topologicalSort(numSorted+indegree);
	}
}

int main() {
	std::string filename;
	std::cout<<"Graph filename: ";
	std::cin>>filename;
	std::cout<<"Using "<<filename<<std::endl;
	fstream fin(filename.c_str(),ios::in);
	
	fin>>numVertices;
	for (int i=0;i<numVertices;i++)
		fin>>labels[i];
	for (int i=0;i<20;i++){
		for (int j=0;j<20;j++){
			edges[i][j]=false;
        }
    }
        
	fin>>numEdges;
	for (int i=0;i<numEdges;i++) {
		int from,to;
		fin>>from;
		fin>>to;
		edges[from][to]=true;
	}
	
	std::cout<<"File loaded.\nLoaded graph.\n"<<std::endl;;
	fin.close();

	showGraph(labels,edges,numVertices);
    cout<<endl;
    cout<<"Topological Sort found!"<<endl;
	topologicalSort(0);
    cout<<endl;
}
