#include <iostream>
#include "Set.h"

Set::Set(const bool elements[255], int capacity) {
    this->capacity = capacity;
    for(int i = 0; i < 255; i++) 
        (this->elements)[i] = elements[i];
};

Set::Set(){ //Constructor
    this->elements[255];
    this->capacity=0;
}

Set::Set(short capacity){ //Constructor
    this->elements[255];
    this->capacity = capacity;
}

Set Set::operator+(const Set &other) const{ //Union
    bool outElements[255];
    int newCapacity = ((this->capacity > other.capacity))?this->capacity:other.capacity;

    for (int a=0; a<newCapacity; a++){
        if(this->elements[a] || other.elements[a]){
            outElements[a] = true;
            newCapacity++;
        }
    }

    Set outSet(outElements, newCapacity);
    return outSet;
}

Set Set::operator+(const int &other) const{ //Add an element --> NEED TO REVIEW

    if (this->capacity < other){
        return *this ;
    }

    bool outElements[255];

    for (int a=0; a<this->capacity; a++){
        if(this->elements[a]){ //NEEDS TESTING FIRST
            outElements[a]=true;
        }
    }

    outElements[other] = true;

    Set outSet(outElements, this->capacity);
    return outSet;
}

Set Set::operator-(const Set &other) const{ //Difference

    bool outElements[255];
    int newCapacity = ((this->capacity > other.capacity))?this->capacity:other.capacity;

     for (int a=0; a<newCapacity; a++){
        if(this->elements[a] != other.elements[a]){
            outElements[a] = true;
            newCapacity--; //TEST?
        }
    }
    
    Set outSet(outElements, newCapacity);
    return outSet;
}

Set Set::operator-(const int &other) const{ //Effectively 'remove element if present' --> NEEED TO REVIEW

  if (this->capacity < other){
        return *this ;
  }

    bool outElements[255];

    for (int a=0; a<this->capacity; a++){
        if(this->elements[a]){ //NEEDS TESTING FIRST
            outElements[a]=true;
        }
    }

    outElements[other] = false;

    Set outSet(outElements, this->capacity);
    return outSet;

}


Set Set::operator~() const{ //Complement
    bool outElements[255];
    int newCapacity = 0;
    
    for (int a=0; a<this->capacity; a++){
        if(this->elements[a]==false){
            outElements[a]=true;
            newCapacity++;
        }
    }

    Set outSet(outElements, newCapacity);
    return outSet;
} 

Set Set::operator+() const{ //Set of universe (i.e. set of all possible elements)
    bool outElements[255];
    for (int a=0; a<this->capacity; a++){
        outElements[a]=true;
    }

    Set outSet(outElements, this->capacity);
    return outSet;
}

Set Set::operator-() const{ //Empty set (with same capacity, of course)
    bool outElements[255];
    for (int a=0; a<this->capacity; a++){
        outElements[a] = false;
    }

    Set outSet(outElements, this->capacity); 
    return outSet;
}

Set Set::operator^(const Set &other) const{ //Intersection
    bool outElements[255];
    int newCapacity = ((this->capacity > other.capacity))?this->capacity:other.capacity; //TEST?

    for (int a=0; a<newCapacity; a++){
        if(this->elements[a] && other.elements[a]){
            outElements[a] = true;
            newCapacity++;
        }
    }

    Set outSet(outElements, newCapacity);
    return outSet;
}

Set Set::operator^(const int &other) const{ //Intersection with element --> NEED TO REVIEW

   if (this->capacity < other){
        return *this ;
    }

    bool outElements[255];
    outElements[other] = true;
    for (int a=0; a<this->capacity; a++){
        if(this->elements[a] && outElements[other]){ //NEEDS TESTING FIRST 
            outElements[a]=true;
        }
    }

    Set outSet(outElements, this->capacity);
    return outSet;
}


bool Set::operator<=(const Set &other) const{ //Subset

    for (int a=0; a<other.capacity; a++){
        if (this->elements[a]){
            return true;
        }
    }
    return false;
}

bool Set::operator<(const Set &other) const{ //Strict subset 

    for (int a=0; a<other.capacity; a++){
        if (this->elements[a] == other.elements[a] && this->capacity != other.capacity){
            return true;
        }
    }
    return false;
}

bool Set::operator>=(const Set &other) const{ //Superset

    for (int a=0; a<this->capacity; a++){
        if (other.elements[a]){
            return true;
        }
    }
    return false;
}

bool Set::operator>(const Set &other) const{ //Strict superset 
    for (int a=0; a<this->capacity; a++){
        if (other.elements[a] == this->elements[a] && this->capacity != other.capacity){
            return true;
        }
    }
    return false;
}

bool Set::operator==(const Set &other) const{ //Test for set equality

    for (int a=0; a<this->capacity; a++){
        for (int b=0; b<other.capacity; b++){
            if (this->elements[a] == other.elements[b]){
                return true;
            }
        }
    }
    return false;
} 

bool Set::operator!=(const Set &other) const{ //Test for set inequality

    for (int a=0; a<this->capacity; a++){
        for (int b=0; b<other.capacity; b++){
            if (this->elements[a] != other.elements[b]){
                return true;
            }
        }
    }
    return false;
}

bool Set::operator!() const{ //Test for empty set

    for (int a=0; a<this->capacity; a++){
        if (this->elements[a] != false){
            return false;
        }
    }
    return true;
}

int Set::operator()() const{ //cardinality of set i.e. |Set|
    int cardinality = 0;
    for (int a=0; a<capacity; a++){
        if(this->elements[a]){
            cardinality++;
        }
    }
    return cardinality;
}

bool Set::operator[](const int &pos) const{ //Test for 'is element of'
    if (pos > capacity){
        return false;
    }
    else{
        if (this->elements[pos]){
            return true;
        }
        return false;
    }
}

std::ostream& operator<<(std::ostream &out, const Set &set){
    int capacity = set.capacity;
    int count = 0;
    std::cout<<"{";
    while(true){
        if(count > capacity) break;
        std::cout<<set.elements[count];
        count++;
    }
    std::cout<<"}"<<std::endl;
}

std::istream& operator>>(std::istream &in, Set &set){
    bool arr[255];
    int cap=set.capacity;
    char open;
    in>>open;
    if (in.fail() || open!='{') {
        in.setstate(std::ios::failbit);
        return in;
    }

    for (int i=0;i<cap;i++)
                arr[i]=false;

    std::string buff;
    std::getline(in,buff,'}');

    std::stringstream ss(buff);
    std::string field;
    while (true) {
        std::getline(ss,field,',');
    if (ss.fail()) break;
        int el;
        std::stringstream se(field);
        se>>el;
        if (el>=0&&el<cap)
            arr[el]=true;
    }
    set=Set(arr,cap);
}

int Set::getCapacity() const{
    return this->capacity;
}


int main(){

    Set s1(3);
    Set s2(4);
    Set s3(5);
    Set s4;

    std::cout<<"First set ({x,y,z}): ";
    std::cin>>s1;
    std::cout<<"A: "<<s1<<std::endl;

    std::cout<<"Second set: ";
    std::cin>>s2;
    std::cout<<"B: "<<s2<<std::endl;

    std::cout<<"Third set: ";
    std::cin>>s3;
    std::cout<<"C: "<<s3<<std::endl;

    std::cout<<"Fourth set: ";
    std::cin>>s4;
    std::cout<<"D: "<<s4<<std::endl;
    
}