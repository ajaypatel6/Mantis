package Lab_10_1; 

import BasicIO.*; 
import static BasicIO.Formats.*;


public class MakeInvFile {
  
  private ASCIIDataFile      invData; 
  private BinaryOutputFile   newInvData; 
  private ASCIIDisplayer     display; 
 
  public MakeInvFile () {
    
    Item anItem; 

    invData    = new ASCIIDataFile(); 
    newInvData = new BinaryOutputFile(); 
    display    = new ASCIIDisplayer(); 
    int objectsCreated = 0; 
    
    for (; ;) {
      anItem = new Item(invData);
      if (invData.isEOF()) break; 
      newInvData.writeObject(anItem);
      objectsCreated = objectsCreated + 1; //Can also use the statement: objectsCreated++; 
    }; // end for loop
    
    display.writeString("Number of records created: ");
    display.writeInt(objectsCreated); 
    
   invData.close(); 
   newInvData.close();
   display.close(); 
    
  }// constructor
  
  
  
    public static void main ( String[] args ) { MakeInvFile i = new MakeInvFile(); };
  
} //MakeInvFile
