package Lab_10_1;


import BasicIO.*;
import static BasicIO.Formats.*;


/** This class is a program to do a simple inventory control producing a report.
  * 
  * @author David Hughes
  * 
  * @version 1.1 (Nov. 2013)                                                    */

public class Inventory {
    
    
    private BinaryDataFile    invData;     // data file for inventory info
    private BasicForm        display;     // GUI for user input
    private BinaryOutputFile  newInvData;  // data file for updated inventory info
    private ReportPrinter    report;      // printer for report
    
    
    /** The constructor does the day-end inventory control for a small company
      * generating a report.                                                    */
    
    public Inventory ( ) {
        
        Item    anItem;      // item in inventory
        int     sold;        // number of item sold
        int     oQuant;      // old quantity on hand
        int     numReorder;  // number of items requiring reorder
        
        invData = new BinaryDataFile();
        display = new BasicForm();
        newInvData = new BinaryOutputFile();
        report = new ReportPrinter();
        setUpReport();
        buildForm();
        numReorder = 0;
        for ( ; ; ) {
            anItem = new Item(invData);
            if ( invData.isEOF() ) break;
            fillForm(anItem);
            display.accept();
            sold = display.readInt("sold");
            oQuant = anItem.getQuant();
            anItem.sell(sold);
            if ( anItem.isReorder() ) {
                writeDetail(anItem,oQuant,sold);
                numReorder = numReorder + 1;
            };
            anItem.write(newInvData);
        };
        writeSummary(numReorder);
        invData.close();
        newInvData.close();
        display.close();
        report.close();
        
    };  // constructor
    
    
    /** This method sets up the report, adding all fields.                      */
    
    private void setUpReport ( ) {
        
        report.setTitle("National Widgets","Inventory Control");
        report.addField("itemNum","Item #",6);
        report.addField("reorder","Reorder Pt",10);
        report.addField("quant","Old",8);
        report.addField("sold","Sold",8);
        report.addField("newQuant","New",8);
        
    };  // setUpReport
    
    
    /** This method generates a report detail line.
      * 
      * @param  anItem    the item
      * @param  oQuant    old quantity
      * @param  sold      items sold                                            */
    
    private void writeDetail ( Item anItem, int oQuant, int sold ) {
        
        report.writeString("itemNum",anItem.getItemNum());
        report.writeInt("reorder",anItem.getReorder());
        report.writeInt("quant",oQuant);
        report.writeInt("sold",sold);
        report.writeInt("newQuant",anItem.getQuant());
        
    };  // writeDetail
    
    
    /** This method generates the report summary.
      * 
      * @param  numReorder number of items requiring reorder                     */
    
    private void writeSummary ( int numReorder ) {
        
        report.writeLine("# Items to Reorder: "+numReorder);
        
    };  // writeSummary
    
    
    private void buildForm ( ) {
        
        display.addTextField("num","Item #",10,10,10);
        display.setEditable("num",false);
        display.addTextField("reorder","Reorder Point",5,10,40);
        display.setEditable("reorder",false);
        display.addTextField("quant","Quantity on Hand",5,10,70);
        display.setEditable("quant",false);
        display.addTextField("sold","Number Sold",5,10,100);
        
    };  // buildForm
    
    
    public void fillForm ( Item anItem ) {
        
        display.writeString("num",anItem.getItemNum());
        display.writeInt("reorder",anItem.getReorder());
        display.writeInt("quant",anItem.getQuant());
        display.clear("sold");
        
    };  // fillForm
    
    
    public static void main ( String[] args ) { Inventory i = new Inventory(); };
    
    
}  // Inventory