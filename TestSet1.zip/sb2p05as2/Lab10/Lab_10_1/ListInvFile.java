package Lab_10_1; 

import BasicIO.*; 
import java.io.*; 

public class ListInvFile {

  
    private BinaryDataFile invFile; 
    private ASCIIDisplayer display; 
  
  public ListInvFile() {
    Item anItem; 
    
    invFile = new BinaryDataFile(); 
    display = new ASCIIDisplayer(); 
    int objectsCreated = 0; 
    
    for (; ;) {
      anItem = (Item) invFile.readObject();
      if(invFile.isEOF()) break;
      writeDetail(anItem); 
      objectsCreated = objectsCreated + 1; 
    }; //end for loop
    
    display.writeString("Number of records created: ");
    display.writeInt(objectsCreated); 
    
    invFile.close();
    display.close(); 
    
  } //constructor
  
  
   private void writeDetail(Item anItem) {
    display.writeString(anItem.getItemNum());
    display.writeInt(anItem.getReorder()); 
    display.writeInt(anItem.getQuant());
    display.newLine(); 
    
  }  //writeDetail
  
  
   public static void main ( String[] args ) { ListInvFile i = new ListInvFile(); };
  
} //ListInvFile
