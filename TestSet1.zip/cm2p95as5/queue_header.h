#include <iostream>
#include <string>

using namespace std;

struct PRecord {
	int priority;
	string entry;
};

void push(PRecord pr);
void swap(PRecord &arr1, PRecord &arr2);
PRecord pop();
void displayQueue();
PRecord queueHead();
int queueSize();
bool emptyQueue();
int userMenu();
int getRecordPriority();
string getRecordEntry();

