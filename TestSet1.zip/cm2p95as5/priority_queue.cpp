#include <iostream>
#include <string>
#include "queue_header.h"

using namespace std;

//Author: Cesar Moreno, Student #: 5727722
//COSC 2P95 - Lab Exercise #5

const int queue_max_size = 10; //size of the queue
PRecord arr[queue_max_size]; //array of PRecords to build queue
int headIndex = 0;
int tailIndex = 0;

void push(PRecord pr){

	int size = queueSize();

	if (size == (queue_max_size - 1)){
		cerr<<"-----Enqueuing Result-----"<<endl;
		cerr<<"Queue overflow"<<endl;
		cerr<<endl;
	}

	else{
		cerr<<"-----Enqueuing Result-----"<<endl;
		cerr<<"Pushed: "<<pr.entry<<endl;
		arr[tailIndex] = pr;

		if (pr.priority < arr[headIndex].priority){
			for (int i=0; i<tailIndex; i++){
				swap(arr[i],arr[tailIndex]);
			}
		}

		for (int i=tailIndex; i>0; i--){
			if(arr[i-1].priority > arr[i].priority){
				swap(arr[i],arr[i-1]);
			}
		}

		tailIndex = ++tailIndex % queue_max_size;

		cerr<<"(Current number of elements in the queue: "<<(size+1)<<")"<<endl;
		cerr<<endl;
	}
}

void swap(PRecord &arr1, PRecord &arr2){
	PRecord arrTemp = arr1;
	arr1 = arr2;
	arr2 = arrTemp;
}

PRecord pop(){

	PRecord poppedValue;
	int size = queueSize();
	bool queueState = emptyQueue();

	if(queueState == true){
		cerr<<"-----Dequeuing Result-----"<<endl;
		cerr<<"Queue is empty; no values can be popped"<<endl;
		cerr<<endl;
	}

	else{
		poppedValue = arr[headIndex];
		cerr<<"-----Dequeuing Result-----"<<endl;
		cerr<<"Popped: "<<poppedValue.entry<<endl;
		headIndex = ++headIndex % queue_max_size;
		cerr<<"Curret number of elements in the queue (after popping): "<<(size-1)<<endl;
		cerr<<".\n"<<".\n"<<".\n";
	}
	return poppedValue;
}

void displayQueue(){

	cerr<<"Elements in the queue are: \n";
	for (int i=headIndex; i<tailIndex; i++){
		cerr<<arr[i].entry<<" ("<<"priority number: "<<arr[i].priority<<")"<<" | ";
	}
	cerr<<endl;
}

PRecord queueHead(){

	PRecord head;
	bool queueState = emptyQueue();

	if (queueState == true){
		cerr<<"Queue is empty"<<endl;
	}
	else{
		head = arr[headIndex];
		cerr<<"The first element in the queue (i.e. head) is: "<<head.entry<<endl;
		cerr<<endl;
	}
	return head;
}

int queueSize(){

	return abs(tailIndex - headIndex);
}

bool emptyQueue(){

	bool queueState = (headIndex == tailIndex)?true:false;

	return queueState;
}

int userMenu(){

	int choice;

	cerr<<"-----PRIORITY QUEUE MENU-----"<<endl;
	cerr<<"1. Add a new entry"<<endl;
	cerr<<"2. Dequeue and display the 'next' element in queue"<<endl;
	cerr<<"3. Display the current entries in the priority queue"<<endl;
	cerr<<"0. Quit"<<endl;

    cin>>choice;

    return choice;
}

int getRecordPriority(){

	int priority;
	cerr<<"Indicate priority number (i.e. integer) of your record: ";
    cin>>priority;

    return priority;
}

string getRecordEntry(){

	string entry;

	cerr<<"Write some text for your record entry: ";
	getline(cin >> ws,entry);
	return entry;
}

int main(){

	int userChoice;
	int priority;
	string entry;
	PRecord pr;

	do{
		userChoice = userMenu();
		switch(userChoice){
            case 1:
                priority = getRecordPriority();
                entry = getRecordEntry();
				pr.priority = priority;
                pr.entry = entry;
				push(pr);
                break;
			case 2:
				cerr<<".\n"<<".\n"<<".\n";
				pop();
				break;
			case 3:
				displayQueue();
		}
	}while(userChoice!=0);
}