package ga_tsp;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class performs Single Point Crossover on a population. 
 */
public class SinglePoint {
    
    private Parameters parameters;
    private ArrayList<Chromosome> children; 
    private Population curr, next; 
    private Random r; 
    
    public SinglePoint(Parameters p) {
        this.parameters = p; 
        r = parameters.getRandom();
    } //Single Point
    
/** This method performs the crossover operation.
 * 
 * @param p the population to perform crossover on.
 */
    private void crossover(Population p) {
        children = new ArrayList<>(); 
        this.curr = p; 
        int numCrossovers = getNumCrossovers();
        int cPoint = randomCrossoverPoint();
        int[] p1, p2, c1, c2;
        ArrayList<Integer> p1LeftOver, p2LeftOver;
        
        int[][] parents = getPairs(); 
        Chromosome parent1, parent2, child1, child2; 
        int[] randoms = r.ints(0, parents.length).distinct().limit(numCrossovers).toArray();
  
        for (int i=0; i < numCrossovers; i++) {
            parent1 = curr.getChromosome(parents[randoms[i]][0]);
            parent2 = curr.getChromosome(parents[randoms[i]][1]);
            
            parents[randoms[i]][0] = -1;
            parents[randoms[i]][1] = -1;
            
            p1 = parent1.getPath();
            p2 = parent2.getPath();
            c1 = new int[p1.length];
            c2 = new int[p2.length];
            int index = 0; 
            
            for (int x = 0; x < c1.length; x++) {
                c1[x] = -1;
                c2[x] = -1;
            }
            
            p1LeftOver = new ArrayList<>(); 
            p2LeftOver = new ArrayList<>(); 
            
            for (int j=0; j < cPoint; j++) {
                c1[j] = p1[j];
                c2[j] = p2[j];
            }

            
            child1 = new Chromosome();
            child1.setPath(c1);
            
            child2 = new Chromosome();
            child2.setPath(c2);
            
            for (int j=0; j < c1.length; j++) {
                if (!child1.containsCity(p2[j])) {
                    p2LeftOver.add(p2[j]);
                }
                if (!child2.containsCity(p1[j])) {
                    p1LeftOver.add(p1[j]);
                }
            }
            
            for (int j= cPoint; j < c1.length; j++) {
                c1[j] = p2LeftOver.get(index);
                c2[j] = p1LeftOver.get(index);
                index++;
            }

            child1.setPath(c1);
            child2.setPath(c2);
            
            children.add(child1);
            children.add(child2);
             
        }
        for (int i=0; i < parents.length; i++) {
            for (int j=0; j < parents[i].length; j++) {
                if (parents[i][j] == -1) {
                    break;
                } else {
                    children.add(curr.getChromosome(parents[i][j]));
                }
            }
        }  
    } //performCrossover
    
/** This method calculates the number of crossovers to perform based on the crossover rate and the population size.
 * 
 * @return the number of crossovers to perform
 */
    
    private int getNumCrossovers() {
        /* calculate # of parent pairs to undergo crossover */
        int num = (int) Math.floor((curr.getPopSize()/2) * parameters.getCrossoverRate());
        return num;
    } //getNumCrossovers
    
/** This method selects a random crossover point to be used.
 * 
 * @return the crossover point
 */
    private int randomCrossoverPoint() {
        int x = r.nextInt(parameters.getNumCities() - 1);
        
        return x;
    } //randomCrossoverPoint
    
/** This method organizes the population into parent pairs.
 * 
 * @return the parent pairs
 */
    private int[][] getPairs() {
        int[][] parents = new int[parameters.getPopSize()/2][2];
        int index = 0; 
        for (int i=0; i < parents.length; i++) {
            for (int j=0; j < parents[i].length; j++) {
                parents[i][j] = index;
                index++; 
            }
        }
        return parents;
    } //getPairs
    
/** This method returns the next generation of chromosomes after crossover has been performed. 
 * 
 * @param p the population to perform crossover on
 * @return the next generation
 */
    public Population getNextGeneration(Population p) {
        next = new Population(parameters); 
        crossover(p);
        
        for (Chromosome c : children) {
            next.addChromosome(c);
        }
        return next; 
    } //getNextGeneration
} //class
