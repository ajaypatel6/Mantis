package ga_tsp;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class performs Tournament Selection on a population. 
 */
public class Selection {
    
    private Parameters parameters;
    private Population currPop, next;
    private Random r; 
    private ArrayList<Chromosome> candidates;
    
    public Selection(Parameters p) {
        this.parameters = p;
        r = parameters.getRandom();
    } //Selection
    
/** This method performs tournament selection.
 * 
 * @param pop the current generation that we are finding parents from.
 */
    private void performSelection(Population pop) {
        currPop = pop; 
        next = new Population(parameters); 
        getParents();
    } //performSelection
    
/** This method adds parent chromosomes to the next generation population.
 * 
 */
    private void getParents() {
        while(next.getPopSize() < currPop.getPopSize()) {
            /* get k chromosomes from population */
            findCandidates();
            /* pick the best to be parent 1 */
            next.addChromosome(findBest());
            /* pick the bext best to be parent 2 */
            next.addChromosome(findBest());
        } 
    } //getParents
    
/** This method selects k random chromosomes from the current population to be used for tournament selection.
 * 
 */
    private void findCandidates() {
        int[] randomNums = r.ints(0, parameters.getPopSize()).distinct().limit(parameters.getkSize()).toArray();
        candidates = new ArrayList<>(); 
       
        for (int i=0; i < randomNums.length; i++) {
            candidates.add(currPop.getChromosome(randomNums[i]));
        }
    } //findCandidates
    
/** This method finds the best chromosome in the list.
 * 
 * @return the best chromosome
 */
    private Chromosome findBest() {
        float best = Integer.MAX_VALUE;
        Chromosome currBest = null;
        int bestIndex = -1;
        
        for (int i=0; i < candidates.size(); i++) {
            if (candidates.get(i).getDistance() < best) {
                currBest = candidates.get(i);
                best = currBest.getDistance();
                bestIndex = i; 
            }
        }
        candidates.remove(bestIndex);
        return currBest; 
    } //findBest
    
/** This method creates the next generation by selecting parents.
 * 
 * @param pop the current population
 * @return the next generation
 */
    public Population selectNextGen(Population pop) {
        performSelection(pop);
        return next; 
    } //selectNextGen
   
} //class
