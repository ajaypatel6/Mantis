package ga_tsp;

import java.util.Scanner;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class stores the adjacency matrix for the cities. 
 */
public class Map {
    private int numCities; 
    private City[] list;
    private float[][] distance;
    
    public Map(int n, Scanner in) {
        this.numCities = n;
        
        list = new City[numCities];
        distance = new float[numCities][numCities];
        
        /* read and store location information from file */
        getCityInfo(in);
        
        /* calculate distances between cities */
        fillDistances();
    } //Map
    
/** This method creates new cities based on the information from the file.
 * 
 * @param in the file
 */
    private void getCityInfo(Scanner in) {
        while (in.hasNextInt()) {
            for (int i=0; i < numCities; i++) {
                in.nextInt();
                list[i] = new City(in.nextFloat(), in.nextFloat());
            }
        }
    } //getCityInfo
    
/** This method fills in the distances in the adjacency matrix.
 * 
 */
    private void fillDistances() {
        for (int i=0;i < numCities; i++) {
            for (int j=0; j < numCities; j++) {
                if (i==j) {
                    distance[i][j] = 0;
                } else {
                    float x1 = list[i].getX();
                    float y1 = list[i].getY();
                    float x2 = list[j].getX();
                    float y2 = list[j].getY();
                    
                    distance[i][j] = calculate(x1, y1, x2, y2);
                }
            }
        }
    } //fillDistances
    
/** This method calculates the distance between two cities.
 * 
 * @param x1 x location of city 1
 * @param y1 y location of city 1
 * @param x2 x location of city 2
 * @param y2 y location of city 2
 * @return the distance between city 1 and city 2
 */
    private float calculate(float x1, float y1, float x2, float y2) {
        float termX = (x1 - x2) * (x1 - x2);
        float termY = (y1 - y2) * (y1 - y2);
        
        float dist = (float) Math.sqrt(termX + termY);
        
        return dist; 
    }//calculate

    /**
     * @return the distance between city i and j 
     */
    public float getDistance(int i, int j) {
        return distance[i][j];
    }
    
} //class
