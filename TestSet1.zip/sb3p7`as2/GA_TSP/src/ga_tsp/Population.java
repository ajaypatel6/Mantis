package ga_tsp;

import java.util.ArrayList;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class describes a population object. 
 */
public class Population {
    
    Parameters parameters;
    private ArrayList<Chromosome> pop; 
    private int popSize; 
    
    public Population(Parameters p) { 
        this.parameters = p; 
        pop = new ArrayList<>(p.getPopSize());
    } //Population
    
    public Population(Parameters p, ArrayList<Chromosome> list, int size) {
        this.parameters = p;
        this.pop = list;
        this.popSize = size; 
    } //Population
    
/** This method creates a new population and fills it with chromosomes.
 * 
 */
    public void initializePop() {
        for (int i=0; i < parameters.getPopSize(); i++) {
                pop.add(i, new Chromosome(parameters));
            }
            this.popSize = pop.size();
    }
    
/** This method copies the current population.
 * 
 * @return a copy of the current population
 */
    public Population copyPopulation() {
        return new Population(this.parameters, this.pop, this.popSize);
    }
    
/** This method calculates the path distance of the chromosomes in the population.
 * 
 */
    public void calcDistance() {
        for (int i=0; i < parameters.getPopSize(); i++) {
            int[] path = this.getChromosome(i).getPath();
            
            float pLength = 0;
            int x = 0; 
            
            while (x + 1 < path.length) {
                pLength = pLength + parameters.getMap().getDistance(path[x], path[x+1]);
                x++;
            }
            pLength = pLength + parameters.getMap().getDistance(path[path.length - 1], path[0]);
            this.getChromosome(i).setDistance(pLength);
        }
    } //calcDistance
    
/** This method gets a chromosome at a specific index.
 * 
 * @param i the index to use
 * @return the chromosome at the given index
 */
    public Chromosome getChromosome(int i) {
        return pop.get(i);
    } //getChromosome


/** This method returns the index for where the best chromosome is located.
 * 
 * @return the index of the best chromosome
 */
    public int getBestChromosome() {
        float bestDistance = Integer.MAX_VALUE;
        int bestIndex = -1;
        for (int i=0; i < pop.size(); i++) {
            if (this.getChromosome(i).getDistance() <= bestDistance) {
                bestDistance = this.getChromosome(i).getDistance();
                bestIndex = i; 
            }
        }
        return bestIndex;
    } //getBestChromosome
    
/** This method returns the index for where the worst chromosome is located.
 * 
 * @return the index of the worst chromosome
 */
    public int getWorstChromosome() {
        float worstDistance = Integer.MIN_VALUE;
        int worstIndex = -1;
        for (int i=0; i < popSize; i++) {
            if (this.getChromosome(i).getDistance() > worstDistance) {
                worstDistance = this.getChromosome(i).getDistance();
                worstIndex = i; 
            }
        }
        return worstIndex;
    }
    
/** This method returns the population size.
 * 
 * @return the pop size
 */
    public int getPopSize() {
        return popSize;
    } //getPopSize
    
/** This method adds a chromosome to the population.
 * 
 * @param c the chromosome to add
 */
    public void addChromosome(Chromosome c) {
        pop.add(c);
        popSize++; 
    } //addChromosome
    
/** This method removes a chromosome at a specific index.
 * 
 * @param index the index where the chromosome to remove is
 */
    public void removeChromosome(int index) {
        pop.remove(index);
        popSize--;
    } //removeChromosome
    
/** This method calculates the average distance for the chromosomes in the population.
 * 
 * @return the average distance for the population
 */
    public float getAverageFitness() {
        float totalDistance = 0;
        for (int i=0; i < getPopSize(); i++) {
            totalDistance = totalDistance + this.getChromosome(i).getDistance();
        }
        float averageDistance = totalDistance / getPopSize(); 
        return averageDistance; 
    } //getAverageFitness
    
} //class
