package ga_tsp;

import java.util.Arrays;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class performs the search on the population. 
 */
public class Search {
    
    private final Parameters parameters; 
    private Population initialPop, currPop, nextGen;
    private int bestIndex;
    private float bestDistance;
    private int[] bestPath; 
    private Selection select;
    private SinglePoint singlePoint; 
    private UniformOrder uniformOrder;
    private Mutation mutate;
    private Output out; 
    //private double[] average;
    //private double[] best; 
    
    public Search(Parameters p, Output o) {
        this.parameters = p; 
        this.out = o; 
        //average = new double[parameters.getMaxGenSpan()];
        //best = new double[parameters.getMaxGenSpan()];
        
        initializePopulation();
        performSearch();
        printRunResults(); 
    }//Search
   
/** This method initializes the genetic algorithm by creating an initial population of chromosomes that we can work on.
 * 
 */
    private void initializePopulation() {
        initialPop = new Population(parameters);
        initialPop.initializePop();
        initialPop.calcDistance();
        bestIndex = initialPop.getBestChromosome();
        bestDistance = initialPop.getChromosome(bestIndex).getDistance();
        bestPath = initialPop.getChromosome(bestIndex).getPath();
        currPop = initialPop.copyPopulation();
        nextGen = new Population(parameters);  
        select = new Selection(parameters); 
        singlePoint = new SinglePoint(parameters); 
        uniformOrder = new UniformOrder(parameters); 
        mutate = new Mutation(parameters); 
    } //initializePopulation
    
/** This method runs the genetic algorithm.
 * 
 */
    private void performSearch() {
        /* for gen = 1 to Max Gen */
        for (int i=0; i < parameters.getMaxGenSpan(); i++) {
            /* evaluate fitness of individuals */
            currPop.calcDistance();
            /* select new population using some selection strategy */
            nextGen = select.selectNextGen(currPop);
            /* apply genetic operators */
            /* crossover*/
            if (parameters.getCrossoverRate() > 0) {
                if (parameters.isUniformOrder()) {
                    /* uniform order crossover */
                    nextGen = uniformOrder.getNextGeneration(nextGen);
                } else {
                    /* single point crossover */
                    nextGen = singlePoint.getNextGeneration(nextGen);
                }
            }
            /* mutation */
            if (parameters.getMutationRate() > 0) {
                nextGen = mutate.getNextGeneration(nextGen);
            }
            nextGen.calcDistance();
            /* apply elitism */
            elitism(); 
            currPop = nextGen.copyPopulation();
            printGenerationResults(i);
        }
        
        /* for gen = 1 to maxGen
                evaluate fitness of individuals in population
                select new population using some selection strategy
                apply genetic operators, crossover, and mutation
        */
    
    } //performSearch
    
/** This method performs elitism on the current generation.
 * 
 */
    private void elitism() {
        Chromosome compare = nextGen.getChromosome(nextGen.getBestChromosome());
        if (compare.getDistance() < bestDistance) {
            bestIndex = nextGen.getBestChromosome();
            bestDistance = nextGen.getChromosome(bestIndex).getDistance();
            bestPath = nextGen.getChromosome(bestIndex).getPath();
        }
        nextGen.removeChromosome(nextGen.getWorstChromosome());
        Chromosome best = new Chromosome(); 
        best.setPath(bestPath);
        best.setDistance(bestDistance);
        nextGen.addChromosome(best);
    }

/** This method prints the final run results to a file.
 * 
 */
    private void printRunResults() {
        Chromosome c = currPop.getChromosome(currPop.getBestChromosome());
        out.println();
        out.println("Best solution fitness & the corresponding path");
        c.printDistance(out);
        c.printPath(out);
        
//        System.out.println("Best");
//        System.out.println(Arrays.toString(best));
//        
//        System.out.println("Average");
//        System.out.println(Arrays.toString(average));
    } //printRunResults
    
/** This method prints the results of each generation to a file.
 * 
 * @param i the current generation we are working on
 */
    private void printGenerationResults(int i) {
        int genNumber = i + 1; 
        out.println("Generation " + genNumber);
        
        Chromosome c;
        
        c = currPop.getChromosome(currPop.getBestChromosome());
        out.println("Best Fitness Value");
        c.printDistance(out);
        //best[i] = c.getDistance();
        
        out.println("Average Fitness Value for Population");
        out.println(currPop.getAverageFitness());
        out.println();
        //average[i] = currPop.getAverageFitness();
    } //printGenerationResults
    
} //class
