package ga_tsp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class writes the results of the GA to a file. 
 */
public class Output extends PrintWriter {
    
    public Output(File file) throws FileNotFoundException {
        super(file);
        this.println("TSP Solver - Results");
    } //Output
    
    public void printResults(Parameters p) {
        this.println("File used: " + p.getFileName());
        this.println("Crossover Rate: " + p.getCrossoverRate());
        this.println("Mutation Rate: " + p.getMutationRate());
        this.println("K value for selection used: " + p.getkSize());
        this.println("Population Size: " + p.getPopSize());
        this.println("Max Generation Span: " + p.getMaxGenSpan());
        this.println("Number of Cities Visited: " + p.getNumCities());
        if (p.isUniformOrder()) {
            this.println("Using Uniform Ordered Crossover.");
        } else {
            this.println("Using Single Point Crossover.");
        }
        this.println("Random Number Seed: " + p.getSeed());
        this.println();
        this.println();
    }
} //class
