package ga_tsp;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class performs Mutation on a population. 
 */
public class Mutation {
    private Parameters parameters;
    private Population curr, next; 
    private Random r; 
    
    public Mutation(Parameters p) {
        this.parameters = p; 
        r = parameters.getRandom();
    } //Mutation
    
/** This method performs mutation on a population.
 * 
 * @param p the population to use
 */
    private void mutation(Population p) {
        this.curr = p; 
        int numMutations = getNumMutations(); 
        
        int randoms[] = r.ints(0, parameters.getPopSize()).distinct().limit(numMutations).toArray();
        
        for (int i=0; i < numMutations; i++) {
            int[] shuffleIndex = r.ints(0, parameters.getNumCities()).distinct().limit(3).toArray();
            int[] shuffledNumbers = shuffleIndex.clone();
            
            
            Shuffle first = new Shuffle(parameters);
            first.shufflePath(shuffledNumbers);
            shuffledNumbers = first.getShuffledPath();
            
            if (Arrays.equals(shuffleIndex, shuffledNumbers)) {
                Shuffle again = new Shuffle(parameters);
                again.shufflePath(shuffledNumbers);
                shuffledNumbers = again.getShuffledPath();
            }
            
            int[] path = curr.getChromosome(randoms[i]).getPath();
            int[] pathCopy = path.clone();
            
            for (int j=0; j < shuffleIndex.length; j++) {
                int old = shuffleIndex[j];
                int move = shuffledNumbers[j];
                int temp = pathCopy[old];
                path[move] = temp; 
            }
            curr.getChromosome(randoms[i]).setPath(path);
        }
        next = curr.copyPopulation();
    } //mutation
    
/** This method calculates the number of chromosomes to mutate based on the population size and the mutation rate.
 * 
 * @return the number of chromosomes to mutate
 */
    private int getNumMutations() {
        /* calculate # of parent pairs to undergo crossover */
        int num = (int) Math.floor(curr.getPopSize() * parameters.getMutationRate());
        return num; 
    } //getNumMutations
    
/** This method gets the next generation of chromosomes after mutation has been performed.
 * 
 * @param p the population to perform mutation on
 * @return the resulting population
 */
    public Population getNextGeneration(Population p) {
        next = new Population(parameters);
        mutation(p);
        
        return next; 
    } //getNextGeneration
    
} //class
