package ga_tsp;

import java.util.Random;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class shuffles arrays. 
 */
public class Shuffle {
    private int[] path; 
    private Parameters parameters;
    private Random r; 
    
    public Shuffle(Parameters p) {
        this.parameters = p; 
        r = parameters.getRandom();
    } //Shuffle

/** This method takes in an array and shuffles the values in it.
 * 
 * @param p the array to be shuffled
 */
    public void shufflePath(int[] p) {
        this.path = p;         
        for (int i=0; i < path.length; i++) {
            int randomNum = r.nextInt(path.length - 1);
            int temp = path[randomNum];
            
            path[randomNum] = path[i];
            path[i] = temp; 
        }
    } //ShufflePath
    
/** This method returns the shuffled path.
 * 
 * @return the shuffled path
 */
    public int[] getShuffledPath() {
        return this.path;
    } //getShuffledPath
    
} //class
