package ga_tsp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class a chromosome object. 
 */
public class Chromosome {
    
    private int[] path;
    private float distance;
    private Parameters parameters; 
    
    public Chromosome(Parameters p) {
        this.parameters = p;  
        
        /* initialize chromosome with in order path */
        path = new int[p.getNumCities()];
        for (int i=0; i < path.length; i++) {
            path[i] = i;
            }
        shufflePath(); 
    } //Chromosome
    
    public Chromosome() {
    
    } //Chromosome
    
/** This method shuffles the path of a chromosome.
 * 
 */
    private void shufflePath() {
        ArrayList<Integer> pCopy = new ArrayList<>(); 
        for (int i=0; i < path.length; i++) {
            pCopy.add(path[i]);
        }
        Collections.shuffle(pCopy, parameters.getRandom());
        
        for (int i=0; i < path.length; i++) {
            this.path[i] = pCopy.get(i);
        }
    } //shufflePath
    
/** This method prints the path of the current chromosome to the console.
 * 
 */
    public void printPath() {
        System.out.println(Arrays.toString(getPath()));
    } //printPath
    
/** This method prints the path of the current chromosome to a file.
 * 
 * @param o PrintWriter to write to file
 */
    public void printPath(Output o) {
        o.println(Arrays.toString(getPath()));
    } //printPath
    
/** This method prints the distance of the current chromosome to the console.
 * 
 */
    public void printDistance() {
        System.out.println(getDistance());
    } //printDistance
    
/** This method prints the distance of the current chromosome to a file.
 * 
 * @param o PrintWriter to write to file
 */
    public void printDistance(Output o) {
        o.println(getDistance());
    } //printDistance

    /**
     * @return the path
     */
    public int[] getPath() {
        return path;
    }

    /**
     * @param path the path to set
     */
    public void setPath(int[] path) {
        this.path = path;
    }

    /**
     * @return the distance
     */
    public float getDistance() {
        return distance;
    }

    /**
     * @param distance the distance to set
     */
    public void setDistance(float distance) {
        this.distance = distance;
    } //setDistance
    
/** This method checks if a city is already located in the path of the chromosome.
 * 
 * @param city the city to check
 * @return the result if the path contains it or not
 */
    public boolean containsCity(int city) {
        for (int i=0; i < this.path.length; i++) {
            if (this.path[i] == city) {
                return true; 
            }
        }
        return false; 
    } //containsCity
    
    
} //class
