package ga_tsp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.logging.*;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class contains the main method to run the GA. 
 */
public class GA_TSP {
    private Parameters p; 
    private Search s; 
    private Output out; 

    public GA_TSP() {
        System.out.println("TSP Solver");
        p = new Parameters();
        Date d = new Date();
        try {
            out = new Output(new File("results - " + d.toString() + ".txt"));
            out.printResults(p);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GA_TSP.class.getName()).log(Level.SEVERE, null, ex);
        }
        s = new Search(p, out);
        out.close();
        System.out.println("Results printed to results.txt");
    
    } //GA_TSP
    public static void main(String[] args) {
        GA_TSP ga_tsp = new GA_TSP(); 
    } //main
    
} //class
