
package ga_tsp;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class creates a new City object. 
 */
public class City {
    private float x;
    private float y;
    
    public City(float x, float y) {
        this.x = x;
        this.y = y; 
    } //City

    /**
     * @return the x location
     */
    public float getX() {
        return x;
    }

    /**
     * @return the y location
     */
    public float getY() {
        return y;
    }
    
    
} //Class
