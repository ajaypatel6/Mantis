package ga_tsp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * Saifa Bhanji
 * 5172879
 * COSC 3P71 - Assignment 2
 * 
 * Class Description: This class gets and stores the GA parameters from the user. 
 */
public class Parameters {
    
    private Scanner userInput, fileInput; 
    private float crossoverRate, mutationRate;
    private int numCities, kSize, popSize, maxGenSpan, seed;
    private boolean uniformOrder;
    private Map map; 
    private String fileName; 
    private Random random; 
    
    
    public Parameters() {
        userInput = new Scanner(System.in);
        getInfoFromFile();
        getParametersFromUser(); 
        
        random = new Random(this.seed);
    
    } //Parameters

/** This method asks the user which data set file to use and gets the information from that file. 
 * 
 */
    private void getInfoFromFile(){
        try {
            String f1 = "eil51.txt";
            String f2 = "ulysses22.txt";
            System.out.println("Which file would you like to use? 1 for Eil51. 2 for Ulysses22.");
            int choice = userInput.nextInt();
            if (choice == 1) {
                fileName = f1;
            }
            if (choice == 2) {
                fileName = f2;
            }
            File file = new File(getFileName());
            fileInput = new Scanner(file); 
            /* get number of cities from file */
            this.numCities = fileInput.nextInt();
            /* create adjacency matrix with city locations */
            map = new Map(numCities, fileInput);
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    } //getInfoFromFile
    
/** This method gets the GA parameters from the user.
 * 
 */
    private void getParametersFromUser() {
        /* get crossover rate */
        setCrossoverRate();
        /* get mutation rate */
        setMutationRate();
        /* get tournament selection size */
        setkSize(); 
        /* get Population size */
        setPopSize(); 
        /* get max generaton span */
        setMaxGenSpan(); 
        /* random seed */
        setSeed(); 
        /* get crossover method */
        setUniformOrder(); 

    
    } //getParametersFromUser

/** This method stores the crossover rate from the user.
 * 
 */
    private void setCrossoverRate() {
        System.out.println("Enter the crossover rate to use.");
        while (true) {
            this.crossoverRate = userInput.nextFloat();
            if (getCrossoverRate() < 0 || getCrossoverRate() > 1) {
                System.out.println("Enter a valid crossover rate (between 0 and 1)");
            } else {
                break;
            }
        }
    } //setCrossoverRate

/** This method stores the mutation rate from the user.
 * 
 */
    private void setMutationRate() {
        System.out.println("Enter the mutation rate");
        while (true) {
            this.mutationRate = userInput.nextFloat();
            if (getMutationRate() < 0 || getMutationRate() > 1) {
                System.out.println("Enter a valid mutation rate (between 0 and 1");
            } else {
                break;
            }
        }
    } //setMutationRate

/** This method stores the k value for tournament selection from the user.
 * 
 */
    private void setkSize() {
        System.out.println("Enter the value to use for tournament selection");
        while (true) {
            this.kSize = userInput.nextInt();
            if (getkSize() < 2 || getkSize() > 6) {
                System.out.println("Enter a valid number to use for tournament selection (between 1 and 6)");
            } else {
                break;
            }
        }
    }//setKSize
    
/** This method stores the population size from the user.
 * 
 */
    private void setPopSize() {
        System.out.println("Enter the population size");
        while (true) {
            this.popSize = userInput.nextInt();
            if (getPopSize() < getkSize()) {
                System.out.println("Enter a valid population size (larger than " + getkSize() + ").");
            } else {
                break;
            }
        }
    } //setPopSize

/** This method stores the max number of generations from the user.
 * 
 */
    private void setMaxGenSpan() {
        System.out.println("Enter the number of generations");
        while (true) {
            this.maxGenSpan = userInput.nextInt();
            if (getMaxGenSpan() < 1) {
                System.out.println("Enter a valid number of generations (larger than 0)");
            } else {
                break;
            }
        }
    } //setMaxGenSpan

/** This method stores the random seed number that is randomly generated or given from the user.
 * 
 */
    private void setSeed() {
        System.out.println("Enter true to generate a random number seed.");
        System.out.println("Enter false to provide your own random number seed");
        if (userInput.nextBoolean()) {
            this.seed = (int) Math.ceil(Math.random() * 100); 
        } else {
            System.out.println("Enter the number to be used as the seed.");
            this.seed = userInput.nextInt();
        }
    } //setSeed

/** This method stores which crossover type should be used for the GA.
 * 
 */
    private void setUniformOrder() {
        System.out.println("Enter true to use Uniform Ordered Crossover.");
        System.out.println("Enter false to use Single Point Crossover.");
        this.uniformOrder = userInput.nextBoolean();
    } //setUniformOrderCrossover

    /**
     * @return the crossoverRate
     */
    public float getCrossoverRate() {
        return crossoverRate;
    } //getCrossoverRate

    /**
     * @return the mutationRate
     */
    public float getMutationRate() {
        return mutationRate;
    } //getMutationRate

    /**
     * @return the numCities
     */
    public int getNumCities() {
        return numCities;
    } //getNumCities

    /**
     * @return the kSize
     */
    public int getkSize() {
        return kSize;
    } //geteKSize

    /**
     * @return the popSize
     */
    public int getPopSize() {
        return popSize;
    } //getPopSize

    /**
     * @return the maxGenSpan
     */
    public int getMaxGenSpan() {
        return maxGenSpan;
    } //getMaxGenSpan

    /**
     * @return the seed
     */
    public int getSeed() {
        return seed;
    } //getSeed

    /**
     * @return the crossover type
     */
    public boolean isUniformOrder() {
        return uniformOrder;
    } //isUniformOrder

    /**
     * @return the map
     */
    public Map getMap() {
        return map;
    } //getMap

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    } //getFileName

    /**
     * @return the random
     */
    public Random getRandom() {
        return random;
    } //getRandom
    
} //Class

