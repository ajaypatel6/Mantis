package Maze;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Iterator;
import static java.lang.Math.*;
import java.util.Scanner;

/**
 *
 * @Tamara McDiarmid
 * 6148837
 * June 2017
 */
public class Input {
    Scanner in;
    TheMaze tm;
    public Input(){
        int choice=-1;
        in= new Scanner(System.in);
        
        do{
            try{
              choice=menu();
              switch(choice){
                  case 1:
                    in.nextLine();
                    System.out.print("not implemented");
                    break;
                  case 2:
                      in.nextLine();
                      tm.solve();
                      //System.out.print("not implemented");
                      break;
                  case 3:
                      in.nextLine();
                      int width = getInt("Enter width: ");
                      int height=getInt("Enter height: ");
                      int depth = getInt("Enter depth: ");
                      char[][] charMatrix = new char[height][width];
                      for (int i =0;i<charMatrix.length;i++){
                          for (int j=0;j<charMatrix[i].length;j++){
                              charMatrix[i][j]=getChar("enter next char in puzzle");
                          }
                      }
                      System.out.println();
                      System.out.println("Maze to Solve: ");
                      System.out.println();
                      tm = new TheMaze(charMatrix);
                      break;                 
                  default:
                    System.out.println("BYE!");
                  }
            }
            catch (InsufficientElementsException iee) {
				System.out.println("Exception caught. Invalid request.\n");
			}
            catch (InputMismatchException ime) {
				in.next();
				System.out.println("WRONG KIND OF ENTRY.\n");
			}
            }while (choice!=0);
        }
        
    /*Provides a menu to user */
    private int menu() {
		System.out.print("1. Solve subOptimally");
		System.out.print("\t2. Solve optimally ");
		System.out.print("\t3. Enter new puzzle ");
		System.out.println("\t0. Quit");
                
		return in.nextInt();
	}//menu
    
    private int getInt(String msg){
        System.out.print(msg);
        return in.nextInt();
    }//getInt
    
    private char getChar(String msg) {
		System.out.print(msg);
                char c = in.next(".").charAt(0);
		return c;
	}//getChar
	
    public static void main(String[] args) {new Input();}
}//Input
