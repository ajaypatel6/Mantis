package Maze;
/*
 */
public class InsufficientElementsException extends RuntimeException {
	
}