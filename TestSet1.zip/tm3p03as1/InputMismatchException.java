package Maze;
/*
 */
public class InputMismatchException extends RuntimeException {
	
}