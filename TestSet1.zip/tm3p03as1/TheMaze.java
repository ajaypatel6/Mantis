package Maze;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @Tamara McDiarmid
 * 6148837
 * June 2017
 */
public class TheMaze {
    char[][] maze;
    int inf = Integer.MAX_VALUE;
    int [][] adjMatrix;
    int [][] vertices;
    int size;
    Queue<Vertex> verts= new LinkedList();
    int start;
    Vertex[] graph;
    
    /*Initializes the maze entered by user and displays it */
    public TheMaze(char [][] theMaze){
        maze= new char[theMaze.length][theMaze[0].length];
        int counter=0;
        for (int i=0;i<theMaze.length;i++){
            for (int j=0;j<theMaze[i].length;j++){
                maze[i][j]=theMaze[i][j];
                System.out.print(theMaze[i][j] + "");
                counter++;
            }
            System.out.println();
        }       
        size=counter;
        initializeVertices(counter); // sets a matrix with values that correspond with element numbers
        buildAdjMatrix(counter);
        quest(counter);
    }//constructor
    
    /* method to place numbers in an array to use to initialize adjacency matrix*/ 
    private void initializeVertices(int numElements){
        vertices = new int[maze.length][maze[0].length];
        int counter=0;
        System.out.println();
        for (int i =0; i< vertices.length;i++){
            for (int j=0;j<vertices[i].length;j++){
                vertices[i][j]=counter;
                System.out.print(vertices[i][j] + "");          
                counter++;
            }
            System.out.println();
        }
    }//initializeVertices
    
    /*constructs the adjacency matrix*/
    private void buildAdjMatrix(int x){
        adjMatrix = new int[x][x];
        for (int i=0;i<vertices.length;i++){
            for (int j=0;j<vertices[i].length;j++){
                
                if(checkNorth(i,j)){   // looks north
                   int row = vertices[i][j];
                   int col= vertices[i-1][j];
                   adjMatrix[row][col]=1;
                }
                
                    if (checkEast(i,j)){  //looks east
                        int row= vertices[i][j];
                        int col=vertices[i][j+1];
                        adjMatrix[row][col]=1;
                    }
                    
                        if (checkSouth(i,j)){   //looks south
                            int row= vertices[i][j];
                            int col=vertices[i+1][j];
                            adjMatrix[row][col]=1;
                        }
                    
                            if (checkWest(i,j)){  //looks west
                                int row = vertices[i][j];
                                int col= vertices[i][j-1];
                                adjMatrix[row][col]=1;
                            }
            }
        }
        
        for (int print=0;print<adjMatrix.length;print++){ //prints adj matrix
            for (int p=0;p<adjMatrix[print].length;p++){
                System.out.print(adjMatrix[print][p] +"  ");
                
            }
            System.out.println();
        }
    }//buildAdjMatrix
    
    /* checks if a move west is south is posible and returns a boolean */
    private boolean checkWest(int i , int j){
        int west = j-1;
        if (west <0)return false;
        return maze[i][west]=='O'|maze[i][west]=='E'|maze[i][west]=='S';
    }//checkWest
    
    /* checks if a move south is south is posible and returns a boolean */
    private boolean checkSouth(int i , int j){
        int south = i+1;
        if(south >=maze.length)return false;
        if(maze[south][j]=='O'|maze[south][j]=='E'|maze[south][j]=='S')return true;
        else return false;
    }//checkSouth
    
    /* checks if a move east is south is posible and returns a boolean */
    private boolean checkEast(int i , int j){
        int east = j+1;
        if (east > maze.length)return false;
        if (maze[i][east]=='S'|maze[i][east]=='O'|maze[i][east]=='E')return true;
        else return false;
    }//checkEast
    
    /* checks to see if a move north is posible and returns a boolean value */
    private boolean checkNorth(int i,int j){
        int north = i-1;
        if( north  < 0 )return false;
        if(maze[north][j]=='O'|maze[north][j]=='E'|maze[north][j]=='S') return true;               
        else return false;
        
    }//checkNorth
    
    /*shortest path algorithm*/   
    private void quest(int size){
        int s= findStart();
        graph= new Vertex[size];
        int num=maze.length *maze[0].length;
        for(int i=0 ; i<num;i++){
            graph[i]= new Vertex(i);
        }
        graph[s].dist=0;
        for (int i=0;i<size;i++){
            if (i!=s){
         graph[i].dist=inf;
         graph[i].known=false;
        }
       verts.add(graph[s]);
       while (!verts.isEmpty()){
           Vertex v = verts.remove();
           int from= v.name;
           //System.out.print(from);
           for(int to=0;to<adjMatrix.length;to++){
               if (adjMatrix[from][to]==1 &&graph[to].dist==inf){
                       graph[to].dist=graph[from].dist+1;
                       graph[to].path=graph[from];
                       verts.add(graph[to]);
                   
               }
           }
       } 
    }
        
    }//quest
    
    /*solves optimally*/
    public void solve(){
        int end = findEnd();
        printPath(graph[end]);
        System.out.println();
    }//solve
    
    /* helper method that prints the pathway taken to exit*/
    private void printPath(Vertex v){
        if (v.path!=null){
            printPath(v.path);
            System.out.print(" to ");
        }
        System.out.print(v.name);
         //System.out.print(v.dist);
    }//printPath
       
    /* finds starting point of maze*/
    private int findStart(){
        for (int i=0;i<maze.length;i++){
            for (int j=0;j<maze[i].length;j++){
                if (maze[i][j]=='S'){
                  return vertices[i][j];
                }
                
            }
        }
        return -1;
    }//findStart
    
    /*finds the end */
    private int findEnd(){
        for (int i=0;i<maze.length;i++){
            for (int j=0;j<maze[i].length;j++){
                if (maze[i][j]=='E'){
                  return vertices[i][j];
                }
                
            }
        }
        return -1;
    }//findEnd
    
}//TheMaze
