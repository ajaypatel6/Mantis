package Maze;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @Tamara McDiarmid
 * 6148837
 * June 2017
 */
    class Vertex {

        public LinkedList adj;
        public boolean known;
        public int dist;
        public Vertex path;
        public int name;
        int inf = Integer.MAX_VALUE;
        
        public Vertex(int position){
            dist=inf;
            known=false;
            name=position;
            adj = new LinkedList();
        }
        
    
}//Vertex
