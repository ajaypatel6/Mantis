package Assign_1;

import Media.*;      // for Turtle or TurtleDisplayer
import java.awt.*;     // for Color objects and methods
import static java.lang.Math.*;  // for math constants and functions
import static java.awt.Color.*;  // for Color constants

/** This class ...
  *
  * @author Saifa Bhanji
  * @version 1.0 (Sept 2015)                                                        */

public class Flower {
    
    
    // instance variables
    private TurtleDisplayer display; //display to draw on
    private Turtle yertle; //turtle to do drawing
    
    
    /** This constructor ...                                                     */
    
    public Flower ( ) {
        
        // statements 
        
        display = new TurtleDisplayer(); 
        yertle = new Turtle(); 
        display.placeTurtle(yertle);
        
        yertle.left(PI/6); // Move to drawing position
        
       yertle.setPenColor(RED);
       yertle.penDown(); 
       
       for (int j=1; j<=8 ; j++) {
         
         for (int i=1; i<=2 ; i++) {
           yertle.forward(40);
           yertle.right(PI/3);
           yertle.forward(40);
           yertle.right(2*PI/3);
         }; //end for loop i
         
        yertle.left(PI/4);
        
       }; //end for loop j
       
       yertle.penUp();
       yertle.right(PI/6); // Return to starting position  
       
        display.close();
        
    }; // constructor
    
    
    public static void main ( String[] args ) { Flower s = new Flower(); };
    
    
} // Flower
