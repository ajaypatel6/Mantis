COSC 4P03 Assignment 2 - Question 1
Curtis Penney 5660659

IDE: Netbeans

HOW TO USE
Run Assignment2.java
Program will prompt for the dimension of the Latin Square to generate
Input a 0 to terminate the program

The program will then generate the starting square in normal form (first row and col are in order)
From there the program will recursively fill the latin square with all possble values (generating all reduced latin squares)
Once a reduced latin square has been generated it will compare if the square is equivalent to any of the already found ones

It does this the following way:
First, is this the first square we've come across? If yes take it always
Does this square directly match any of the squares we've already found? If yes skip this square
If no
	For every row in the square
		Perform column permutations to put that row in order
		Make that row the first row
		Perform row permutations to put the first column in order
		Is this square Exactly in the squares we've found?
			If yes, skip
			If no, try next row

If the square still hasnt been identified as equivalent, then it is a new square 
Add it to our list and try the next square.




The program will output the information into "outputn.txt"
Where n = the value you inserted at the beginning.
