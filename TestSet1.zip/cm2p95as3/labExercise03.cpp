#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>

using namespace std;

//Author: Cesar Moreno, Student#: 5727722

double minX = -4;
double maxX = 6;
double minY = -12;
double maxY = 5;

void function1(int graduations, int outputType){

    double array[graduations*graduations];
    double stepX = (maxX - minX)/graduations;
    double stepY = (maxY - minY)/graduations;

    //cout<<stepX<<endl; 
    //cout<<stepY<<endl;
    //cout<<"Test: First function"<<endl;
    //cout<<"Number of graduations: "<<graduations<<endl;

    for (int b=0; b<graduations; b++){
        for (int a=0; a<graduations; a++){

            array[a*graduations + b] = sin(minX + a * stepX) * cos(minY + b * stepY);

            switch(outputType){
                case 0:
                    if (array[a*graduations + b] > 0){
                        cout<<"O"; //the value is positive
                    }
                    else{
                        cout<<"X"; //the value is negative
                    }
                    break;
                case 1:
                    cout<<array[a*graduations + b];
                    break;
            }
        }cout<<endl;
    }
}

void function2(int graduations, int outputType){

    double array[graduations*graduations];
    double stepX = (maxX - minX)/graduations;
    double stepY = (maxY - minY)/graduations;

    //cout<<stepX<<endl; 
    //cout<<stepY<<endl;
    //cout<<"Test: Second function"<<endl;
    //cout<<"Number of graduations: "<<graduations<<endl;

    for (int b=0; b<graduations; b++){
        for (int a=0; a<graduations; a++){

            array[a*graduations + b] = sin(minX + a * stepX) + ( pow( cos( (0.5)*(minY + b * stepY) ), 2) ) - ( (minX + a * stepX)/(minY + b * stepY) ) ;

            switch(outputType){
                case 0:
                    if (array[a*graduations + b] > 0){
                        cout<<"O"; //the value is positive
                    }
                    else{
                        cout<<"X"; //the value is negative
                    }
                    break;
                case 1:
                    cout<<array[a*graduations + b];
                    break;
            }
        }cout<<endl;
    }
}

void function3(int graduations, int outputType){

    double array[graduations*graduations];
    double stepX = (maxX - minX)/graduations;
    double stepY = (maxY - minY)/graduations;

    //cout<<stepX<<endl; 
    //cout<<stepY<<endl;
    //cout<<"Test: Third function"<<endl;
    //cout<<"Number of graduations: "<<graduations<<endl;

    for (int b=0; b<graduations; b++){
        for (int a=0; a<graduations; a++){
            array[a*graduations + b] = ( sin(minX + a * stepX) * (0.5) ) + ( cos(minY + b * stepY) * (0.5) );

            switch(outputType){
                case 0:
                    if (array[a*graduations + b] > 0){
                        cout<<"O"; //the value is positive 
                    }
                    else{
                        cout<<"X"; //the value is negative
                    }
                    break;
                case 1:
                    cout<<array[a*graduations + b];
                    break;
            }
        }cout<<endl;
    }
}

void function4(int graduations, int outputType){

    double array[graduations*graduations];
    double stepX = (maxX - minX)/graduations;
    double stepY = (maxY - minY)/graduations;

    //cout<<stepX<<endl; 
    //cout<<stepY<<endl;
    //cout<<"Test: Fourth function"<<endl;
    //cout<<"Number of graduations: "<<graduations<<endl;

    for (int b=0; b<graduations; b++){
        for (int a=0; a<graduations; a++){

            array[a*graduations + b] = ( sin(minX + a * stepX) * (0.5) ) + ( (cos((minY + b * stepY) * 3) ) * (minX + a * stepX) );

            switch(outputType){
                case 0:
                    if (array[a*graduations + b] > 0){
                        cout<<"O"; //the value is positive
                    }
                    else{
                        cout<<"X"; //the value is negative
                    }
                    break;
                case 1:
                    cout<<array[a*graduations + b];
                    break;
            }
        }cout<<endl;
    }
}

int userMenu(){
    int choice;

    cerr<<"Select your function: "<<endl;
    cerr<<"1. sin(x)cos(y)"<<endl;
    cerr<<"2. sin(x)+cos^2(y/2)-x/y"<<endl;
    cerr<<"3. 1/2 sin(x) + 1/2 cos(y)"<<endl;
    cerr<<"4. 1/2 sin(x) + xcos(3y)"<<endl;
    cerr<<"0. Quit"<<endl;

    cin>>choice;
    return choice;
}

int graduationNumber(){
    int graduations;

    cerr<<"Number of graduations per axis: ";
    cin>>graduations;

    return graduations;
}

int outputType(){
    int outputType;

    cerr<<"(0) Bitmap or (1) Values? ";
    cin>>outputType;

    return outputType;
}

int main(){
    
    int graduationChoice;
    int outputChoice;
    int userChoice;
    
    do{
        userChoice = userMenu();
        switch(userChoice){
            case 1:
                graduationChoice = graduationNumber();
                outputChoice = outputType();
                function1(graduationChoice, outputChoice);
                break;
            case 2:
                graduationChoice = graduationNumber();
                outputChoice = outputType();
                function2(graduationChoice, outputChoice);
                break;
            case 3:
                graduationChoice = graduationNumber();
                outputChoice = outputType();
                function3(graduationChoice, outputChoice);
                break;
            case 4:
                graduationChoice = graduationNumber();
                outputChoice = outputType();
                function4(graduationChoice, outputChoice);
                break;
        }
    }while(userChoice !=0);
}