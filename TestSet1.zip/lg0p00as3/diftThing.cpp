#include <iostream>
#include <fstream>

using namespace std;

void DFT(int vert, bool* visited,int numVert, int** graph, char* labels){
	cout<<labels[vert]<<",";
	visited[vert] = true;
	for (int i=0;i<numVert;i++){
		if (graph[vert][i]){
			if (!visited[i]){
				DFT(i, visited, numVert, graph, labels);
			}
		}	
	}

}

int main(int argvm, char** argc){

	ifstream input;
	input.open(argc[1]);
	
	int numVert;
	input>>numVert;

	char* labels = new char[numVert];
	
	for(int i=0;i<numVert;i++){
		input>>labels[i];
	}	
	/*for (int i=0;i<numVert;i++){
		cout <<labels[i]<<endl;
	}*/
	
	int** graph = new int*[numVert];
	for(int i=0; i<numVert;i++){
		graph[i] = new int[numVert];		
	}

	for(int i=0; i<numVert;i++){ //init 2D array to 0
		for(int j=0; j<numVert;j++){
			graph[i][j] =0;		
		}	
	}
	
	int numEdge;
	input>>numEdge;

	for (int i=0; i<numEdge;i++){
		int from,to;
		input>>from>>to; //double read, can separate into two reads if you want
		graph[from][to] = 1; 
	}

	//output etc.

	cout<<"Vertices: "<<endl;

	for (int i=0; i<numVert;i++){
		cout << "[" << i << ":" << labels[i] << "] ";
	}
	cout<<endl<<endl;

	cout<< "Edges: "<<endl;
	
	for (int i=0; i<numVert;i++){
		cout<<labels[i]<<" -> ";
		for (int j=0;j<numVert;j++){
			if (graph[i][j]){
				cout<<labels[j]<< ", ";
			}		
		}
		cout<<endl;
	}
	cout<<endl;
	
		

	cout<<"Starting vertex number for DFT: ";
	int dftstart;	
	cin>>dftstart;
	
	bool* visited = new bool[numVert];	
	
	for(int i=0; i<numVert;i++){
		visited[i] = false;
	}	
	
	DFT(dftstart,visited, numVert, graph, labels);
	cout<<endl;
	
	//memory management
	input.close();
	delete[] visited;
	delete[] labels;
	for (int i=0; i<numVert;i++){
		delete[] graph[i];	
	}
	delete[] graph;
	
	return 0;	

}
