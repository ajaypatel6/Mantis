package Assign_5; 
 
 
import Media.*;                  // for Media classes 
import static java.lang.Math.*;  // for math constants and functions 

 
 
/** This class ... 
  * 
  * @author Saifa Bhanji
  * @version 1.0 (Nov 2015)                                                        */ 
 
public class Noisy { 
     
     
    // instance variables 
  
  private SoundPlayer player; // a player for the sound
  public static final int FACTOR = 2; 
     
     
    /** This constructor ...                                                     */ 
     
    public Noisy ( ) { 
 
        // local variables 
      Sound theSound; //sound that user loads into the program
      Sound newSound; //sound that is cleaned up
         
        // statements 
      
      player = new SoundPlayer();
      theSound = new Sound();
      
      player.placeSound(theSound); 
      player.waitForUser();
      newSound = clean(theSound, FACTOR);
      player.placeSound(newSound);
      player.waitForUser();
      player.close();
      newSound.save(); 
         
    }; // constructor 
     
     
    // methods 
 
    private Sound clean (Sound original, int factor) {
      Sound result; 
      Sample s; 
      int numSamples; 
      int pos; 
      int amp1;
      int amp2;
      int amp3;
      int amp4;
      int amp5;
      int average; 
   
      numSamples = original.getNumSamples(); 
      result = new Sound(numSamples, original); 
      pos = 2; 
      average = 0; 
      
      while (pos < numSamples - 2) {
        amp1 = original.getSample(pos-factor).getAmp();
        amp2 = original.getSample(pos - (factor - 1)).getAmp();
        amp3 = original.getSample(pos).getAmp();
        amp4 = original.getSample(pos + (factor - 1)).getAmp();
        amp5 = original.getSample(pos + factor).getAmp();
        average = (amp1 + amp2 + amp3 + amp4 + amp5) /5; 

        result.getSample(pos).setAmp(average); 
        pos = pos + 1;
       } // end while loop
      return result; 
    } ///clean
     
    public static void main ( String[] args ) { Noisy s = new Noisy(); }; 
     
     
} // Noisy 
