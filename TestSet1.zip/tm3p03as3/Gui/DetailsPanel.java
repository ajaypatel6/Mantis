package Gui;

import java.awt.*;
import assign3.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.EventListenerList;

/**
 *
 * @author Tamara McDiarmid Student # 6148837 COSC ASSIGNMENT #
 */
public class DetailsPanel extends JPanel {

    private GridBagConstraints gc = new GridBagConstraints();
    private JLabel filePathLbl = new JLabel("File Path: ");
    private JLabel currBestLbl = new JLabel("Current Best: ");
    private JLabel numThreadsLbl = new JLabel("Number of Threads: ");
    private JLabel numSearchLbl = new JLabel("Number of Searches: ");
    private JLabel numIterationsLbl = new JLabel("Number of Iterations");
    private JTextField filePathFld = new JTextField(10);
    private JTextField currBestFld = new JTextField(10);
    private JTextField numThreadsFld = new JTextField(10);
    private JTextField numSearchFld = new JTextField(10);
    private JTextField numIterationsFld = new JTextField(10);
    private JButton addBtn = new JButton("Run Search");
    private String filePath;    //stores the filePath entered into GUI
    private String numThreads;
    private String numSearch;
    private String numIterations;
    private EventListenerList listenList = new EventListenerList();

    public DetailsPanel() {
        Dimension size = getPreferredSize();
        size.width = 250;
        setPreferredSize(size);
        setBorder(BorderFactory.createTitledBorder("data display"));
        setLayout(new GridBagLayout());
        setupForm();

    }//constructor

    private void setupForm() {
//FILE PATH FIELDS
        gc.anchor = GridBagConstraints.LINE_END;
        gc.weightx = 0.25;
        gc.weighty = 0.25;
        gc.gridx = 0;
        gc.gridy = 0;
        add(filePathLbl, gc);
        gc.anchor = GridBagConstraints.LINE_START;
        gc.gridx = 1;
        gc.gridy = 0;
        add(filePathFld, gc);
        filePathFld.setText("berlin52.txt");
//END OF FILE PATH FIELDS

//BUTTON ADDED
        gc.anchor = GridBagConstraints.CENTER;
        gc.gridx = 1;
        gc.gridy = 1;
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fp = filePathFld.getText();
                filePath = fp;
                numThreads = (numThreadsFld.getText());
                numSearch = (numSearchFld.getText());
                numIterations = (numIterationsFld.getText());
                fireEvent(new PanelEvent(this, fp));
            }
        });
        add(addBtn, gc);
//END OF BUTTON ADDED

//OTHER FIELDS ADDED 
        gc.anchor = GridBagConstraints.LINE_END;
        gc.gridx = 0;
        gc.gridy = 2;
        add(currBestLbl, gc);
        gc.anchor = GridBagConstraints.LINE_START;
        gc.gridx = 1;
        gc.gridy = 2;
        add(currBestFld, gc);
        currBestFld.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
              fireEvent(new PanelEvent(this));
            }
            
        });
        gc.anchor = GridBagConstraints.LINE_END;
        gc.gridx = 0;
        gc.gridy = 3;
        add(numThreadsLbl, gc);
        gc.anchor = GridBagConstraints.LINE_START;
        gc.gridx = 1;
        gc.gridy = 3;
        add(numThreadsFld, gc);
        numThreadsFld.setText("3");
        gc.anchor = GridBagConstraints.LINE_END;
        gc.gridx = 0;
        gc.gridy = 4;
        add(numSearchLbl, gc);
        gc.anchor = GridBagConstraints.LINE_START;
        gc.gridx = 1;
        gc.gridy = 4;
        add(numSearchFld, gc);
        numSearchFld.setText("30");
        gc.anchor = GridBagConstraints.FIRST_LINE_START;
        gc.weighty = 10;
        gc.gridx = 0;
        gc.gridy = 5;
        add(numIterationsLbl, gc);
        gc.gridx = 1;
        gc.gridy = 5;
        add(numIterationsFld, gc);
        numIterationsFld.setText("1000000");
//END OF OTHER FIELDS
    }//setupForm

    //fires events from panel
    public void fireEvent(PanelEvent event) {
        Object[] listeners = listenList.getListenerList();
        for (int i = 0; i < listeners.length; i += 2) {
            if (listeners[i] == PanelListener.class) {
                ((PanelListener) listeners[i + 1]).panelEventOccurred(event);
            }
        }
    }

    //getter method for the filepath
    public String getFilePath() {
        return filePath;
    }//getFilePath

    public String getNumThreads() {
        return numThreads;
    }//getNumThreads

    public String getNumIterations() {
        return numIterations;
    }//getNumIterations

    public String getNumSearches() {
        return numSearch;
    }//getNumSearches

    public void addPanelListener(PanelListener listen) {
        listenList.add(PanelListener.class, listen);
    }//addPanelListener

    public void removePanelListener(PanelListener listen) {
        listenList.remove(PanelListener.class, listen);
    }//removePanelListener

    public JTextField getFilePathField() {
        return filePathFld;
    }
    public JTextField getCurrBestField() {
        return currBestFld;
    }
}//DetailsPane
