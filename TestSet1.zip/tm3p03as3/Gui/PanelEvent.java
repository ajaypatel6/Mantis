package Gui;

import java.util.EventObject;
import Assign3.TSP;
/**
 *
 * Tamara McDiarmid Student # 6148837 COSC ASSIGNMENT #3
 */
public class PanelEvent extends EventObject{
    private String thePath;
    
    public PanelEvent(Object o, String pathString){
        super(o);
        this.thePath=pathString;
    }//constructor
    public PanelEvent(Object obj){
        super(obj);
        
    }
    public String getPath(){
        return thePath;
    }//getPath
}//PanelEvent
