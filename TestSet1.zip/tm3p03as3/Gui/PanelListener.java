package Gui;

import java.util.EventListener;
import Assign3.TSP;

/**
 *
 * @author Tamara McDiarmid Student # 6148837 COSC ASSIGNMENT #
 */
public interface PanelListener extends EventListener  {
   
       public void panelEventOccurred(PanelEvent event);
}
