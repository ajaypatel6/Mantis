package Gui;

//import Assign3.*;
import Assign3.TSP;
import java.awt.*;
import javax.swing.*;

/**
 *
 * Tamara McDiarmid Student # 6148837 COSC ASSIGNMENT #3
 */
public class MainFrame extends JFrame {

    private DetailsPanel detailsPanel;
    TSP theSearch;  //search class that searches using evolutionary strategy

    //main controller that listens for events on GUI
    public MainFrame(String title) {
        super(title);
        setLayout(new BorderLayout());

        //create components
        Container c = getContentPane();
        
        detailsPanel = new DetailsPanel();
        c.add(detailsPanel, BorderLayout.WEST);
        c.setVisible(true);
        detailsPanel.addPanelListener(new PanelListener() {
            @Override
            public void panelEventOccurred(PanelEvent event) {

                String str = event.getPath();
                int numThreads = Integer.parseInt(detailsPanel.getNumThreads());
                int numIts = Integer.parseInt(detailsPanel.getNumIterations());
                int numSearch = Integer.parseInt(detailsPanel.getNumSearches());
                Thread[] myThreads = new Thread[numThreads];
                for (int i = 0; i < numThreads; i++) {
                    theSearch = new TSP(str, numThreads, numIts, numSearch, detailsPanel, c);
                    myThreads[i] = new Thread(theSearch);
                    myThreads[i].start();
                }
            }

        });
        detailsPanel.addPanelListener(new PanelListener() {
            @Override
            public void panelEventOccurred(PanelEvent event) {

                Draw draw = new Draw(c, theSearch);
                c.setVisible(true);
                repaint();
                draw.setVisible(true);
            }

        });

    }//constructor
}//MainFrame
