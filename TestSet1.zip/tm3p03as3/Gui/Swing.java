package Gui;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import Assign3.TSP;
/**
 *
 * Tamara McDiarmid Student # 6148837 COSC ASSIGNMENT #3
 */
public class Swing {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                JFrame frame = new MainFrame("TSP Solver");
                frame.setSize(1500, 1500);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setVisible(true);
            }
        });

    }
}//Swing
