package Gui;

/**
 *
 * Tamara McDiarmid 6148837 Assignment #3 march 2018
 */
import Assign3.Point;
import Assign3.TSP;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Line2D;
import javax.swing.*;

public class Draw extends JFrame {

    TSP theSearch;
    Container c;

    public Draw(Container c, TSP t) {

        super();
        this.c = c;
        this.theSearch = t;
        c.setSize(1250, 1500);
        c.add(new Draw.DrawStuff(theSearch.getAllPoints(), theSearch.getCurrPath()), BorderLayout.CENTER);
        c.repaint();
        c.setVisible(true);
    }

    public class DrawStuff extends JComponent {

        int[] path;
        Point[] points;

        public DrawStuff(Point[] p, int[] pa) {
            super();
            this.path = pa;
            this.points = p;

        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            setOpaque(true);
            for (int i = 0; i < 52; i++) {
                if (i + 1 < 52) {
                    float x1 = scaleDown(points[path[i]].getX());
                    float y1 = scaleDown(points[path[i]].getY());
                    float x2 = scaleDown(points[path[i + 1]].getX());
                    float y2 = scaleDown(points[path[i + 1]].getY());
                    Shape line = new Line2D.Double(x1, y1, x2, y2);
                    g2.setPaint(Color.BLACK);
                    g2.draw(line);
                }

            }
            float x1 = scaleDown(points[path[0]].getX());
            float y1 = scaleDown(points[path[0]].getY());
            float x2 = scaleDown(points[path[51]].getX());
            float y2 = scaleDown(points[path[51]].getY());
            Shape line = new Line2D.Double(x1, y1, x2, y2);
            g2.setPaint(Color.BLACK);
            g2.draw(line);
        }//paint

        public float scaleDown(float f) {
            float result = f / 2;
            return result;
        }//scaleDown
    }
}//Draw

