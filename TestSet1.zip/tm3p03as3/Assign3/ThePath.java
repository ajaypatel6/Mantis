package Assign3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

/**
 *
 * Tamara McDiarmid 6148837 COSC 2P05 ASSIGN#3 March 2018
 */
public class ThePath {

    private int[] path = new int[52];
    private int[] newPath = new int[52];
    int[] d = new int[3];
    int[] a = new int[3];
    private Point[] thePoints;
    private double[][] matrix;
    private static int globalBest = 1000000;

    public ThePath(Point[] allPoints, double[][] adjMatrix) {
        this.thePoints = allPoints;
        this.matrix = adjMatrix;
        generatePath();
        shuffle();
    }

    public Point[] getThePoints() {
        return thePoints;
    }

    public double calcDistOfPath(int[] pathDist) {
        int i = 0;
        double dist = 0;
        while (i + 1 < 51) {
            double add = get(pathDist[i], pathDist[i + 1]);
            dist = dist + add;
            i++;
        }
        double addTripHome=get(pathDist[0],pathDist[51]);
        dist=dist+addTripHome;
        return dist;
    }//calcDistOfPath

    private double get(int start, int go) {
        double num = matrix[start][go];
        return num;
    }

    private int[] distinctGenerator() {
        ArrayList<Integer> distinct = new ArrayList<>();
        int[] theDistinctNums = new int[3];
        for (int i = 0; i < 52; i++) {
            distinct.add(new Integer(i));
        }
        Collections.shuffle(distinct);
        for (int i = 0; i < 3; i++) {
            theDistinctNums[i] = distinct.get(i);
        }
        return theDistinctNums;
    }//distinctGenerator

    public int[] transformation() {
        for (int copy = 0; copy < path.length; copy++) {
            newPath[copy] = path[copy];
        }
        d = distinctGenerator();
        int[] testy = new int[3];
        for (int t = 0; t < testy.length; t++) {
            testy[t] = d[t];
        }
        a = shuffleThree(d);
        mutate(a, testy);
        return newPath;
    }//transformation

    private void mutate(int[] a, int[] orig) {
        if (Arrays.equals(a, orig)) {
            int[] retry = shuffleThree(a);
            mutate(retry, orig);
        }
        if (a[0] == orig[0]) {
            newPath[a[2]] = path[a[1]];
            newPath[a[1]] = path[a[2]];
        }
        if (a[1] == orig[1]) {
            newPath[orig[0]] = path[a[2]];
            newPath[orig[2]] = path[a[0]];
        }
        if (a[2] == orig[2]) {
            newPath[a[0]] = path[a[1]];
            newPath[a[1]] = path[a[0]];
        }
        if (a[2] == orig[0]) {
            newPath[a[1]] = path[orig[0]];
            newPath[a[2]] = path[orig[1]];
            newPath[a[0]] = path[orig[2]];
        }
        if (a[0] == orig[2]) {
            newPath[a[2]] = path[orig[0]];
            newPath[a[0]] = path[orig[1]];
            newPath[a[1]] = path[orig[2]];
        }

    }//mutate

    //shuffles the 3 distinct generated numbers
    private int[] shuffleThree(int[] threeToShuffle) {
        Random random = new Random();
        for (int i = 0; i < threeToShuffle.length; i++) {
            int r = i + random.nextInt(threeToShuffle.length - i);
            int temp = threeToShuffle[r];
            threeToShuffle[r] = threeToShuffle[i];
            threeToShuffle[i] = temp;
        }
        return threeToShuffle;
    }//shuffleThree

    public int[] getPath() {
        return path;
    }//getPath

    public int[] getNewPath() {
        return newPath;
    }//getPath

    private void generatePath() {
        for (int i = 0; i < path.length; i++) {
            path[i] = i;
        }
    }//generateRandomPath

    //shuffles the 52 vertices
    public int[] shuffle() {
        Random random = new Random();
        for (int i = 0; i < path.length; i++) {
            int r = i + random.nextInt(path.length - i);
            int temp = path[r];
            path[r] = path[i];
            path[i] = temp;
        }
        return path;
    }//shuffle

    public void updateCurrPath(int[] mutation) {
        for (int i = 0; i < path.length; i++) {
            path[i] = mutation[i];
        }
    }//updateCurrPath

    public void updateGlobalBest(int num) {
        System.out.println("GLOBAL UPDATE");
        if (globalBest > num) {
            globalBest = num;
        }

    }//updateGlobalBest

    public int getGlobalBest() {
        return globalBest;
    }//getGlobalBest
}//ThePath
