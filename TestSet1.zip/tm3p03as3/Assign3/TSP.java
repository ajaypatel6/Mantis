package Assign3;

import Gui.DetailsPanel;
import java.awt.Container;


/**
 * Tamara McDiarmid 6148837 COSC 2P05 - ASSIGN #3 MARCH 2018
 *
 */
//class used to control objects
public class TSP implements Runnable {

    private Point[] allPoints;  //stores all points
    private double[][] adjMatrix;   //stores the adjacencymatrix of the points
    private ThePath aPath;
    private int[] mutatedPath;
    private int[] currentPath;
    private int numIts; //stores passed in GUI value entered for # of iterations
    private int numSearches;
    private int numThreads;
    public static int nThreads = 0;
    DetailsPanel dp;
    Container c;

    public TSP(String thePath, int numThreads, int numIts, int numSearch, DetailsPanel dp, Container c) {
        this.c = c;
        this.dp = dp;
        this.numIts = numIts;
        this.numSearches = numSearch;
        this.numThreads = numThreads;
        GetFile creator = new GetFile(thePath);
        allPoints = creator.getAllThePoints();
        adjMatrix = creator.getTheAdjMatrix();
        aPath = new ThePath(allPoints, adjMatrix);
        currentPath = aPath.getPath();
        mutatedPath = aPath.transformation();
    }//constructor   

    public void run() {
        int localBest = 888888;
        System.out.println("MADE IT TO THREADS");
        for (int out = 0; out < numSearches; out++) {
            currentPath = aPath.shuffle();
            for (int i = 0; i < numIts; i++) {
                aPath.transformation();
                mutatedPath = aPath.getNewPath();
                if (aPath.calcDistOfPath(mutatedPath) < aPath.calcDistOfPath(currentPath)) {
                    aPath.updateCurrPath(mutatedPath);
                    currentPath = aPath.getPath();
                    localBest = (int) aPath.calcDistOfPath(mutatedPath);
                }
            }

        }
        boolean value = dp.getCurrBestField().getText().isEmpty();
        if (value) {
            dp.getCurrBestField().setText(String.valueOf(localBest));
        } else {
            int toCompare = Integer.parseInt(dp.getCurrBestField().getText());
            if (toCompare > localBest) {
                dp.getCurrBestField().setText("");
                dp.getCurrBestField().setText(String.valueOf(localBest));
            }
        }

        System.out.println(aPath.calcDistOfPath(mutatedPath));
        System.out.println(aPath.calcDistOfPath(currentPath));
    }//evolutionaryStrategy

    public int getBest() {
        return (int) aPath.calcDistOfPath(currentPath);
    }

    public ThePath getPath() {
        return aPath;
    }

    public Point[] getAllPoints() {
        return allPoints;
    }

    public int[] getCurrPath() {
        return currentPath;
    }

}//TSP
