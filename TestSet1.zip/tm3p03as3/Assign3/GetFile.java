/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assign3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * Tamara McDiarmid Student # 6148837 COSC ASSIGNMENT #3
 */
public class GetFile {

    private String path;
    private Point[] allPoints;
    private AdjMatrix theMatrix;

    public GetFile(String thePath) {
        this.path = thePath;
        getInputFile();

    }//constructor

    //getter method for all 52 points assoc. with the problem
    public Point[] getAllThePoints() {
        return allPoints;
    }//getAllthePoints

    public double[][] getTheAdjMatrix() {
        return theMatrix.getAdjMatrix();
    }//getAdjMatrix

    private void getInputFile() {
        boolean value = false;
        try {
            File pathway = new File(path);
            Scanner reader = new Scanner(pathway);
            value = true;
            if (value) {
                makePoints(reader);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("EXCEPTION CAUGHT--> " + ex);
            
        }

    }//getInputFile

    private void makePoints(Scanner s) {
        int size = s.nextInt();
        allPoints = new Point[size];
        while (s.hasNext()) {
            int pos = Integer.parseInt(s.next());
            float x = Float.parseFloat(s.next());
            float y = Float.parseFloat(s.next());
            allPoints[pos - 1] = new Point(x, y);
        }
        //print();
        makeMatrix();
    }//makePoints

    private void print() {
        theMatrix.print();
    }//print

    private void makeMatrix() {
        theMatrix = new AdjMatrix(allPoints);
    }//makeMatrix

}//GetFile

