/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assign3;

/**
 *
 * Tamara McDiarmid 6148837 assignment#3
 */
public class Point {

    private float x;
    private float y;
    private int pos;

    public Point( float x, float y) {
        this.x = x;
        this.y = y;
        this.pos=pos;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }
    public int getPos(){
        return pos;
    }
}//Point
