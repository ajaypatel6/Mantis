package Assign3;

import static java.lang.Math.sqrt;

/**
 * Tamara McDiarmid 6148837 COSC2P05 ASSIGNMENT#3 MARCH 2018
 *
 */
public class AdjMatrix {

    private double[][] adjMatrix = new double[52][52];
    private Point[] vertices;

    public AdjMatrix(Point[] v) {
        this.vertices = v;
        computeTheMatrix();

    }//constructor

    private void computeTheMatrix() {
        for (int i = 0; i < adjMatrix.length; i++) {
            for (int j = 0; j < adjMatrix[i].length; j++) {
                if (i == j) {
                    adjMatrix[i][j] = 0;
                    adjMatrix[j][i] = 0;
                } else {
                    addEdge(i, j, vertices[i], vertices[j]);
                }
            }
        }
    }//computeTheMatrix

    public void addEdge(int fillX, int fillY, Point one, Point two) {
        double temp = sqrt((one.getX() - two.getX()) * (one.getX() - two.getX()) + (one.getY() - two.getY()) * (one.getY() - two.getY()));
        adjMatrix[fillX][fillY] = temp;
        adjMatrix[fillY][fillX] = temp;
    }//addEdge

    //used for testing purposes
    public void print() {
        for (int i = 0; i < adjMatrix.length; i++) {
            for (int j = 0; j < adjMatrix[i].length; j++) {
                // System.out.print(adjMatrix[i][j] + " , ");
            }
        }
    }//print

    public double[][] getAdjMatrix() {
        return adjMatrix;
    }//getAdjMatrix
}//AdjMatrix
