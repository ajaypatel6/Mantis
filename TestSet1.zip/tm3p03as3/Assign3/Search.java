package Assign3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

/**
 *
 * Tamara McDiarmid 6148837 COSC2P05 ASSIGNMENT#3 MARCH 5/ 2018
 */
public class Search {

    private int[] path = new int[52];
    private double[][] adjMatrix;
    int[] d = new int[3];
    int[] rearrange1 = new int[3];//????????????
    int[] rearrange2 = new int[3];
    int[] rearrange3 = new int[3];
    int[] rearrange4 = new int[3];
    int[] rearrange5 = new int[3];
    int[] rearrange6 = new int[3];

    public Search(double[][] adjMatrix) {
        this.adjMatrix = adjMatrix;
        generateRandomPath();
        shuffle();
        d = distinctGenerator();
        rearrange(0, d);
        int[] a1 = {2, 1, 3};
        int[] a2 = {1, 2, 3};
        if (Arrays.equals(a1, a2)) {
            System.out.println("SAME");
        }
    }//constructor

    private void rearrange(int x, int[] array) {
        if (x == array.length) {
            System.out.println("DOH!");
            
            return;
        }
        for (int i = x; i < array.length; i++) {
            int temp = array[i];
            array[i] = array[x];
            array[x] = temp;
            rearrange(x + 1, array);
            temp = array[i];
            array[i] = array[x];
            array[x] = temp;
        }
    }//rearrange 
    //randomly selects 3 numbers from 0 to 51

    private int[] distinctGenerator() {
        ArrayList<Integer> distinct = new ArrayList<>();
        int[] theDistinctNums = new int[3];
        for (int i = 1; i < 4; i++) {
            distinct.add(new Integer(i));
        }
        Collections.shuffle(distinct);
        for (int i = 0; i < 3; i++) {
            //System.out.println(distinct.get(i));
            theDistinctNums[i] = distinct.get(i);
            //   System.out.println(theDistinctNums[i]);
        }
        return theDistinctNums;
    }//distinctGenerator

    //shuffles the 52 vertices
    private void shuffle() {
        Random random = new Random();
        for (int i = 0; i < path.length; i++) {
            int r = i + random.nextInt(path.length - i);
            int temp = path[r];
            path[r] = path[i];
            path[i] = temp;
        }
    }//shuffle

    private void generateRandomPath() {
        for (int i = 0; i < path.length; i++) {
            path[i] = i;
        }
    }//generateRandomPath

    public void print() {
        for (int i = 0; i < path.length; i++) {
            System.out.println(path[i]);
        }
    }//print
}//Search
