#COSC 3P03 Assignment 3 Question 1
#Curtis Penney - 5660659

#Default settings
distMax = 11
distGoal = 15
distCost = [0 for x in range(distMax)]
distCost[0] = 0
distCost[1] = 2
distCost[2] = 6
distCost[3] = 4
distCost[4] = 3
distCost[5] = 6
distCost[6] = 2
distCost[7] = 4
distCost[8] = 9
distCost[9] = 5
distCost[10] = 1

#Validating if the user wants custom input
print ("Do you wish to enter a custom information? (Y/N)")
UserInputQuery = input()

#If the user wants to input...
if UserInputQuery == "Y" or UserInputQuery == "y" :
	#Uncomment for user input
	print ("Please enter the maximum Distance the bus can travel: ")
	distMax = int(input()) + 1
	distCost = [0 for x in range(distMax)]
	print ("Please enter the distance to travel: ")
	distGoal = int(input())
	
	print("Please enter the costs of travelling the following distances: ")
	for i in range(1, distMax):
		print("Distance " + str(i) + ": ", end='')
		distCost[i] = int(input())
		
#Calculating the optimal route
maxVal = 999999
optimalCost = [0 for x in range(distMax)]

for i in range (1, distMax):
	minVal = maxVal
	for j in range(i):
		#Initial Case
		minVal = min(minVal, distCost[j] + optimalCost[i-j-1])
	optimalCost[i] = minVal

for i in range (1, distMax):
	print(optimalCost[i])





		
