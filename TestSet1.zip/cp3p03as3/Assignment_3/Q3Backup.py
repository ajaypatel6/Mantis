#COSC 3P03 Assignment 3 Question 3
#Curtis Penney - 5660659

#Initializing with default...
matrixNum = 4
dimNum = 5
dimArr = [0 for x in range(dimNum)]
dimArr[0] = 10
dimArr[1] = 20
dimArr[2] = 50
dimArr[3] = 1
dimArr[4] = 100


#Validating if the user wants custom input
print ("Do you wish to enter custom arrays? (Y/N)")
UserInputQuery = input()

#If the user wants to input...
if UserInputQuery == "Y" or UserInputQuery == "y" :
	#Uncomment for user input
	print ("Please enter the number of matrices to multiply: ")
	matrixNum = int(input())
	dimNum = matrixNum + 1
	dimArr = [0 for x in range(dimNum)]
	
	print ("Please enter the matrix dimensions in order. ex. 2x2 X 2x3 X 3x7 => 2,2,3,7")
	for i in range(dimNum):
		print ("Please enter the dimention #: " + str(i+1))
		
		#Ensuring the user inputs valid data
		while True:
			userIn = input()
			
			#Handling cases...
			if (userIn.isdigit() and int(userIn) > 0):
				dimArr[i] = userIn
				break
			else:
				print("The string must be an integer greater than 0.")
				

#Input has been stored. Time to do the stuff!

#Initializing the Cost array
matrixCost = [[0 for x in range(matrixNum)] for y in range(matrixNum)]
for i in range(matrixNum):
	matrixCost[i][i] = 0

for l in range(1, matrixNum):
	for i in range(matrixNum - l + 1):
		j = i + l 
		
		minK   = -1
		minVal = -1
		for k in range(i, j):
			tempVal = matrixCost[i][k] + matrixCost[k+1][j] + (int(dimArr[i]) * int(dimArr[k]) * int(dimArr[j]))
			if (minVal == -1 or minVal > tempVal):
				minVal = tempVal
				minK   = k
		
		matrixCost[i][j] = minVal
		
for i in range(matrixNum):
	for j in range(matrixNum):
		print(str(matrixCost[i][j]) + ",", end='')
	print()








