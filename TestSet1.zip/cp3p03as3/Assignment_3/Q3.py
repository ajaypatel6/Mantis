#COSC 3P03 Assignment 3 Question 3
#Curtis Penney - 5660659

#Initializing things...
matrixNum = 4
dimNum = 5
dimArr = [0 for x in range(dimNum)]
dimArr[0] = 10
dimArr[1] = 20
dimArr[2] = 50
dimArr[3] = 1
dimArr[4] = 100


#Validating if the user wants custom input
print ("Do you wish to enter custom arrays? (Y/N)")
UserInputQuery = input()
#If the user wants to input...
if UserInputQuery == "Y" or UserInputQuery == "y" :
	#Uncomment for user input
	print ("Please enter the number of matrices to multiply: ")
	matrixNum = int(input())
	dimNum = matrixNum + 1
	dimArr = [0 for x in range(dimNum)]
	
	print ("Please enter the matrix dimensions in order. ex. 2x2 X 2x3 X 3x7 => 2,2,3,7")
	for i in range(dimNum):
		print ("Please enter the dimention #(" + str(i+1) + "): ", end='')
		
		#Ensuring the user inputs valid data
		while True:
			userIn = input()
			
			#Handling cases...
			if (userIn.isdigit() and int(userIn) > 0):
				dimArr[i] = userIn
				break
			else:
				print("The string must be an integer greater than 0.")
				
				
#Initializing the Cost and Tracker arrays
matrixCost = [[0 for x in range(dimNum)] for y in range(dimNum)]
matrixTrack = [[0 for x in range(dimNum)] for y in range(dimNum)]

	
#Calculating, fills the matrixCost and matrixTrack arrays.
for l in range(2, dimNum):
	for i in range(1, dimNum - l + 1):
		j = i + l - 1
		
		minTrack   = -1
		minVal = -1

		for k in range(i, j):
			tempVal = matrixCost[i][k] + matrixCost[k+1][j] + (int(dimArr[i-1]) * int(dimArr[k]) * int(dimArr[j]))
			if (minVal == -1 or minVal > tempVal):
				minVal = tempVal
				minTrack   = k
		
		#Adding values to the arrays
		matrixTrack[i][j] = minTrack
		matrixCost[i][j] = minVal

#Initializing output string
matrixArr = [0 for x in range(dimNum)]
for i in range(1, dimNum):
	matrixArr[i] = str(dimArr[i - 1]) + "x" + str(dimArr[i])
	
#Placing Brackets
tempX = 1
tempY = matrixNum
while (matrixCost[tempX][tempY] != 0):
	#Adding the brackets on the left and right sides... and in middle
	matrixArr[tempX] = "(" + matrixArr[tempX] 
	matrixArr[tempY] = matrixArr[tempY] + ")" 
	matrixArr[matrixTrack[tempX][tempY] + 1] = "(" + matrixArr[matrixTrack[tempX][tempY] + 1] 
	matrixArr[matrixTrack[tempX][tempY]] = matrixArr[matrixTrack[tempX][tempY]] + ")"
	
	#Determining next bracket location!
	if matrixCost[tempX + 1][tempY] <= matrixCost[tempX][tempY - 1]:
		#Going down
		tempX = tempX + 1
	else:
		#Going left
		tempY = tempY - 1

#Concatenating output String
optimalBrackets = ""
for i in range(1, dimNum):
	optimalBrackets = optimalBrackets + matrixArr[i]
	if i < dimNum -1:
		optimalBrackets = optimalBrackets + " * "
	
#Printing the output for the user
print()
print("The optimal solution has a cost of " + str(matrixCost[1][matrixNum]))
print("The optimal brackets are as follows: ")
print(optimalBrackets)


print()
#Printing matrixTrack array
for i in range(dimNum):
	for j in range(dimNum):
		print(str(matrixTrack[i][j]) + ",", end='')
	print()
print()	
#Printing matrixCost array
for i in range(dimNum):
	for j in range(dimNum):
		print(str(matrixCost[i][j]) + ",", end='')
	print()








