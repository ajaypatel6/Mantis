#COSC 3P03 Assignment 3 Question 2
#Curtis Penney - 5660659

#Initializing with default words...
String_1 = "photograph"
String_2 = "tomography"

#Validating if the user wants custom input
print ("Default substring comparison is ""photograph"" and ""tomography"". ")
print ("Do you wish to enter custom strings? (Y/N)")
UserInputQuery = input()

#If the user wants to input...
if UserInputQuery == "Y" or UserInputQuery == "y" :
	#Uncomment for user input
	print ("Please enter the first word: ")
	String_1 = input()
	print ("Please enter the second word: ")
	String_2 = input()

#Initializing variables
String_Length_1 = len(String_1) + 1
String_Length_2 = len(String_2) + 1
CSuff = [[0 for x in range(String_Length_2)] for y in range(String_Length_1)]

#Initializing the first row and column
for i in range(String_Length_1):
	CSuff[i][0] = 0
for j in range(String_Length_2):
	CSuff[0][j] = 0

#Populating the table (array)
for i in range(1, String_Length_1):
	for j in range(1, String_Length_2):
		if (String_1[i-1] == String_2[j-1]):
			CSuff[i][j] = CSuff[i-1][j-1] + 1
		else:
			CSuff[i][j] = 0

#Max can be calculated during creation of the table for a simpler solution
#However calculating it here allows the table to be abstracted out and stored, letting the search happen on an already existing Common-Suffix table
max = 0
for i in range(1, String_Length_1):
	for j in range(1, String_Length_2):
		if CSuff[i][j] > max:
			max = CSuff[i][j]

#Printing the output
print ("Longest substring of " + str(String_1) + " and " + str(String_2) + " is: "  + str(max))			