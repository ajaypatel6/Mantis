package Assign_7; 
 
import BasicIO.*;
import static BasicIO.Formats.*;


public class Account {
  
  //instance variables
  
  private String acctNum; // Account Number
  private String name; // Name on Account
  private double reading; //last reading of the meter
  private static final double RATE = 1.525; 
  
  /* This constructor...*/ 
  public Account (String acctNum, String name, double reading) {
    this.acctNum = acctNum; 
    this.name = name; 
    this.reading = reading; 
    
  }; //constructor
  
  //methods
  
  public String getAcctNum () {
    return acctNum; 
    
  } //getAcctNum; 
  
  public String getName() {
    return name; 
  } //getName
  
  public double getReading() {
    return reading;
  }  //getReading
  
  public double bill (double newReading) {
    double oldreading = reading;
    this.reading = newReading; 
    
    // The amount charged is return 
    return (newReading - oldreading) * RATE; 
    
  } //bill
  
  public void write (ASCIIOutputFile data) {
   data.writeString(acctNum); 
   data.writeString(name); 
   data.writeDouble(reading); 
   data.newLine(); 
    
  } //write
  
} //Account
