package Assign_7; 
 
import BasicIO.*;
import static BasicIO.Formats.*;

 
 
/** This class ... 
  * 
  * @author Saifa Bhanji
  * @version 1.0 (Dec 2015)                                                        */ 
 
public class Billing { 
     
     
    // instance variables 
  
  private ASCIIDataFile acctData; 
  private ASCIIOutputFile newAcctData; 
  private ReportPrinter report; 
  private BasicForm display; 
     
     
    /** This constructor ...                                                     */ 
     
    public Billing ( ) { 
 
        // local variables 
      Account anAccount; 
      acctData = new ASCIIDataFile(); 
      newAcctData = new ASCIIOutputFile(); 
     report = new ReportPrinter(); 
     display = new BasicForm(); 
     setUpReport(); 
     buildForm(); 
      
      String acctNum; 
      String name; 
      double reading; 
      double newReading; 
      
      for (;;) {
        acctNum = acctData.readString(); 
        if (acctData.isEOF()) break; 
        name = acctData.readString(); 
       reading = acctData.readDouble();
       anAccount = new Account(acctNum, name, reading);
       fillForm(anAccount); 
       display.accept(); 
        newReading = display.readDouble("new");
        double amtCharged = anAccount.bill(newReading); 
      anAccount.write(newAcctData);  
      writeDetail(anAccount, reading, newReading, amtCharged); 
      
      }
       
  report.close();  
  display.close(); 
  acctData.close();
  newAcctData.close(); 
         
    }; // constructor 
     
     
    // methods 
    
     private void setUpReport ( ) {
        
        report.setTitle("Over The Horizon Utilities","Billing Report");
        report.addField("acctNum","Account #");
        report.addField("name","Name",20);
        report.addField("old","Previous",10);
        report.addField("new","Current",15);
        report.addField("charge","Charge",getCurrencyInstance(), 20);
        
    };  // setUpReport
     
      private void buildForm ( ) {
        display.setTitle("Over the Horizon Utilities"); 
        display.addTextField("acctNum","Account #");
        display.setEditable("acctNum",false);
        display.addTextField("name","Name");
        display.setEditable("name",false);
        display.addTextField("old","Previous Reading", getDecimalInstance(1));
        display.setEditable("old",false);
        display.addTextField("new","Current Reading");
        
    };  // buildForm
      
        public void fillForm ( Account anAccount ) {
        
        display.writeString("acctNum",anAccount.getAcctNum());
        display.writeString("name",anAccount.getName());
        display.writeDouble("old",anAccount.getReading());
        display.clear("new");
        
    };  // fillForm
        
       private void writeDetail ( Account anAccount, double reading, double newReading, double amtCharged) {
        
        report.writeString("acctNum",anAccount.getAcctNum());
        report.writeString("name",anAccount.getName());
        report.writeDouble("old", reading);
        report.writeDouble("new",newReading);
        report.writeDouble("charge",amtCharged);
        
    };  // writeDetail 
 
     
     
    public static void main ( String[] args ) { new Billing(); }; 
     
     
} // Billing 
